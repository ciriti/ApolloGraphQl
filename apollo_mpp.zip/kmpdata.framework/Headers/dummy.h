//! Project version number for dummy.
FOUNDATION_EXPORT double dummyVersionNumber;

//! Project version string for dummy.
FOUNDATION_EXPORT const unsigned char dummyVersionString[];
