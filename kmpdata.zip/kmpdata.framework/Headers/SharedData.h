#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class SharedDataEval<__covariant A>, SharedDataEvalAlways<__covariant A>, SharedDataEvalLater<__covariant A>, SharedDataEvalNow<__covariant A>, SharedDataKotlinUnit, SharedDataMpTry<__covariant A>, SharedDataKotlinThrowable, SharedDataMpTryFailure, SharedDataKotlinNothing, SharedDataMpTrySuccess<__covariant A>, SharedDataKotlinArray<T>, SharedDataKotlinException, SharedDataTryException, SharedDataTryExceptionPredicateException, SharedDataTryExceptionUnsupportedOperationException, SharedDataUserQueryData, SharedDataPrice, SharedDataDestination, SharedDataOkioByteString, SharedDataApollo_apiScalarTypeAdapters, SharedDataApollo_apiResponse<T>, SharedDataApollo_apiOperationVariables, SharedDataApollo_apiInput<V>, SharedDataUserQuery, SharedDataUserQueryUser, SharedDataUserQueryHobby, SharedDataKotlinEnum<E>, SharedDataCustomType, SharedDataRemoteDataSourceCompanion, SharedDataApollo_runtime_kotlinApolloClient, SharedDataKotlinByteArray, SharedDataApollo_apiResponseBuilder<T>, SharedDataApollo_apiError, SharedDataOkioBuffer, SharedDataOkioTimeout, SharedDataApollo_apiResponseField, SharedDataApollo_apiResponseFieldCustomTypeField, SharedDataKtor_client_coreHttpClient, SharedDataKtor_client_coreHttpClientEngineConfig, SharedDataKotlinx_coroutines_coreCoroutineDispatcher, SharedDataKotlinByteIterator, SharedDataApollo_apiCustomTypeValue<T>, SharedDataApollo_apiErrorLocation, SharedDataApollo_apiResponseFieldCondition, SharedDataApollo_apiResponseFieldType, SharedDataKtor_client_coreHttpClientConfig<T>, SharedDataKtor_client_coreHttpReceivePipeline, SharedDataKtor_client_coreHttpRequestPipeline, SharedDataKtor_client_coreHttpResponsePipeline, SharedDataKtor_client_coreHttpSendPipeline, SharedDataKtor_client_coreProxyConfig, SharedDataKotlinAbstractCoroutineContextElement, SharedDataApollo_runtime_kotlinGraphQLRequest, SharedDataApollo_runtime_kotlinApolloRequest<T>, SharedDataKotlinx_serialization_runtimeSerialKind, SharedDataKotlinx_serialization_runtimeUpdateMode, SharedDataKtor_utilsAttributeKey<T>, SharedDataKtor_utilsPipelinePhase, SharedDataKtor_utilsPipeline<TSubject, TContext>, SharedDataKtor_client_coreHttpResponse, SharedDataKtor_client_coreHttpClientCall, SharedDataKtor_client_coreHttpRequestBuilder, SharedDataKtor_client_coreHttpResponseContainer, SharedDataKtor_httpUrl, SharedDataKtor_utilsGMTDate, SharedDataKtor_httpHttpStatusCode, SharedDataKtor_httpHttpProtocolVersion, SharedDataKtor_httpHeadersBuilder, SharedDataKtor_client_coreHttpRequestData, SharedDataKtor_httpURLBuilder, SharedDataKtor_httpHttpMethod, SharedDataKtor_client_coreTypeInfo, SharedDataKtor_httpURLProtocol, SharedDataKtor_ioByteOrder, SharedDataKtor_utilsWeekDay, SharedDataKtor_utilsMonth, SharedDataKtor_httpOutgoingContent, SharedDataKtor_utilsStringValuesBuilder, SharedDataKtor_httpParametersBuilder, SharedDataKotlinx_coroutines_coreCancellationException, SharedDataKtor_ioIoBuffer, SharedDataKtor_httpContentType, SharedDataKotlinRuntimeException, SharedDataKotlinIllegalStateException, SharedDataKotlinKTypeProjection, SharedDataKtor_ioMemory, SharedDataKtor_ioBuffer, SharedDataKtor_ioChunkBuffer, SharedDataKotlinCharArray, SharedDataKtor_httpHeaderValueParam, SharedDataKtor_httpHeaderValueWithParameters, SharedDataKotlinx_coroutines_coreAtomicDesc, SharedDataKotlinx_coroutines_corePrepareOp, SharedDataKotlinKVariance, SharedDataKotlinCharIterator, SharedDataKotlinx_coroutines_coreAtomicOp<__contravariant T>, SharedDataKotlinx_coroutines_coreOpDescriptor, SharedDataKotlinx_coroutines_coreLinkedListNode, SharedDataKotlinx_coroutines_coreAbstractAtomicDesc;

@protocol SharedDataKind, SharedDataNetConfig, SharedDataRemoteRepoGraphQl, SharedDataDealsUseCase, SharedDataApollo_apiOperationName, SharedDataOkioBufferedSource, SharedDataApollo_apiResponseFieldMapper, SharedDataApollo_apiOperationData, SharedDataApollo_apiOperation, SharedDataApollo_apiQuery, SharedDataApollo_apiResponseFieldMarshaller, SharedDataApollo_apiResponseReader, SharedDataKotlinComparable, SharedDataApollo_apiScalarType, SharedDataRemoteDataSource, SharedDataKtor_client_coreHttpClientEngine, SharedDataKotlinx_coroutines_coreCoroutineScope, SharedDataLocalDataSource, SharedDataKotlinSuspendFunction1, SharedDataKotlinx_serialization_runtimeKSerializer, SharedDataDealsService, SharedDataKotlinIterator, SharedDataApollo_apiCustomTypeAdapter, SharedDataApollo_apiExecutionContext, SharedDataOkioSink, SharedDataOkioSource, SharedDataApollo_apiInputFieldMarshaller, SharedDataApollo_apiResponseWriter, SharedDataApollo_apiResponseReaderObjectReader, SharedDataApollo_apiResponseReaderListItemReader, SharedDataApollo_apiResponseReaderListReader, SharedDataKtor_client_coreHttpClientEngineCapability, SharedDataKotlinCoroutineContext, SharedDataKtor_ioCloseable, SharedDataApollo_runtime_kotlinNetworkTransport, SharedDataApollo_runtime_kotlinApolloRequestInterceptor, SharedDataApollo_runtime_kotlinApolloMutationCall, SharedDataApollo_apiMutation, SharedDataApollo_runtime_kotlinApolloQueryCall, SharedDataKotlinFunction, SharedDataKotlinx_serialization_runtimeEncoder, SharedDataKotlinx_serialization_runtimeSerialDescriptor, SharedDataKotlinx_serialization_runtimeSerializationStrategy, SharedDataKotlinx_serialization_runtimeDecoder, SharedDataKotlinx_serialization_runtimeDeserializationStrategy, SharedDataApollo_apiExecutionContextElement, SharedDataApollo_apiExecutionContextKey, SharedDataOkioBufferedSink, SharedDataApollo_apiInputFieldWriter, SharedDataApollo_apiResponseWriterListItemWriter, SharedDataApollo_apiResponseWriterListWriter, SharedDataKtor_utilsAttributes, SharedDataKotlinCoroutineContextKey, SharedDataKotlinCoroutineContextElement, SharedDataKotlinContinuation, SharedDataKotlinContinuationInterceptor, SharedDataKotlinx_coroutines_coreRunnable, SharedDataKotlinx_coroutines_coreFlow, SharedDataApollo_runtime_kotlinApolloInterceptorChain, SharedDataApollo_runtime_kotlinApolloCall, SharedDataKotlinx_serialization_runtimeCompositeEncoder, SharedDataKotlinx_serialization_runtimeSerialModule, SharedDataKotlinAnnotation, SharedDataKotlinx_serialization_runtimeCompositeDecoder, SharedDataApollo_apiInputFieldWriterListItemWriter, SharedDataApollo_apiInputFieldWriterListWriter, SharedDataKtor_client_coreHttpClientFeature, SharedDataKotlinSuspendFunction2, SharedDataKotlinx_serialization_runtimeSerialModuleCollector, SharedDataKotlinKClass, SharedDataKtor_httpHeaders, SharedDataKtor_httpHttpMessage, SharedDataKtor_ioByteReadChannel, SharedDataKtor_client_coreHttpRequest, SharedDataKtor_httpHttpMessageBuilder, SharedDataKotlinx_coroutines_coreJob, SharedDataKtor_httpParameters, SharedDataKotlinKDeclarationContainer, SharedDataKotlinKAnnotatedElement, SharedDataKotlinKClassifier, SharedDataKotlinMapEntry, SharedDataKtor_utilsStringValues, SharedDataKtor_ioReadSession, SharedDataKotlinx_coroutines_coreChildHandle, SharedDataKotlinx_coroutines_coreChildJob, SharedDataKotlinx_coroutines_coreDisposableHandle, SharedDataKotlinSequence, SharedDataKotlinx_coroutines_coreSelectClause0, SharedDataKtor_client_coreType, SharedDataKotlinKType, SharedDataKotlinx_coroutines_coreParentJob, SharedDataKotlinx_coroutines_coreSelectInstance, SharedDataKotlinSuspendFunction0, SharedDataKtor_ioObjectPool, SharedDataKtor_ioInput, SharedDataKotlinAppendable, SharedDataKtor_ioOutput;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wnullability"

__attribute__((swift_name("KotlinBase")))
@interface SharedDataBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end;

@interface SharedDataBase (SharedDataBaseCopying) <NSCopying>
@end;

__attribute__((swift_name("KotlinMutableSet")))
@interface SharedDataMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end;

__attribute__((swift_name("KotlinMutableDictionary")))
@interface SharedDataMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end;

@interface NSError (NSErrorSharedDataKotlinException)
@property (readonly) id _Nullable kotlinException;
@end;

__attribute__((swift_name("KotlinNumber")))
@interface SharedDataNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end;

__attribute__((swift_name("KotlinByte")))
@interface SharedDataByte : SharedDataNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end;

__attribute__((swift_name("KotlinUByte")))
@interface SharedDataUByte : SharedDataNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end;

__attribute__((swift_name("KotlinShort")))
@interface SharedDataShort : SharedDataNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end;

__attribute__((swift_name("KotlinUShort")))
@interface SharedDataUShort : SharedDataNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end;

__attribute__((swift_name("KotlinInt")))
@interface SharedDataInt : SharedDataNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end;

__attribute__((swift_name("KotlinUInt")))
@interface SharedDataUInt : SharedDataNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end;

__attribute__((swift_name("KotlinLong")))
@interface SharedDataLong : SharedDataNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end;

__attribute__((swift_name("KotlinULong")))
@interface SharedDataULong : SharedDataNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end;

__attribute__((swift_name("KotlinFloat")))
@interface SharedDataFloat : SharedDataNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end;

__attribute__((swift_name("KotlinDouble")))
@interface SharedDataDouble : SharedDataNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end;

__attribute__((swift_name("KotlinBoolean")))
@interface SharedDataBoolean : SharedDataNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end;

__attribute__((swift_name("Kind")))
@protocol SharedDataKind
@required
@end;

__attribute__((swift_name("Eval")))
@interface SharedDataEval<__covariant A> : SharedDataBase <SharedDataKind>
- (A _Nullable)extract __attribute__((swift_name("extract()")));
- (SharedDataEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalAlways")))
@interface SharedDataEvalAlways<__covariant A> : SharedDataEval<A>
- (instancetype)initWithF:(A _Nullable (^)(void))f __attribute__((swift_name("init(f:)"))) __attribute__((objc_designated_initializer));
- (SharedDataEvalAlways<A> *)doCopyF:(A _Nullable (^)(void))f __attribute__((swift_name("doCopy(f:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (SharedDataEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalCompanion")))
@interface SharedDataEvalCompanion : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (SharedDataEvalAlways<id> *)alwaysF:(id _Nullable (^)(void))f __attribute__((swift_name("always(f:)")));
- (SharedDataEval<id> *)justA:(id _Nullable)a __attribute__((swift_name("just(a:)")));
- (SharedDataEvalLater<id> *)laterF:(id _Nullable (^)(void))f __attribute__((swift_name("later(f:)")));
- (SharedDataEvalNow<id> *)nowA:(id _Nullable)a __attribute__((swift_name("now(a:)")));
@property (readonly) SharedDataEval<SharedDataBoolean *> *False __attribute__((swift_name("False")));
@property (readonly) SharedDataEval<SharedDataInt *> *One __attribute__((swift_name("One")));
@property (readonly) SharedDataEval<SharedDataBoolean *> *True __attribute__((swift_name("True")));
@property (readonly) SharedDataEval<SharedDataKotlinUnit *> *Unit __attribute__((swift_name("Unit")));
@property (readonly) SharedDataEval<SharedDataInt *> *Zero __attribute__((swift_name("Zero")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalLater")))
@interface SharedDataEvalLater<__covariant A> : SharedDataEval<A>
- (instancetype)initWithF:(A _Nullable (^)(void))f __attribute__((swift_name("init(f:)"))) __attribute__((objc_designated_initializer));
- (SharedDataEvalLater<A> *)doCopyF:(A _Nullable (^)(void))f __attribute__((swift_name("doCopy(f:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (SharedDataEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@property (readonly, getter=value_) A _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalNow")))
@interface SharedDataEvalNow<__covariant A> : SharedDataEval<A>
- (instancetype)initWithValue:(A _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (A _Nullable)component1 __attribute__((swift_name("component1()")));
- (SharedDataEvalNow<A> *)doCopyValue:(A _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (SharedDataEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@property (readonly, getter=value_) A _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForTry")))
@interface SharedDataForTry : SharedDataBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForTry.Companion")))
@interface SharedDataForTryCompanion : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("MpTry")))
@interface SharedDataMpTry<__covariant A> : SharedDataBase <SharedDataKind>
- (SharedDataMpTry<id> *)apFf:(id<SharedDataKind>)ff __attribute__((swift_name("ap(ff:)")));
- (BOOL)existsPredicate:(SharedDataBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("exists(predicate:)")));
- (SharedDataMpTry<SharedDataKotlinThrowable *> *)failed __attribute__((swift_name("failed()")));
- (SharedDataMpTry<A> *)filterP:(SharedDataBoolean *(^)(A _Nullable))p __attribute__((swift_name("filter(p:)")));
- (SharedDataMpTry<id> *)flatMapF:(id<SharedDataKind> (^)(A _Nullable))f __attribute__((swift_name("flatMap(f:)")));
- (id _Nullable)foldIfFailure:(id _Nullable (^)(SharedDataKotlinThrowable *))ifFailure ifSuccess:(id _Nullable (^)(A _Nullable))ifSuccess __attribute__((swift_name("fold(ifFailure:ifSuccess:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, A _Nullable))operation __attribute__((swift_name("foldLeft(initial:operation:)")));
- (SharedDataEval<id> *)foldRightInitial:(SharedDataEval<id> *)initial operation:(SharedDataEval<id> *(^)(A _Nullable, SharedDataEval<id> *))operation __attribute__((swift_name("foldRight(initial:operation:)")));
- (BOOL)isFailure __attribute__((swift_name("isFailure()")));
- (BOOL)isSuccess __attribute__((swift_name("isSuccess()")));
- (SharedDataMpTry<id> *)mapF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("map(f:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTryCompanion")))
@interface SharedDataMpTryCompanion : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (SharedDataMpTry<id> *)invokeF:(id _Nullable (^)(void))f __attribute__((swift_name("invoke(f:)")));
- (SharedDataMpTry<id> *)justA:(id _Nullable)a __attribute__((swift_name("just(a:)")));
- (SharedDataMpTry<id> *)raiseE:(SharedDataKotlinThrowable *)e __attribute__((swift_name("raise(e:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTryFailure")))
@interface SharedDataMpTryFailure : SharedDataMpTry<SharedDataKotlinNothing *>
- (instancetype)initWithException:(SharedDataKotlinThrowable *)exception __attribute__((swift_name("init(exception:)"))) __attribute__((objc_designated_initializer));
- (SharedDataKotlinThrowable *)component1 __attribute__((swift_name("component1()")));
- (SharedDataMpTryFailure *)doCopyException:(SharedDataKotlinThrowable *)exception __attribute__((swift_name("doCopy(exception:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)existsPredicate:(SharedDataBoolean *(^)(SharedDataKotlinNothing *))predicate __attribute__((swift_name("exists(predicate:)")));
- (SharedDataMpTry<SharedDataKotlinNothing *> *)filterP:(SharedDataBoolean *(^)(SharedDataKotlinNothing *))p __attribute__((swift_name("filter(p:)")));
- (SharedDataMpTry<id> *)flatMapF:(id<SharedDataKind> (^)(SharedDataKotlinNothing *))f __attribute__((swift_name("flatMap(f:)")));
- (id _Nullable)foldIfFailure:(id _Nullable (^)(SharedDataKotlinThrowable *))ifFailure ifSuccess:(id _Nullable (^)(SharedDataKotlinNothing *))ifSuccess __attribute__((swift_name("fold(ifFailure:ifSuccess:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, SharedDataKotlinNothing *))operation __attribute__((swift_name("foldLeft(initial:operation:)")));
- (SharedDataEval<id> *)foldRightInitial:(SharedDataEval<id> *)initial operation:(SharedDataEval<id> *(^)(SharedDataKotlinNothing *, SharedDataEval<id> *))operation __attribute__((swift_name("foldRight(initial:operation:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isFailure __attribute__((swift_name("isFailure()")));
- (BOOL)isSuccess __attribute__((swift_name("isSuccess()")));
- (SharedDataMpTry<id> *)mapF:(id _Nullable (^)(SharedDataKotlinNothing *))f __attribute__((swift_name("map(f:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedDataKotlinThrowable *exception __attribute__((swift_name("exception")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTrySuccess")))
@interface SharedDataMpTrySuccess<__covariant A> : SharedDataMpTry<A>
- (instancetype)initWithValue:(A _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (A _Nullable)component1 __attribute__((swift_name("component1()")));
- (SharedDataMpTrySuccess<A> *)doCopyValue:(A _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isFailure __attribute__((swift_name("isFailure()")));
- (BOOL)isSuccess __attribute__((swift_name("isSuccess()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) A _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("KotlinThrowable")))
@interface SharedDataKotlinThrowable : SharedDataBase
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (SharedDataKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedDataKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
@end;

__attribute__((swift_name("KotlinException")))
@interface SharedDataKotlinException : SharedDataKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("TryException")))
@interface SharedDataTryException : SharedDataKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TryException.PredicateException")))
@interface SharedDataTryExceptionPredicateException : SharedDataTryException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (SharedDataTryExceptionPredicateException *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TryException.UnsupportedOperationException")))
@interface SharedDataTryExceptionUnsupportedOperationException : SharedDataTryException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (SharedDataTryExceptionUnsupportedOperationException *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((swift_name("Logger")))
@protocol SharedDataLogger
@required
- (void)logTag:(NSString *)tag message:(NSString *)message __attribute__((swift_name("log(tag:message:)")));
@end;

__attribute__((swift_name("ModuleConfig")))
@protocol SharedDataModuleConfig
@required
@property id<SharedDataNetConfig> netConfig __attribute__((swift_name("netConfig")));
@end;

__attribute__((swift_name("NetConfig")))
@protocol SharedDataNetConfig
@required
@property NSString *pathDeals __attribute__((swift_name("pathDeals")));
@property NSString *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetConfigImpl")))
@interface SharedDataNetConfigImpl : SharedDataBase <SharedDataNetConfig>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)netConfigImpl __attribute__((swift_name("init()")));
@property NSString *pathDeals __attribute__((swift_name("pathDeals")));
@property NSString *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("RemoteRepoGraphQl")))
@protocol SharedDataRemoteRepoGraphQl
@required
- (void)fetchUserCBId:(NSString *)id success:(void (^)(SharedDataUserQueryData *))success error:(void (^)(SharedDataKotlinThrowable *))error __attribute__((swift_name("fetchUserCB(id:success:error:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServiceLocatorShared")))
@interface SharedDataServiceLocatorShared : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serviceLocatorShared __attribute__((swift_name("init()")));
@property (readonly) id<SharedDataRemoteRepoGraphQl> graph __attribute__((swift_name("graph")));
@property (readonly) id<SharedDataDealsUseCase> uc __attribute__((swift_name("uc")));
@end;

__attribute__((swift_name("LocalDataSource")))
@protocol SharedDataLocalDataSource
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocalDataSourceCompanion")))
@interface SharedDataLocalDataSourceCompanion : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Destination")))
@interface SharedDataDestination : SharedDataBase
- (instancetype)initWithDestinationId:(int32_t)destinationId destinationName:(NSString *)destinationName image:(NSString *)image price:(SharedDataPrice *)price searchUrl:(NSString *)searchUrl startDate:(NSString *)startDate timePeriod:(NSString *)timePeriod __attribute__((swift_name("init(destinationId:destinationName:image:price:searchUrl:startDate:timePeriod:)"))) __attribute__((objc_designated_initializer));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (SharedDataPrice *)component4 __attribute__((swift_name("component4()")));
- (NSString *)component5 __attribute__((swift_name("component5()")));
- (NSString *)component6 __attribute__((swift_name("component6()")));
- (NSString *)component7 __attribute__((swift_name("component7()")));
- (SharedDataDestination *)doCopyDestinationId:(int32_t)destinationId destinationName:(NSString *)destinationName image:(NSString *)image price:(SharedDataPrice *)price searchUrl:(NSString *)searchUrl startDate:(NSString *)startDate timePeriod:(NSString *)timePeriod __attribute__((swift_name("doCopy(destinationId:destinationName:image:price:searchUrl:startDate:timePeriod:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t destinationId __attribute__((swift_name("destinationId")));
@property (readonly) NSString *destinationName __attribute__((swift_name("destinationName")));
@property (readonly) NSString *image __attribute__((swift_name("image")));
@property (readonly) SharedDataPrice *price __attribute__((swift_name("price")));
@property (readonly) NSString *searchUrl __attribute__((swift_name("searchUrl")));
@property (readonly) NSString *startDate __attribute__((swift_name("startDate")));
@property (readonly) NSString *timePeriod __attribute__((swift_name("timePeriod")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Price")))
@interface SharedDataPrice : SharedDataBase
- (instancetype)initWithAmount:(double)amount currency:(NSString *)currency __attribute__((swift_name("init(amount:currency:)"))) __attribute__((objc_designated_initializer));
- (double)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (SharedDataPrice *)doCopyAmount:(double)amount currency:(NSString *)currency __attribute__((swift_name("doCopy(amount:currency:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) double amount __attribute__((swift_name("amount")));
@property (readonly) NSString *currency __attribute__((swift_name("currency")));
@end;

__attribute__((swift_name("RemoteDataSource")))
@protocol SharedDataRemoteDataSource
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemoteDataSourceCompanion")))
@interface SharedDataRemoteDataSourceCompanion : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("DealsService")))
@protocol SharedDataDealsService
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DealsServiceCompanion")))
@interface SharedDataDealsServiceCompanion : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("DealsUseCase")))
@protocol SharedDataDealsUseCase
@required
- (void)getDestinationsCbSuccess:(void (^)(NSArray<id> *))success error:(void (^)(SharedDataKotlinThrowable *))error __attribute__((swift_name("getDestinationsCb(success:error:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DealsUseCaseCompanion")))
@interface SharedDataDealsUseCaseCompanion : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("Apollo_apiOperation")))
@protocol SharedDataApollo_apiOperation
@required
- (SharedDataOkioByteString *)composeRequestBody __attribute__((swift_name("composeRequestBody()")));
- (SharedDataOkioByteString *)composeRequestBodyScalarTypeAdapters:(SharedDataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(scalarTypeAdapters:)")));
- (id<SharedDataApollo_apiOperationName>)name __attribute__((swift_name("name()")));
- (NSString *)operationId __attribute__((swift_name("operationId()")));
- (SharedDataApollo_apiResponse<id> *)parseSource:(id<SharedDataOkioBufferedSource>)source __attribute__((swift_name("parse(source:)")));
- (SharedDataApollo_apiResponse<id> *)parseSource:(id<SharedDataOkioBufferedSource>)source scalarTypeAdapters:(SharedDataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(source:scalarTypeAdapters:)")));
- (SharedDataApollo_apiResponse<id> *)parseByteString:(SharedDataOkioByteString *)byteString __attribute__((swift_name("parse(byteString:)")));
- (SharedDataApollo_apiResponse<id> *)parseByteString:(SharedDataOkioByteString *)byteString scalarTypeAdapters:(SharedDataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(byteString:scalarTypeAdapters:)")));
- (NSString *)queryDocument __attribute__((swift_name("queryDocument()")));
- (id<SharedDataApollo_apiResponseFieldMapper>)responseFieldMapper __attribute__((swift_name("responseFieldMapper()")));
- (SharedDataApollo_apiOperationVariables *)variables __attribute__((swift_name("variables()")));
- (id _Nullable)wrapDataData:(id<SharedDataApollo_apiOperationData> _Nullable)data __attribute__((swift_name("wrapData(data:)")));
@end;

__attribute__((swift_name("Apollo_apiQuery")))
@protocol SharedDataApollo_apiQuery <SharedDataApollo_apiOperation>
@required
- (SharedDataOkioByteString *)composeRequestBodyAutoPersistQueries:(BOOL)autoPersistQueries withQueryDocument:(BOOL)withQueryDocument scalarTypeAdapters:(SharedDataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(autoPersistQueries:withQueryDocument:scalarTypeAdapters:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery")))
@interface SharedDataUserQuery : SharedDataBase <SharedDataApollo_apiQuery>
- (instancetype)initWithId:(SharedDataApollo_apiInput<NSString *> *)id __attribute__((swift_name("init(id:)"))) __attribute__((objc_designated_initializer));
- (SharedDataApollo_apiInput<NSString *> *)component1 __attribute__((swift_name("component1()")));
- (SharedDataOkioByteString *)composeRequestBody __attribute__((swift_name("composeRequestBody()")));
- (SharedDataOkioByteString *)composeRequestBodyScalarTypeAdapters:(SharedDataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(scalarTypeAdapters:)")));
- (SharedDataOkioByteString *)composeRequestBodyAutoPersistQueries:(BOOL)autoPersistQueries withQueryDocument:(BOOL)withQueryDocument scalarTypeAdapters:(SharedDataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(autoPersistQueries:withQueryDocument:scalarTypeAdapters:)")));
- (SharedDataUserQuery *)doCopyId:(SharedDataApollo_apiInput<NSString *> *)id __attribute__((swift_name("doCopy(id:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<SharedDataApollo_apiOperationName>)name __attribute__((swift_name("name()")));
- (NSString *)operationId __attribute__((swift_name("operationId()")));
- (SharedDataApollo_apiResponse<SharedDataUserQueryData *> *)parseSource:(id<SharedDataOkioBufferedSource>)source __attribute__((swift_name("parse(source:)")));
- (SharedDataApollo_apiResponse<SharedDataUserQueryData *> *)parseSource:(id<SharedDataOkioBufferedSource>)source scalarTypeAdapters:(SharedDataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(source:scalarTypeAdapters:)")));
- (SharedDataApollo_apiResponse<SharedDataUserQueryData *> *)parseByteString:(SharedDataOkioByteString *)byteString __attribute__((swift_name("parse(byteString:)")));
- (SharedDataApollo_apiResponse<SharedDataUserQueryData *> *)parseByteString:(SharedDataOkioByteString *)byteString scalarTypeAdapters:(SharedDataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(byteString:scalarTypeAdapters:)")));
- (NSString *)queryDocument __attribute__((swift_name("queryDocument()")));
- (id<SharedDataApollo_apiResponseFieldMapper>)responseFieldMapper __attribute__((swift_name("responseFieldMapper()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (SharedDataApollo_apiOperationVariables *)variables __attribute__((swift_name("variables()")));
- (SharedDataUserQueryData * _Nullable)wrapDataData:(SharedDataUserQueryData * _Nullable)data __attribute__((swift_name("wrapData(data:)")));
@property (readonly) SharedDataApollo_apiInput<NSString *> *id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.Companion")))
@interface SharedDataUserQueryCompanion : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (readonly) NSString *OPERATION_ID __attribute__((swift_name("OPERATION_ID")));
@property (readonly) id<SharedDataApollo_apiOperationName> OPERATION_NAME __attribute__((swift_name("OPERATION_NAME")));
@property (readonly) NSString *QUERY_DOCUMENT __attribute__((swift_name("QUERY_DOCUMENT")));
@end;

__attribute__((swift_name("Apollo_apiOperationData")))
@protocol SharedDataApollo_apiOperationData
@required
- (id<SharedDataApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.Data")))
@interface SharedDataUserQueryData : SharedDataBase <SharedDataApollo_apiOperationData>
- (instancetype)initWithUser:(SharedDataUserQueryUser * _Nullable)user __attribute__((swift_name("init(user:)"))) __attribute__((objc_designated_initializer));
- (SharedDataUserQueryUser * _Nullable)component1 __attribute__((swift_name("component1()")));
- (SharedDataUserQueryData *)doCopyUser:(SharedDataUserQueryUser * _Nullable)user __attribute__((swift_name("doCopy(user:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<SharedDataApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedDataUserQueryUser * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.DataCompanion")))
@interface SharedDataUserQueryDataCompanion : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<SharedDataApollo_apiResponseFieldMapper>)Mapper __attribute__((swift_name("Mapper()")));
- (SharedDataUserQueryData *)invokeReader:(id<SharedDataApollo_apiResponseReader>)reader __attribute__((swift_name("invoke(reader:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.Hobby")))
@interface SharedDataUserQueryHobby : SharedDataBase
- (instancetype)initWith__typename:(NSString *)__typename description:(NSString * _Nullable)description title:(NSString * _Nullable)title __attribute__((swift_name("init(__typename:description:title:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (SharedDataUserQueryHobby *)doCopy__typename:(NSString *)__typename description:(NSString * _Nullable)description title:(NSString * _Nullable)title __attribute__((swift_name("doCopy(__typename:description:title:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<SharedDataApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *__typename __attribute__((swift_name("__typename")));
@property (readonly, getter=description_) NSString * _Nullable description __attribute__((swift_name("description")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.HobbyCompanion")))
@interface SharedDataUserQueryHobbyCompanion : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<SharedDataApollo_apiResponseFieldMapper>)Mapper __attribute__((swift_name("Mapper()")));
- (SharedDataUserQueryHobby *)invokeReader:(id<SharedDataApollo_apiResponseReader>)reader __attribute__((swift_name("invoke(reader:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.User")))
@interface SharedDataUserQueryUser : SharedDataBase
- (instancetype)initWith__typename:(NSString *)__typename id:(NSString * _Nullable)id name:(NSString * _Nullable)name age:(SharedDataInt * _Nullable)age hobbies:(NSArray<id> * _Nullable)hobbies __attribute__((swift_name("init(__typename:id:name:age:hobbies:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (SharedDataInt * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSArray<id> * _Nullable)component5 __attribute__((swift_name("component5()")));
- (SharedDataUserQueryUser *)doCopy__typename:(NSString *)__typename id:(NSString * _Nullable)id name:(NSString * _Nullable)name age:(SharedDataInt * _Nullable)age hobbies:(NSArray<id> * _Nullable)hobbies __attribute__((swift_name("doCopy(__typename:id:name:age:hobbies:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<SharedDataApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *__typename __attribute__((swift_name("__typename")));
@property (readonly) SharedDataInt * _Nullable age __attribute__((swift_name("age")));
@property (readonly) NSArray<id> * _Nullable hobbies __attribute__((swift_name("hobbies")));
@property (readonly) NSString * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.UserCompanion")))
@interface SharedDataUserQueryUserCompanion : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<SharedDataApollo_apiResponseFieldMapper>)Mapper __attribute__((swift_name("Mapper()")));
- (SharedDataUserQueryUser *)invokeReader:(id<SharedDataApollo_apiResponseReader>)reader __attribute__((swift_name("invoke(reader:)")));
@end;

__attribute__((swift_name("KotlinComparable")))
@protocol SharedDataKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("KotlinEnum")))
@interface SharedDataKotlinEnum<E> : SharedDataBase <SharedDataKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=name_) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end;

__attribute__((swift_name("Apollo_apiScalarType")))
@protocol SharedDataApollo_apiScalarType
@required
- (NSString *)className __attribute__((swift_name("className()")));
- (NSString *)typeName __attribute__((swift_name("typeName()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CustomType")))
@interface SharedDataCustomType : SharedDataKotlinEnum<SharedDataCustomType *> <SharedDataApollo_apiScalarType>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedDataCustomType *id __attribute__((swift_name("id")));
- (int32_t)compareToOther:(SharedDataCustomType *)other __attribute__((swift_name("compareTo(other:)")));
@end;

@interface SharedDataKotlinThrowable (Extensions)
- (SharedDataMpTry<id> *)failure __attribute__((swift_name("failure()")));
@end;

@interface SharedDataRemoteDataSourceCompanion (Extensions)
- (id<SharedDataRemoteDataSource>)createClientHttpEngine:(id<SharedDataKtor_client_coreHttpClientEngine>)clientHttpEngine netConfig:(id<SharedDataNetConfig>)netConfig __attribute__((swift_name("create(clientHttpEngine:netConfig:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTryKt")))
@interface SharedDataMpTryKt : SharedDataBase
+ (id _Nullable)identityA:(id _Nullable)a __attribute__((swift_name("identity(a:)")));
+ (SharedDataMpTry<id> *)fix:(id<SharedDataKind>)receiver __attribute__((swift_name("fix(_:)")));
+ (SharedDataMpTry<id> *)flatten:(id<SharedDataKind>)receiver __attribute__((swift_name("flatten(_:)")));
+ (id _Nullable)getOrDefault:(id<SharedDataKind>)receiver default:(id _Nullable (^)(void))default_ __attribute__((swift_name("getOrDefault(_:default:)")));
+ (id _Nullable)getOrElse:(id<SharedDataKind>)receiver default:(id _Nullable (^)(SharedDataKotlinThrowable *))default_ __attribute__((swift_name("getOrElse(_:default:)")));
+ (SharedDataMpTry<id> *)orElse:(id<SharedDataKind>)receiver f:(id<SharedDataKind> (^)(void))f __attribute__((swift_name("orElse(_:f:)")));
+ (id _Nullable)orNull:(id<SharedDataKind>)receiver __attribute__((swift_name("orNull(_:)")));
+ (SharedDataMpTry<id> *)recover:(id<SharedDataKind>)receiver f:(id _Nullable (^)(SharedDataKotlinThrowable *))f __attribute__((swift_name("recover(_:f:)")));
+ (SharedDataMpTry<id> *)recoverWith:(id<SharedDataKind>)receiver f:(id<SharedDataKind> (^)(SharedDataKotlinThrowable *))f __attribute__((swift_name("recoverWith(_:f:)")));
+ (SharedDataMpTry<id> *)rescue:(id<SharedDataKind>)receiver f:(id<SharedDataKind> (^)(SharedDataKotlinThrowable *))f __attribute__((swift_name("rescue(_:f:)")));
+ (SharedDataMpTry<id> *)success:(id _Nullable)receiver __attribute__((swift_name("success(_:)")));
+ (SharedDataMpTry<id> *)try_:(id _Nullable (^)(void))receiver __attribute__((swift_name("try_(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ActualObjKt")))
@interface SharedDataActualObjKt : SharedDataBase
+ (int64_t)expectedTimestamp __attribute__((swift_name("expectedTimestamp()")));
@property (class, readonly) id<SharedDataKtor_client_coreHttpClientEngine> clientEngine __attribute__((swift_name("clientEngine")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApolloRemoteRepositoryKt")))
@interface SharedDataApolloRemoteRepositoryKt : SharedDataBase
+ (SharedDataApollo_runtime_kotlinApolloClient *)createApolloClient __attribute__((swift_name("createApolloClient()")));
+ (id<SharedDataRemoteRepoGraphQl>)createRemoteRepoGraphQl __attribute__((swift_name("createRemoteRepoGraphQl()")));
+ (id<SharedDataRemoteRepoGraphQl>)createRemoteRepoGraphQlClient:(SharedDataApollo_runtime_kotlinApolloClient *)client __attribute__((swift_name("createRemoteRepoGraphQl(client:)")));
+ (id<SharedDataRemoteRepoGraphQl>)createRemoteRepoGraphQlClient:(SharedDataApollo_runtime_kotlinApolloClient *)client scope:(id<SharedDataKotlinx_coroutines_coreCoroutineScope>)scope __attribute__((swift_name("createRemoteRepoGraphQl(client:scope:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocalDataSourceKt")))
@interface SharedDataLocalDataSourceKt : SharedDataBase
+ (id<SharedDataLocalDataSource>)createLocalDataSource __attribute__((swift_name("createLocalDataSource()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemoteDataSourceKt")))
@interface SharedDataRemoteDataSourceKt : SharedDataBase
+ (id<SharedDataRemoteDataSource>)createRemoteDataSource __attribute__((swift_name("createRemoteDataSource()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetDataModelKt")))
@interface SharedDataNetDataModelKt : SharedDataBase
+ (id<SharedDataKotlinSuspendFunction1>)mapperListT:(id<SharedDataKotlinx_serialization_runtimeKSerializer>)t __attribute__((swift_name("mapperList(t:)")));
+ (NSMutableArray<id> *)filterResponseValues:(NSArray<id> *)receiver dtoMapper:(id _Nullable (^)(id _Nullable))dtoMapper __attribute__((swift_name("filterResponseValues(_:dtoMapper:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DealsServiceKt")))
@interface SharedDataDealsServiceKt : SharedDataBase
+ (id<SharedDataDealsService>)createDealsServiceLocalDataSource:(id<SharedDataLocalDataSource>)localDataSource remoteDataSource:(id<SharedDataRemoteDataSource>)remoteDataSource __attribute__((swift_name("createDealsService(localDataSource:remoteDataSource:)")));
+ (id<SharedDataDealsService>)createDealsServiceLocalDataSource:(id<SharedDataLocalDataSource>)localDataSource remoteDataSource:(id<SharedDataRemoteDataSource>)remoteDataSource scope:(id<SharedDataKotlinx_coroutines_coreCoroutineScope>)scope __attribute__((swift_name("createDealsService(localDataSource:remoteDataSource:scope:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DealsUseCaseKt")))
@interface SharedDataDealsUseCaseKt : SharedDataBase
+ (id<SharedDataDealsUseCase>)createDealsUseCaseDealsService:(id<SharedDataDealsService>)dealsService dealsMapper:(id _Nullable (^)(SharedDataDestination *))dealsMapper __attribute__((swift_name("createDealsUseCase(dealsService:dealsMapper:)")));
+ (id<SharedDataDealsUseCase>)createDealsUseCaseWithScopeDealsService:(id<SharedDataDealsService>)dealsService dealsMapper:(id _Nullable (^)(SharedDataDestination *))dealsMapper scope:(id<SharedDataKotlinx_coroutines_coreCoroutineScope>)scope __attribute__((swift_name("createDealsUseCaseWithScope(dealsService:dealsMapper:scope:)")));
+ (id<SharedDataDealsUseCase>)createDealsUseCase:(id<SharedDataDealsUseCase>)receiver dealsService:(id<SharedDataDealsService>)dealsService dealsMapper:(id _Nullable (^)(SharedDataDestination *))dealsMapper __attribute__((swift_name("createDealsUseCase(_:dealsService:dealsMapper:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface SharedDataKotlinUnit : SharedDataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface SharedDataKotlinNothing : SharedDataBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface SharedDataKotlinArray<T> : SharedDataBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(SharedDataInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<SharedDataKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("OkioByteString")))
@interface SharedDataOkioByteString : SharedDataBase <SharedDataKotlinComparable>
- (NSString *)base64 __attribute__((swift_name("base64()")));
- (NSString *)base64Url __attribute__((swift_name("base64Url()")));
- (int32_t)compareToOther:(SharedDataOkioByteString *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)endsWithSuffix:(SharedDataKotlinByteArray *)suffix __attribute__((swift_name("endsWith(suffix:)")));
- (BOOL)endsWithSuffix_:(SharedDataOkioByteString *)suffix __attribute__((swift_name("endsWith(suffix_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)hex __attribute__((swift_name("hex()")));
- (int32_t)indexOfOther:(SharedDataKotlinByteArray *)other fromIndex:(int32_t)fromIndex __attribute__((swift_name("indexOf(other:fromIndex:)")));
- (int32_t)indexOfOther:(SharedDataOkioByteString *)other fromIndex_:(int32_t)fromIndex __attribute__((swift_name("indexOf(other:fromIndex_:)")));
- (int32_t)lastIndexOfOther:(SharedDataKotlinByteArray *)other fromIndex:(int32_t)fromIndex __attribute__((swift_name("lastIndexOf(other:fromIndex:)")));
- (int32_t)lastIndexOfOther:(SharedDataOkioByteString *)other fromIndex_:(int32_t)fromIndex __attribute__((swift_name("lastIndexOf(other:fromIndex_:)")));
- (BOOL)rangeEqualsOffset:(int32_t)offset other:(SharedDataKotlinByteArray *)other otherOffset:(int32_t)otherOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:other:otherOffset:byteCount:)")));
- (BOOL)rangeEqualsOffset:(int32_t)offset other:(SharedDataOkioByteString *)other otherOffset:(int32_t)otherOffset byteCount_:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:other:otherOffset:byteCount_:)")));
- (BOOL)startsWithPrefix:(SharedDataKotlinByteArray *)prefix __attribute__((swift_name("startsWith(prefix:)")));
- (BOOL)startsWithPrefix_:(SharedDataOkioByteString *)prefix __attribute__((swift_name("startsWith(prefix_:)")));
- (SharedDataOkioByteString *)substringBeginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("substring(beginIndex:endIndex:)")));
- (SharedDataOkioByteString *)toAsciiLowercase __attribute__((swift_name("toAsciiLowercase()")));
- (SharedDataOkioByteString *)toAsciiUppercase __attribute__((swift_name("toAsciiUppercase()")));
- (SharedDataKotlinByteArray *)toByteArray __attribute__((swift_name("toByteArray()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (NSString *)utf8 __attribute__((swift_name("utf8()")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiScalarTypeAdapters")))
@interface SharedDataApollo_apiScalarTypeAdapters : SharedDataBase
- (instancetype)initWithCustomAdapters:(NSDictionary<id<SharedDataApollo_apiScalarType>, id<SharedDataApollo_apiCustomTypeAdapter>> *)customAdapters __attribute__((swift_name("init(customAdapters:)"))) __attribute__((objc_designated_initializer));
- (id<SharedDataApollo_apiCustomTypeAdapter>)adapterForScalarType:(id<SharedDataApollo_apiScalarType>)scalarType __attribute__((swift_name("adapterFor(scalarType:)")));
@property (readonly) NSDictionary<id<SharedDataApollo_apiScalarType>, id<SharedDataApollo_apiCustomTypeAdapter>> *customAdapters __attribute__((swift_name("customAdapters")));
@end;

__attribute__((swift_name("Apollo_apiOperationName")))
@protocol SharedDataApollo_apiOperationName
@required
- (NSString *)name __attribute__((swift_name("name()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponse")))
@interface SharedDataApollo_apiResponse<T> : SharedDataBase
- (instancetype)initWithBuilder:(SharedDataApollo_apiResponseBuilder<T> *)builder __attribute__((swift_name("init(builder:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithOperation:(id<SharedDataApollo_apiOperation>)operation data:(T _Nullable)data errors:(NSArray<SharedDataApollo_apiError *> * _Nullable)errors dependentKeys:(NSSet<NSString *> *)dependentKeys fromCache:(BOOL)fromCache extensions:(NSDictionary<NSString *, id> *)extensions executionContext:(id<SharedDataApollo_apiExecutionContext>)executionContext __attribute__((swift_name("init(operation:data:errors:dependentKeys:fromCache:extensions:executionContext:)"))) __attribute__((objc_designated_initializer));
- (id<SharedDataApollo_apiOperation>)component1 __attribute__((swift_name("component1()")));
- (T _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSArray<SharedDataApollo_apiError *> * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSSet<NSString *> *)component4 __attribute__((swift_name("component4()")));
- (BOOL)component5 __attribute__((swift_name("component5()")));
- (NSDictionary<NSString *, id> *)component6 __attribute__((swift_name("component6()")));
- (id<SharedDataApollo_apiExecutionContext>)component7 __attribute__((swift_name("component7()")));
- (SharedDataApollo_apiResponse<T> *)doCopyOperation:(id<SharedDataApollo_apiOperation>)operation data:(T _Nullable)data errors:(NSArray<SharedDataApollo_apiError *> * _Nullable)errors dependentKeys:(NSSet<NSString *> *)dependentKeys fromCache:(BOOL)fromCache extensions:(NSDictionary<NSString *, id> *)extensions executionContext:(id<SharedDataApollo_apiExecutionContext>)executionContext __attribute__((swift_name("doCopy(operation:data:errors:dependentKeys:fromCache:extensions:executionContext:)")));
- (T _Nullable)data __attribute__((swift_name("data()"))) __attribute__((deprecated("Use property instead")));
- (NSSet<NSString *> *)dependentKeys __attribute__((swift_name("dependentKeys()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSArray<SharedDataApollo_apiError *> * _Nullable)errors __attribute__((swift_name("errors()"))) __attribute__((deprecated("Use property instead")));
- (NSDictionary<NSString *, id> *)extensions __attribute__((swift_name("extensions()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)fromCache __attribute__((swift_name("fromCache()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)hasErrors __attribute__((swift_name("hasErrors()")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<SharedDataApollo_apiOperation>)operation __attribute__((swift_name("operation()"))) __attribute__((deprecated("Use property instead")));
- (SharedDataApollo_apiResponseBuilder<T> *)toBuilder __attribute__((swift_name("toBuilder()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=data_) T _Nullable data __attribute__((swift_name("data")));
@property (readonly, getter=dependentKeys_) NSSet<NSString *> *dependentKeys __attribute__((swift_name("dependentKeys")));
@property (readonly, getter=errors_) NSArray<SharedDataApollo_apiError *> * _Nullable errors __attribute__((swift_name("errors")));
@property (readonly) id<SharedDataApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly, getter=extensions_) NSDictionary<NSString *, id> *extensions __attribute__((swift_name("extensions")));
@property (readonly, getter=fromCache_) BOOL fromCache __attribute__((swift_name("fromCache")));
@property (readonly, getter=operation_) id<SharedDataApollo_apiOperation> operation __attribute__((swift_name("operation")));
@end;

__attribute__((swift_name("OkioSource")))
@protocol SharedDataOkioSource
@required
- (void)close __attribute__((swift_name("close()")));
- (int64_t)readSink:(SharedDataOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("read(sink:byteCount:)")));
- (SharedDataOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
@end;

__attribute__((swift_name("OkioBufferedSource")))
@protocol SharedDataOkioBufferedSource <SharedDataOkioSource>
@required
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (int64_t)indexOfB:(int8_t)b __attribute__((swift_name("indexOf(b:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(b:fromIndex:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex toIndex:(int64_t)toIndex __attribute__((swift_name("indexOf(b:fromIndex:toIndex:)")));
- (int64_t)indexOfBytes:(SharedDataOkioByteString *)bytes __attribute__((swift_name("indexOf(bytes:)")));
- (int64_t)indexOfBytes:(SharedDataOkioByteString *)bytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(bytes:fromIndex:)")));
- (int64_t)indexOfElementTargetBytes:(SharedDataOkioByteString *)targetBytes __attribute__((swift_name("indexOfElement(targetBytes:)")));
- (int64_t)indexOfElementTargetBytes:(SharedDataOkioByteString *)targetBytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOfElement(targetBytes:fromIndex:)")));
- (id<SharedDataOkioBufferedSource>)peek __attribute__((swift_name("peek()")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(SharedDataOkioByteString *)bytes __attribute__((swift_name("rangeEquals(offset:bytes:)")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(SharedDataOkioByteString *)bytes bytesOffset:(int32_t)bytesOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:bytes:bytesOffset:byteCount:)")));
- (int32_t)readSink:(SharedDataKotlinByteArray *)sink __attribute__((swift_name("read(sink:)")));
- (int32_t)readSink:(SharedDataKotlinByteArray *)sink offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("read(sink:offset:byteCount:)")));
- (int64_t)readAllSink:(id<SharedDataOkioSink>)sink __attribute__((swift_name("readAll(sink:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (SharedDataKotlinByteArray *)readByteArray __attribute__((swift_name("readByteArray()")));
- (SharedDataKotlinByteArray *)readByteArrayByteCount:(int64_t)byteCount __attribute__((swift_name("readByteArray(byteCount:)")));
- (SharedDataOkioByteString *)readByteString __attribute__((swift_name("readByteString()")));
- (SharedDataOkioByteString *)readByteStringByteCount:(int64_t)byteCount __attribute__((swift_name("readByteString(byteCount:)")));
- (int64_t)readDecimalLong __attribute__((swift_name("readDecimalLong()")));
- (void)readFullySink:(SharedDataKotlinByteArray *)sink __attribute__((swift_name("readFully(sink:)")));
- (void)readFullySink:(SharedDataOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readFully(sink:byteCount:)")));
- (int64_t)readHexadecimalUnsignedLong __attribute__((swift_name("readHexadecimalUnsignedLong()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int32_t)readIntLe __attribute__((swift_name("readIntLe()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int64_t)readLongLe __attribute__((swift_name("readLongLe()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (int16_t)readShortLe __attribute__((swift_name("readShortLe()")));
- (NSString *)readUtf8 __attribute__((swift_name("readUtf8()")));
- (NSString *)readUtf8ByteCount:(int64_t)byteCount __attribute__((swift_name("readUtf8(byteCount:)")));
- (int32_t)readUtf8CodePoint __attribute__((swift_name("readUtf8CodePoint()")));
- (NSString * _Nullable)readUtf8Line __attribute__((swift_name("readUtf8Line()")));
- (NSString *)readUtf8LineStrict __attribute__((swift_name("readUtf8LineStrict()")));
- (NSString *)readUtf8LineStrictLimit:(int64_t)limit __attribute__((swift_name("readUtf8LineStrict(limit:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (int32_t)selectOptions:(NSArray<SharedDataOkioByteString *> *)options __attribute__((swift_name("select(options:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
@property (readonly) SharedDataOkioBuffer *buffer __attribute__((swift_name("buffer")));
@end;

__attribute__((swift_name("Apollo_apiResponseFieldMapper")))
@protocol SharedDataApollo_apiResponseFieldMapper
@required
- (id _Nullable)mapResponseReader:(id<SharedDataApollo_apiResponseReader>)responseReader __attribute__((swift_name("map(responseReader:)")));
@end;

__attribute__((swift_name("Apollo_apiOperationVariables")))
@interface SharedDataApollo_apiOperationVariables : SharedDataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)marshal __attribute__((swift_name("marshal()")));
- (NSString *)marshalScalarTypeAdapters:(SharedDataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("marshal(scalarTypeAdapters:)")));
- (id<SharedDataApollo_apiInputFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSDictionary<NSString *, id> *)valueMap __attribute__((swift_name("valueMap()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiInput")))
@interface SharedDataApollo_apiInput<V> : SharedDataBase
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
@property (readonly) BOOL defined __attribute__((swift_name("defined")));
@property (readonly) V _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Apollo_apiResponseFieldMarshaller")))
@protocol SharedDataApollo_apiResponseFieldMarshaller
@required
- (void)marshalWriter:(id<SharedDataApollo_apiResponseWriter>)writer __attribute__((swift_name("marshal(writer:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseReader")))
@protocol SharedDataApollo_apiResponseReader
@required
- (SharedDataBoolean * _Nullable)readBooleanField:(SharedDataApollo_apiResponseField *)field __attribute__((swift_name("readBoolean(field:)")));
- (id _Nullable)readCustomTypeField:(SharedDataApollo_apiResponseFieldCustomTypeField *)field __attribute__((swift_name("readCustomType(field:)")));
- (SharedDataDouble * _Nullable)readDoubleField:(SharedDataApollo_apiResponseField *)field __attribute__((swift_name("readDouble(field:)")));
- (id _Nullable)readFragmentField:(SharedDataApollo_apiResponseField *)field block:(id (^)(id<SharedDataApollo_apiResponseReader>))block __attribute__((swift_name("readFragment(field:block:)")));
- (id _Nullable)readFragmentField:(SharedDataApollo_apiResponseField *)field objectReader:(id<SharedDataApollo_apiResponseReaderObjectReader>)objectReader __attribute__((swift_name("readFragment(field:objectReader:)")));
- (SharedDataInt * _Nullable)readIntField:(SharedDataApollo_apiResponseField *)field __attribute__((swift_name("readInt(field:)")));
- (NSArray<id> * _Nullable)readListField:(SharedDataApollo_apiResponseField *)field block:(id (^)(id<SharedDataApollo_apiResponseReaderListItemReader>))block __attribute__((swift_name("readList(field:block:)")));
- (NSArray<id> * _Nullable)readListField:(SharedDataApollo_apiResponseField *)field listReader:(id<SharedDataApollo_apiResponseReaderListReader>)listReader __attribute__((swift_name("readList(field:listReader:)")));
- (SharedDataLong * _Nullable)readLongField:(SharedDataApollo_apiResponseField *)field __attribute__((swift_name("readLong(field:)")));
- (id _Nullable)readObjectField:(SharedDataApollo_apiResponseField *)field block:(id (^)(id<SharedDataApollo_apiResponseReader>))block __attribute__((swift_name("readObject(field:block:)")));
- (id _Nullable)readObjectField:(SharedDataApollo_apiResponseField *)field objectReader:(id<SharedDataApollo_apiResponseReaderObjectReader>)objectReader __attribute__((swift_name("readObject(field:objectReader:)")));
- (NSString * _Nullable)readStringField:(SharedDataApollo_apiResponseField *)field __attribute__((swift_name("readString(field:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol SharedDataKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<SharedDataKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end;

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol SharedDataKtor_ioCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol SharedDataKtor_client_coreHttpClientEngine <SharedDataKotlinx_coroutines_coreCoroutineScope, SharedDataKtor_ioCloseable>
@required
- (void)installClient:(SharedDataKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) SharedDataKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) SharedDataKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<SharedDataKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtime_kotlinApolloClient")))
@interface SharedDataApollo_runtime_kotlinApolloClient : SharedDataBase
- (instancetype)initWithNetworkTransport:(id<SharedDataApollo_runtime_kotlinNetworkTransport>)networkTransport scalarTypeAdapters:(SharedDataApollo_apiScalarTypeAdapters *)scalarTypeAdapters interceptors:(NSArray<id<SharedDataApollo_runtime_kotlinApolloRequestInterceptor>> *)interceptors executionContext:(id<SharedDataApollo_apiExecutionContext>)executionContext __attribute__((swift_name("init(networkTransport:scalarTypeAdapters:interceptors:executionContext:)"))) __attribute__((objc_designated_initializer));
- (id<SharedDataApollo_runtime_kotlinApolloMutationCall>)mutateMutation:(id<SharedDataApollo_apiMutation>)mutation __attribute__((swift_name("mutate(mutation:)")));
- (id<SharedDataApollo_runtime_kotlinApolloQueryCall>)queryQuery:(id<SharedDataApollo_apiQuery>)query __attribute__((swift_name("query(query:)")));
@end;

__attribute__((swift_name("KotlinFunction")))
@protocol SharedDataKotlinFunction
@required
@end;

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol SharedDataKotlinSuspendFunction1 <SharedDataKotlinFunction>
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerializationStrategy")))
@protocol SharedDataKotlinx_serialization_runtimeSerializationStrategy
@required
- (void)serializeEncoder:(id<SharedDataKotlinx_serialization_runtimeEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<SharedDataKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeDeserializationStrategy")))
@protocol SharedDataKotlinx_serialization_runtimeDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<SharedDataKotlinx_serialization_runtimeDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (id _Nullable)patchDecoder:(id<SharedDataKotlinx_serialization_runtimeDecoder>)decoder old:(id _Nullable)old __attribute__((swift_name("patch(decoder:old:)")));
@property (readonly) id<SharedDataKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeKSerializer")))
@protocol SharedDataKotlinx_serialization_runtimeKSerializer <SharedDataKotlinx_serialization_runtimeSerializationStrategy, SharedDataKotlinx_serialization_runtimeDeserializationStrategy>
@required
@end;

__attribute__((swift_name("KotlinIterator")))
@protocol SharedDataKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface SharedDataKotlinByteArray : SharedDataBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(SharedDataByte *(^)(SharedDataInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (SharedDataKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("Apollo_apiCustomTypeAdapter")))
@protocol SharedDataApollo_apiCustomTypeAdapter
@required
- (id _Nullable)decodeValue:(SharedDataApollo_apiCustomTypeValue<id> *)value __attribute__((swift_name("decode(value:)")));
- (SharedDataApollo_apiCustomTypeValue<id> *)encodeValue:(id _Nullable)value __attribute__((swift_name("encode(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponseBuilder")))
@interface SharedDataApollo_apiResponseBuilder<T> : SharedDataBase
- (SharedDataApollo_apiResponse<T> *)build __attribute__((swift_name("build()")));
- (SharedDataApollo_apiResponseBuilder<T> *)dataData:(T _Nullable)data __attribute__((swift_name("data(data:)")));
- (SharedDataApollo_apiResponseBuilder<T> *)dependentKeysDependentKeys:(NSSet<NSString *> * _Nullable)dependentKeys __attribute__((swift_name("dependentKeys(dependentKeys:)")));
- (SharedDataApollo_apiResponseBuilder<T> *)errorsErrors:(NSArray<SharedDataApollo_apiError *> * _Nullable)errors __attribute__((swift_name("errors(errors:)")));
- (SharedDataApollo_apiResponseBuilder<T> *)executionContextExecutionContext:(id<SharedDataApollo_apiExecutionContext>)executionContext __attribute__((swift_name("executionContext(executionContext:)")));
- (SharedDataApollo_apiResponseBuilder<T> *)extensionsExtensions:(NSDictionary<NSString *, id> * _Nullable)extensions __attribute__((swift_name("extensions(extensions:)")));
- (SharedDataApollo_apiResponseBuilder<T> *)fromCacheFromCache:(BOOL)fromCache __attribute__((swift_name("fromCache(fromCache:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiError")))
@interface SharedDataApollo_apiError : SharedDataBase
- (instancetype)initWithMessage:(NSString *)message locations:(NSArray<SharedDataApollo_apiErrorLocation *> *)locations customAttributes:(NSDictionary<NSString *, id> *)customAttributes __attribute__((swift_name("init(message:locations:customAttributes:)"))) __attribute__((objc_designated_initializer));
- (NSDictionary<NSString *, id> *)customAttributes __attribute__((swift_name("customAttributes()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSArray<SharedDataApollo_apiErrorLocation *> *)locations __attribute__((swift_name("locations()"))) __attribute__((deprecated("Use property instead")));
- (NSString * _Nullable)message __attribute__((swift_name("message()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=customAttributes_) NSDictionary<NSString *, id> *customAttributes __attribute__((swift_name("customAttributes")));
@property (readonly, getter=locations_) NSArray<SharedDataApollo_apiErrorLocation *> *locations __attribute__((swift_name("locations")));
@property (readonly, getter=message_) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((swift_name("Apollo_apiExecutionContext")))
@protocol SharedDataApollo_apiExecutionContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<SharedDataApollo_apiExecutionContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<SharedDataApollo_apiExecutionContextElement> _Nullable)getKey:(id<SharedDataApollo_apiExecutionContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<SharedDataApollo_apiExecutionContext>)minusKeyKey:(id<SharedDataApollo_apiExecutionContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<SharedDataApollo_apiExecutionContext>)plusContext:(id<SharedDataApollo_apiExecutionContext>)context __attribute__((swift_name("plus(context:)")));
@end;

__attribute__((swift_name("OkioSink")))
@protocol SharedDataOkioSink
@required
- (void)close __attribute__((swift_name("close()")));
- (void)flush __attribute__((swift_name("flush()")));
- (SharedDataOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
- (void)writeSource:(SharedDataOkioBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
@end;

__attribute__((swift_name("OkioBufferedSink")))
@protocol SharedDataOkioBufferedSink <SharedDataOkioSink>
@required
- (id<SharedDataOkioBufferedSink>)emit __attribute__((swift_name("emit()")));
- (id<SharedDataOkioBufferedSink>)emitCompleteSegments __attribute__((swift_name("emitCompleteSegments()")));
- (id<SharedDataOkioBufferedSink>)writeSource:(SharedDataKotlinByteArray *)source __attribute__((swift_name("write(source:)")));
- (id<SharedDataOkioBufferedSink>)writeSource:(SharedDataKotlinByteArray *)source offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(source:offset:byteCount:)")));
- (id<SharedDataOkioBufferedSink>)writeByteString:(SharedDataOkioByteString *)byteString __attribute__((swift_name("write(byteString:)")));
- (id<SharedDataOkioBufferedSink>)writeByteString:(SharedDataOkioByteString *)byteString offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(byteString:offset:byteCount:)")));
- (id<SharedDataOkioBufferedSink>)writeSource:(id<SharedDataOkioSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (int64_t)writeAllSource:(id<SharedDataOkioSource>)source __attribute__((swift_name("writeAll(source:)")));
- (id<SharedDataOkioBufferedSink>)writeByteB:(int32_t)b __attribute__((swift_name("writeByte(b:)")));
- (id<SharedDataOkioBufferedSink>)writeDecimalLongV:(int64_t)v __attribute__((swift_name("writeDecimalLong(v:)")));
- (id<SharedDataOkioBufferedSink>)writeHexadecimalUnsignedLongV:(int64_t)v __attribute__((swift_name("writeHexadecimalUnsignedLong(v:)")));
- (id<SharedDataOkioBufferedSink>)writeIntI:(int32_t)i __attribute__((swift_name("writeInt(i:)")));
- (id<SharedDataOkioBufferedSink>)writeIntLeI:(int32_t)i __attribute__((swift_name("writeIntLe(i:)")));
- (id<SharedDataOkioBufferedSink>)writeLongV:(int64_t)v __attribute__((swift_name("writeLong(v:)")));
- (id<SharedDataOkioBufferedSink>)writeLongLeV:(int64_t)v __attribute__((swift_name("writeLongLe(v:)")));
- (id<SharedDataOkioBufferedSink>)writeShortS:(int32_t)s __attribute__((swift_name("writeShort(s:)")));
- (id<SharedDataOkioBufferedSink>)writeShortLeS:(int32_t)s __attribute__((swift_name("writeShortLe(s:)")));
- (id<SharedDataOkioBufferedSink>)writeUtf8String:(NSString *)string __attribute__((swift_name("writeUtf8(string:)")));
- (id<SharedDataOkioBufferedSink>)writeUtf8String:(NSString *)string beginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("writeUtf8(string:beginIndex:endIndex:)")));
- (id<SharedDataOkioBufferedSink>)writeUtf8CodePointCodePoint:(int32_t)codePoint __attribute__((swift_name("writeUtf8CodePoint(codePoint:)")));
@property (readonly) SharedDataOkioBuffer *buffer __attribute__((swift_name("buffer")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OkioBuffer")))
@interface SharedDataOkioBuffer : SharedDataBase <SharedDataOkioBufferedSource, SharedDataOkioBufferedSink>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));
- (void)close __attribute__((swift_name("close()")));
- (int64_t)completeSegmentByteCount __attribute__((swift_name("completeSegmentByteCount()")));
- (SharedDataOkioBuffer *)doCopy __attribute__((swift_name("doCopy()")));
- (SharedDataOkioBuffer *)doCopyToOut:(SharedDataOkioBuffer *)out offset:(int64_t)offset __attribute__((swift_name("doCopyTo(out:offset:)")));
- (SharedDataOkioBuffer *)doCopyToOut:(SharedDataOkioBuffer *)out offset:(int64_t)offset byteCount:(int64_t)byteCount __attribute__((swift_name("doCopyTo(out:offset:byteCount:)")));
- (SharedDataOkioBuffer *)emit __attribute__((swift_name("emit()")));
- (SharedDataOkioBuffer *)emitCompleteSegments __attribute__((swift_name("emitCompleteSegments()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (void)flush __attribute__((swift_name("flush()")));
- (int8_t)getPos:(int64_t)pos __attribute__((swift_name("get(pos:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (int64_t)indexOfB:(int8_t)b __attribute__((swift_name("indexOf(b:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(b:fromIndex:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex toIndex:(int64_t)toIndex __attribute__((swift_name("indexOf(b:fromIndex:toIndex:)")));
- (int64_t)indexOfBytes:(SharedDataOkioByteString *)bytes __attribute__((swift_name("indexOf(bytes:)")));
- (int64_t)indexOfBytes:(SharedDataOkioByteString *)bytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(bytes:fromIndex:)")));
- (int64_t)indexOfElementTargetBytes:(SharedDataOkioByteString *)targetBytes __attribute__((swift_name("indexOfElement(targetBytes:)")));
- (int64_t)indexOfElementTargetBytes:(SharedDataOkioByteString *)targetBytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOfElement(targetBytes:fromIndex:)")));
- (id<SharedDataOkioBufferedSource>)peek __attribute__((swift_name("peek()")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(SharedDataOkioByteString *)bytes __attribute__((swift_name("rangeEquals(offset:bytes:)")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(SharedDataOkioByteString *)bytes bytesOffset:(int32_t)bytesOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:bytes:bytesOffset:byteCount:)")));
- (int32_t)readSink:(SharedDataKotlinByteArray *)sink __attribute__((swift_name("read(sink:)")));
- (int32_t)readSink:(SharedDataKotlinByteArray *)sink offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("read(sink:offset:byteCount:)")));
- (int64_t)readSink:(SharedDataOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("read(sink:byteCount:)")));
- (int64_t)readAllSink:(id<SharedDataOkioSink>)sink __attribute__((swift_name("readAll(sink:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (SharedDataKotlinByteArray *)readByteArray __attribute__((swift_name("readByteArray()")));
- (SharedDataKotlinByteArray *)readByteArrayByteCount:(int64_t)byteCount __attribute__((swift_name("readByteArray(byteCount:)")));
- (SharedDataOkioByteString *)readByteString __attribute__((swift_name("readByteString()")));
- (SharedDataOkioByteString *)readByteStringByteCount:(int64_t)byteCount __attribute__((swift_name("readByteString(byteCount:)")));
- (int64_t)readDecimalLong __attribute__((swift_name("readDecimalLong()")));
- (void)readFullySink:(SharedDataKotlinByteArray *)sink __attribute__((swift_name("readFully(sink:)")));
- (void)readFullySink:(SharedDataOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readFully(sink:byteCount:)")));
- (int64_t)readHexadecimalUnsignedLong __attribute__((swift_name("readHexadecimalUnsignedLong()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int32_t)readIntLe __attribute__((swift_name("readIntLe()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int64_t)readLongLe __attribute__((swift_name("readLongLe()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (int16_t)readShortLe __attribute__((swift_name("readShortLe()")));
- (NSString *)readUtf8 __attribute__((swift_name("readUtf8()")));
- (NSString *)readUtf8ByteCount:(int64_t)byteCount __attribute__((swift_name("readUtf8(byteCount:)")));
- (int32_t)readUtf8CodePoint __attribute__((swift_name("readUtf8CodePoint()")));
- (NSString * _Nullable)readUtf8Line __attribute__((swift_name("readUtf8Line()")));
- (NSString *)readUtf8LineStrict __attribute__((swift_name("readUtf8LineStrict()")));
- (NSString *)readUtf8LineStrictLimit:(int64_t)limit __attribute__((swift_name("readUtf8LineStrict(limit:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (int32_t)selectOptions:(NSArray<SharedDataOkioByteString *> *)options __attribute__((swift_name("select(options:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (SharedDataOkioByteString *)snapshot __attribute__((swift_name("snapshot()")));
- (SharedDataOkioByteString *)snapshotByteCount:(int32_t)byteCount __attribute__((swift_name("snapshot(byteCount:)")));
- (SharedDataOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (SharedDataOkioBuffer *)writeSource:(SharedDataKotlinByteArray *)source __attribute__((swift_name("write(source:)")));
- (SharedDataOkioBuffer *)writeSource:(SharedDataKotlinByteArray *)source offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(source:offset:byteCount:)")));
- (void)writeSource:(SharedDataOkioBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
- (SharedDataOkioBuffer *)writeByteString:(SharedDataOkioByteString *)byteString __attribute__((swift_name("write(byteString:)")));
- (SharedDataOkioBuffer *)writeByteString:(SharedDataOkioByteString *)byteString offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(byteString:offset:byteCount:)")));
- (SharedDataOkioBuffer *)writeSource:(id<SharedDataOkioSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (int64_t)writeAllSource:(id<SharedDataOkioSource>)source __attribute__((swift_name("writeAll(source:)")));
- (SharedDataOkioBuffer *)writeByteB:(int32_t)b __attribute__((swift_name("writeByte(b:)")));
- (SharedDataOkioBuffer *)writeDecimalLongV:(int64_t)v __attribute__((swift_name("writeDecimalLong(v:)")));
- (SharedDataOkioBuffer *)writeHexadecimalUnsignedLongV:(int64_t)v __attribute__((swift_name("writeHexadecimalUnsignedLong(v:)")));
- (SharedDataOkioBuffer *)writeIntI:(int32_t)i __attribute__((swift_name("writeInt(i:)")));
- (SharedDataOkioBuffer *)writeIntLeI:(int32_t)i __attribute__((swift_name("writeIntLe(i:)")));
- (SharedDataOkioBuffer *)writeLongV:(int64_t)v __attribute__((swift_name("writeLong(v:)")));
- (SharedDataOkioBuffer *)writeLongLeV:(int64_t)v __attribute__((swift_name("writeLongLe(v:)")));
- (SharedDataOkioBuffer *)writeShortS:(int32_t)s __attribute__((swift_name("writeShort(s:)")));
- (SharedDataOkioBuffer *)writeShortLeS:(int32_t)s __attribute__((swift_name("writeShortLe(s:)")));
- (SharedDataOkioBuffer *)writeUtf8String:(NSString *)string __attribute__((swift_name("writeUtf8(string:)")));
- (SharedDataOkioBuffer *)writeUtf8String:(NSString *)string beginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("writeUtf8(string:beginIndex:endIndex:)")));
- (SharedDataOkioBuffer *)writeUtf8CodePointCodePoint:(int32_t)codePoint __attribute__((swift_name("writeUtf8CodePoint(codePoint:)")));
@property (readonly) SharedDataOkioBuffer *buffer __attribute__((swift_name("buffer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("OkioTimeout")))
@interface SharedDataOkioTimeout : SharedDataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end;

__attribute__((swift_name("Apollo_apiInputFieldMarshaller")))
@protocol SharedDataApollo_apiInputFieldMarshaller
@required
- (void)marshalWriter_:(id<SharedDataApollo_apiInputFieldWriter>)writer __attribute__((swift_name("marshal(writer_:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseWriter")))
@protocol SharedDataApollo_apiResponseWriter
@required
- (void)writeBooleanField:(SharedDataApollo_apiResponseField *)field value:(SharedDataBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(field:value:)")));
- (void)writeCustomField:(SharedDataApollo_apiResponseFieldCustomTypeField *)field value:(id _Nullable)value __attribute__((swift_name("writeCustom(field:value:)")));
- (void)writeDoubleField:(SharedDataApollo_apiResponseField *)field value:(SharedDataDouble * _Nullable)value __attribute__((swift_name("writeDouble(field:value:)")));
- (void)writeFragmentMarshaller:(id<SharedDataApollo_apiResponseFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeFragment(marshaller:)")));
- (void)writeIntField:(SharedDataApollo_apiResponseField *)field value:(SharedDataInt * _Nullable)value __attribute__((swift_name("writeInt(field:value:)")));
- (void)writeListField:(SharedDataApollo_apiResponseField *)field values:(NSArray<id> * _Nullable)values block:(void (^)(NSArray<id> * _Nullable, id<SharedDataApollo_apiResponseWriterListItemWriter>))block __attribute__((swift_name("writeList(field:values:block:)")));
- (void)writeListField:(SharedDataApollo_apiResponseField *)field values:(NSArray<id> * _Nullable)values listWriter:(id<SharedDataApollo_apiResponseWriterListWriter>)listWriter __attribute__((swift_name("writeList(field:values:listWriter:)")));
- (void)writeLongField:(SharedDataApollo_apiResponseField *)field value:(SharedDataLong * _Nullable)value __attribute__((swift_name("writeLong(field:value:)")));
- (void)writeObjectField:(SharedDataApollo_apiResponseField *)field marshaller:(id<SharedDataApollo_apiResponseFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(field:marshaller:)")));
- (void)writeStringField:(SharedDataApollo_apiResponseField *)field value:(NSString * _Nullable)value __attribute__((swift_name("writeString(field:value:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseField")))
@interface SharedDataApollo_apiResponseField : SharedDataBase
- (NSDictionary<NSString *, id> *)arguments __attribute__((swift_name("arguments()"))) __attribute__((deprecated("Use property instead")));
- (NSArray<SharedDataApollo_apiResponseFieldCondition *> *)conditions __attribute__((swift_name("conditions()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSString *)fieldName __attribute__((swift_name("fieldName()"))) __attribute__((deprecated("Use property instead")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)optional __attribute__((swift_name("optional()"))) __attribute__((deprecated("Use property instead")));
- (id _Nullable)resolveArgumentName:(NSString *)name variables:(SharedDataApollo_apiOperationVariables *)variables __attribute__((swift_name("resolveArgument(name:variables:)")));
- (NSString *)responseName __attribute__((swift_name("responseName()"))) __attribute__((deprecated("Use property instead")));
- (SharedDataApollo_apiResponseFieldType *)type __attribute__((swift_name("type()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=arguments_) NSDictionary<NSString *, id> *arguments __attribute__((swift_name("arguments")));
@property (readonly, getter=conditions_) NSArray<SharedDataApollo_apiResponseFieldCondition *> *conditions __attribute__((swift_name("conditions")));
@property (readonly, getter=fieldName_) NSString *fieldName __attribute__((swift_name("fieldName")));
@property (readonly, getter=optional_) BOOL optional __attribute__((swift_name("optional")));
@property (readonly, getter=responseName_) NSString *responseName __attribute__((swift_name("responseName")));
@property (readonly, getter=type_) SharedDataApollo_apiResponseFieldType *type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponseField.CustomTypeField")))
@interface SharedDataApollo_apiResponseFieldCustomTypeField : SharedDataApollo_apiResponseField
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<SharedDataApollo_apiScalarType>)scalarType __attribute__((swift_name("scalarType()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=scalarType_) id<SharedDataApollo_apiScalarType> scalarType __attribute__((swift_name("scalarType")));
@end;

__attribute__((swift_name("Apollo_apiResponseReaderObjectReader")))
@protocol SharedDataApollo_apiResponseReaderObjectReader
@required
- (id)readReader:(id<SharedDataApollo_apiResponseReader>)reader __attribute__((swift_name("read(reader:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseReaderListItemReader")))
@protocol SharedDataApollo_apiResponseReaderListItemReader
@required
- (BOOL)readBoolean __attribute__((swift_name("readBoolean()")));
- (id)readCustomTypeScalarType:(id<SharedDataApollo_apiScalarType>)scalarType __attribute__((swift_name("readCustomType(scalarType:)")));
- (double)readDouble __attribute__((swift_name("readDouble()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (NSArray<id> *)readListBlock:(id (^)(id<SharedDataApollo_apiResponseReaderListItemReader>))block __attribute__((swift_name("readList(block:)")));
- (NSArray<id> *)readListListReader:(id<SharedDataApollo_apiResponseReaderListReader>)listReader __attribute__((swift_name("readList(listReader:)")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (id)readObjectBlock:(id (^)(id<SharedDataApollo_apiResponseReader>))block __attribute__((swift_name("readObject(block:)")));
- (id)readObjectObjectReader:(id<SharedDataApollo_apiResponseReaderObjectReader>)objectReader __attribute__((swift_name("readObject(objectReader:)")));
- (NSString *)readString __attribute__((swift_name("readString()")));
@end;

__attribute__((swift_name("Apollo_apiResponseReaderListReader")))
@protocol SharedDataApollo_apiResponseReaderListReader
@required
- (id)readReader_:(id<SharedDataApollo_apiResponseReaderListItemReader>)reader __attribute__((swift_name("read(reader_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface SharedDataKtor_client_coreHttpClient : SharedDataBase <SharedDataKotlinx_coroutines_coreCoroutineScope, SharedDataKtor_ioCloseable>
- (instancetype)initWithEngine:(id<SharedDataKtor_client_coreHttpClientEngine>)engine userConfig:(SharedDataKtor_client_coreHttpClientConfig<SharedDataKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (SharedDataKtor_client_coreHttpClient *)configBlock:(void (^)(SharedDataKtor_client_coreHttpClientConfig<SharedDataKtor_client_coreHttpClientEngineConfig *> *))block __attribute__((swift_name("config(block:)")));
- (BOOL)isSupportedCapability:(id<SharedDataKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<SharedDataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<SharedDataKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) SharedDataKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher"))) __attribute__((unavailable("[dispatcher] is deprecated. Use coroutineContext instead.")));
@property (readonly) id<SharedDataKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) SharedDataKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) SharedDataKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) SharedDataKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) SharedDataKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) SharedDataKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface SharedDataKtor_client_coreHttpClientEngineConfig : SharedDataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property SharedDataKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property (readonly) SharedDataKotlinNothing *response __attribute__((swift_name("response"))) __attribute__((unavailable("Response config is deprecated. See [HttpPlainText] feature for charset configuration")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount")));
@end;

__attribute__((swift_name("KotlinCoroutineContext")))
@protocol SharedDataKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation_:(id _Nullable (^)(id _Nullable, id<SharedDataKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation_:)")));
- (id<SharedDataKotlinCoroutineContextElement> _Nullable)getKey_:(id<SharedDataKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key_:)")));
- (id<SharedDataKotlinCoroutineContext>)minusKeyKey_:(id<SharedDataKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key_:)")));
- (id<SharedDataKotlinCoroutineContext>)plusContext_:(id<SharedDataKotlinCoroutineContext>)context __attribute__((swift_name("plus(context_:)")));
@end;

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol SharedDataKotlinCoroutineContextElement <SharedDataKotlinCoroutineContext>
@required
@property (readonly) id<SharedDataKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface SharedDataKotlinAbstractCoroutineContextElement : SharedDataBase <SharedDataKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<SharedDataKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<SharedDataKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol SharedDataKotlinContinuationInterceptor <SharedDataKotlinCoroutineContextElement>
@required
- (id<SharedDataKotlinContinuation>)interceptContinuationContinuation:(id<SharedDataKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<SharedDataKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface SharedDataKotlinx_coroutines_coreCoroutineDispatcher : SharedDataKotlinAbstractCoroutineContextElement <SharedDataKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<SharedDataKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)dispatchContext:(id<SharedDataKotlinCoroutineContext>)context block:(id<SharedDataKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<SharedDataKotlinCoroutineContext>)context block:(id<SharedDataKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<SharedDataKotlinContinuation>)interceptContinuationContinuation:(id<SharedDataKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<SharedDataKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (SharedDataKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(SharedDataKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<SharedDataKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol SharedDataKtor_client_coreHttpClientEngineCapability
@required
@end;

__attribute__((swift_name("Apollo_runtime_kotlinNetworkTransport")))
@protocol SharedDataApollo_runtime_kotlinNetworkTransport
@required
- (id<SharedDataKotlinx_coroutines_coreFlow>)executeRequest:(SharedDataApollo_runtime_kotlinGraphQLRequest *)request __attribute__((swift_name("execute(request:)")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloRequestInterceptor")))
@protocol SharedDataApollo_runtime_kotlinApolloRequestInterceptor
@required
- (id<SharedDataKotlinx_coroutines_coreFlow>)interceptRequest:(SharedDataApollo_runtime_kotlinApolloRequest<id> *)request interceptorChain:(id<SharedDataApollo_runtime_kotlinApolloInterceptorChain>)interceptorChain __attribute__((swift_name("intercept(request:interceptorChain:)")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloCall")))
@protocol SharedDataApollo_runtime_kotlinApolloCall
@required
- (id<SharedDataKotlinx_coroutines_coreFlow>)execute __attribute__((swift_name("execute()")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloMutationCall")))
@protocol SharedDataApollo_runtime_kotlinApolloMutationCall <SharedDataApollo_runtime_kotlinApolloCall>
@required
@end;

__attribute__((swift_name("Apollo_apiMutation")))
@protocol SharedDataApollo_apiMutation <SharedDataApollo_apiOperation>
@required
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloQueryCall")))
@protocol SharedDataApollo_runtime_kotlinApolloQueryCall <SharedDataApollo_runtime_kotlinApolloCall>
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeEncoder")))
@protocol SharedDataKotlinx_serialization_runtimeEncoder
@required
- (id<SharedDataKotlinx_serialization_runtimeCompositeEncoder>)beginCollectionDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize typeSerializers:(SharedDataKotlinArray<id<SharedDataKotlinx_serialization_runtimeKSerializer>> *)typeSerializers __attribute__((swift_name("beginCollection(descriptor:collectionSize:typeSerializers:)")));
- (id<SharedDataKotlinx_serialization_runtimeCompositeEncoder>)beginStructureDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor typeSerializers:(SharedDataKotlinArray<id<SharedDataKotlinx_serialization_runtimeKSerializer>> *)typeSerializers __attribute__((swift_name("beginStructure(descriptor:typeSerializers:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));
- (void)encodeNull __attribute__((swift_name("encodeNull()")));
- (void)encodeNullableSerializableValueSerializer:(id<SharedDataKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<SharedDataKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
- (void)encodeUnit __attribute__((swift_name("encodeUnit()")));
@property (readonly) id<SharedDataKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialDescriptor")))
@protocol SharedDataKotlinx_serialization_runtimeSerialDescriptor
@required
- (NSArray<id<SharedDataKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (NSArray<id<SharedDataKotlinAnnotation>> *)getEntityAnnotations __attribute__((swift_name("getEntityAnnotations()"))) __attribute__((deprecated("Deprecated in the favour of 'annotations' property")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<SharedDataKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) SharedDataKotlinx_serialization_runtimeSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly, getter=name_) NSString *name __attribute__((swift_name("name"))) __attribute__((unavailable("name property deprecated in the favour of serialName")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeDecoder")))
@protocol SharedDataKotlinx_serialization_runtimeDecoder
@required
- (id<SharedDataKotlinx_serialization_runtimeCompositeDecoder>)beginStructureDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor typeParams:(SharedDataKotlinArray<id<SharedDataKotlinx_serialization_runtimeKSerializer>> *)typeParams __attribute__((swift_name("beginStructure(descriptor:typeParams:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));
- (SharedDataKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<SharedDataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<SharedDataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
- (void)decodeUnit __attribute__((swift_name("decodeUnit()")));
- (id _Nullable)updateNullableSerializableValueDeserializer:(id<SharedDataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateNullableSerializableValue(deserializer:old:)")));
- (id _Nullable)updateSerializableValueDeserializer:(id<SharedDataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateSerializableValue(deserializer:old:)")));
@property (readonly) id<SharedDataKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@property (readonly) SharedDataKotlinx_serialization_runtimeUpdateMode *updateMode __attribute__((swift_name("updateMode")));
@end;

__attribute__((swift_name("KotlinByteIterator")))
@interface SharedDataKotlinByteIterator : SharedDataBase <SharedDataKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedDataByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end;

__attribute__((swift_name("Apollo_apiCustomTypeValue")))
@interface SharedDataApollo_apiCustomTypeValue<T> : SharedDataBase
@property (readonly) T _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiError.Location")))
@interface SharedDataApollo_apiErrorLocation : SharedDataBase
- (instancetype)initWithLine:(int64_t)line column:(int64_t)column __attribute__((swift_name("init(line:column:)"))) __attribute__((objc_designated_initializer));
- (int64_t)column __attribute__((swift_name("column()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (int64_t)line __attribute__((swift_name("line()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=column_) int64_t column __attribute__((swift_name("column")));
@property (readonly, getter=line_) int64_t line __attribute__((swift_name("line")));
@end;

__attribute__((swift_name("Apollo_apiExecutionContextElement")))
@protocol SharedDataApollo_apiExecutionContextElement <SharedDataApollo_apiExecutionContext>
@required
@property (readonly) id<SharedDataApollo_apiExecutionContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("Apollo_apiExecutionContextKey")))
@protocol SharedDataApollo_apiExecutionContextKey
@required
@end;

__attribute__((swift_name("Apollo_apiInputFieldWriter")))
@protocol SharedDataApollo_apiInputFieldWriter
@required
- (void)writeBooleanFieldName:(NSString *)fieldName value:(SharedDataBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(fieldName:value:)")));
- (void)writeCustomFieldName:(NSString *)fieldName scalarType:(id<SharedDataApollo_apiScalarType>)scalarType value:(id _Nullable)value __attribute__((swift_name("writeCustom(fieldName:scalarType:value:)")));
- (void)writeDoubleFieldName:(NSString *)fieldName value:(SharedDataDouble * _Nullable)value __attribute__((swift_name("writeDouble(fieldName:value:)")));
- (void)writeIntFieldName:(NSString *)fieldName value:(SharedDataInt * _Nullable)value __attribute__((swift_name("writeInt(fieldName:value:)")));
- (void)writeListFieldName:(NSString *)fieldName block:(void (^)(id<SharedDataApollo_apiInputFieldWriterListItemWriter>))block __attribute__((swift_name("writeList(fieldName:block:)")));
- (void)writeListFieldName:(NSString *)fieldName listWriter:(id<SharedDataApollo_apiInputFieldWriterListWriter> _Nullable)listWriter __attribute__((swift_name("writeList(fieldName:listWriter:)")));
- (void)writeLongFieldName:(NSString *)fieldName value:(SharedDataLong * _Nullable)value __attribute__((swift_name("writeLong(fieldName:value:)")));
- (void)writeMapFieldName:(NSString *)fieldName value:(NSDictionary<NSString *, id> * _Nullable)value __attribute__((swift_name("writeMap(fieldName:value:)")));
- (void)writeNumberFieldName:(NSString *)fieldName value:(id _Nullable)value __attribute__((swift_name("writeNumber(fieldName:value:)")));
- (void)writeObjectFieldName:(NSString *)fieldName marshaller:(id<SharedDataApollo_apiInputFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(fieldName:marshaller:)")));
- (void)writeStringFieldName:(NSString *)fieldName value:(NSString * _Nullable)value __attribute__((swift_name("writeString(fieldName:value:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseWriterListItemWriter")))
@protocol SharedDataApollo_apiResponseWriterListItemWriter
@required
- (void)writeBooleanValue:(SharedDataBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(value:)")));
- (void)writeCustomScalarType:(id<SharedDataApollo_apiScalarType>)scalarType value:(id _Nullable)value __attribute__((swift_name("writeCustom(scalarType:value:)")));
- (void)writeDoubleValue:(SharedDataDouble * _Nullable)value __attribute__((swift_name("writeDouble(value:)")));
- (void)writeIntValue:(SharedDataInt * _Nullable)value __attribute__((swift_name("writeInt(value:)")));
- (void)writeListItems:(NSArray<id> * _Nullable)items block:(void (^)(NSArray<id> * _Nullable, id<SharedDataApollo_apiResponseWriterListItemWriter>))block __attribute__((swift_name("writeList(items:block:)")));
- (void)writeListItems:(NSArray<id> * _Nullable)items listWriter:(id<SharedDataApollo_apiResponseWriterListWriter>)listWriter __attribute__((swift_name("writeList(items:listWriter:)")));
- (void)writeLongValue:(SharedDataLong * _Nullable)value __attribute__((swift_name("writeLong(value:)")));
- (void)writeObjectMarshaller:(id<SharedDataApollo_apiResponseFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(marshaller:)")));
- (void)writeStringValue:(NSString * _Nullable)value __attribute__((swift_name("writeString(value:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseWriterListWriter")))
@protocol SharedDataApollo_apiResponseWriterListWriter
@required
- (void)writeItems:(NSArray<id> * _Nullable)items listItemWriter:(id<SharedDataApollo_apiResponseWriterListItemWriter>)listItemWriter __attribute__((swift_name("write(items:listItemWriter:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseField.Condition")))
@interface SharedDataApollo_apiResponseFieldCondition : SharedDataBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponseField.Type_")))
@interface SharedDataApollo_apiResponseFieldType : SharedDataKotlinEnum<SharedDataApollo_apiResponseFieldType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedDataApollo_apiResponseFieldType *string __attribute__((swift_name("string")));
@property (class, readonly) SharedDataApollo_apiResponseFieldType *int_ __attribute__((swift_name("int_")));
@property (class, readonly) SharedDataApollo_apiResponseFieldType *long_ __attribute__((swift_name("long_")));
@property (class, readonly) SharedDataApollo_apiResponseFieldType *double_ __attribute__((swift_name("double_")));
@property (class, readonly) SharedDataApollo_apiResponseFieldType *boolean __attribute__((swift_name("boolean")));
@property (class, readonly) SharedDataApollo_apiResponseFieldType *enum_ __attribute__((swift_name("enum_")));
@property (class, readonly) SharedDataApollo_apiResponseFieldType *object __attribute__((swift_name("object")));
@property (class, readonly) SharedDataApollo_apiResponseFieldType *list __attribute__((swift_name("list")));
@property (class, readonly) SharedDataApollo_apiResponseFieldType *custom __attribute__((swift_name("custom")));
@property (class, readonly) SharedDataApollo_apiResponseFieldType *fragment __attribute__((swift_name("fragment")));
@property (class, readonly) SharedDataApollo_apiResponseFieldType *fragments __attribute__((swift_name("fragments")));
- (int32_t)compareToOther:(SharedDataApollo_apiResponseFieldType *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface SharedDataKtor_client_coreHttpClientConfig<T> : SharedDataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedDataKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(SharedDataKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installFeature:(id<SharedDataKtor_client_coreHttpClientFeature>)feature configure:(void (^)(id))configure __attribute__((swift_name("install(feature:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(SharedDataKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(SharedDataKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end;

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol SharedDataKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(SharedDataKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(SharedDataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey__:(SharedDataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key__:)")));
- (id _Nullable)getOrNullKey:(SharedDataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(SharedDataKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey:(SharedDataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));
- (id)takeKey:(SharedDataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(SharedDataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<SharedDataKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end;

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface SharedDataKtor_utilsPipeline<TSubject, TContext> : SharedDataBase
- (instancetype)initWithPhase:(SharedDataKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<SharedDataKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(SharedDataKotlinArray<SharedDataKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(SharedDataKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));
- (void)insertPhaseAfterReference:(SharedDataKtor_utilsPipelinePhase *)reference phase:(SharedDataKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(SharedDataKtor_utilsPipelinePhase *)reference phase:(SharedDataKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(SharedDataKtor_utilsPipelinePhase *)phase block:(id<SharedDataKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (void)mergeFrom:(SharedDataKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
@property (readonly) id<SharedDataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<SharedDataKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface SharedDataKtor_client_coreHttpReceivePipeline : SharedDataKtor_utilsPipeline<SharedDataKtor_client_coreHttpResponse *, SharedDataKtor_client_coreHttpClientCall *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(SharedDataKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<SharedDataKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(SharedDataKotlinArray<SharedDataKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(SharedDataKtor_utilsPipeline<SharedDataKtor_client_coreHttpResponse *, SharedDataKtor_client_coreHttpClientCall *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface SharedDataKtor_client_coreHttpRequestPipeline : SharedDataKtor_utilsPipeline<id, SharedDataKtor_client_coreHttpRequestBuilder *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(SharedDataKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<SharedDataKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(SharedDataKotlinArray<SharedDataKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(SharedDataKtor_utilsPipeline<id, SharedDataKtor_client_coreHttpRequestBuilder *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface SharedDataKtor_client_coreHttpResponsePipeline : SharedDataKtor_utilsPipeline<SharedDataKtor_client_coreHttpResponseContainer *, SharedDataKtor_client_coreHttpClientCall *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(SharedDataKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<SharedDataKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(SharedDataKotlinArray<SharedDataKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(SharedDataKtor_utilsPipeline<SharedDataKtor_client_coreHttpResponseContainer *, SharedDataKtor_client_coreHttpClientCall *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface SharedDataKtor_client_coreHttpSendPipeline : SharedDataKtor_utilsPipeline<id, SharedDataKtor_client_coreHttpRequestBuilder *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(SharedDataKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<SharedDataKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(SharedDataKotlinArray<SharedDataKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(SharedDataKtor_utilsPipeline<id, SharedDataKtor_client_coreHttpRequestBuilder *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface SharedDataKtor_client_coreProxyConfig : SharedDataBase
- (instancetype)initWithUrl:(SharedDataKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedDataKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol SharedDataKotlinCoroutineContextKey
@required
@end;

__attribute__((swift_name("KotlinContinuation")))
@protocol SharedDataKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<SharedDataKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol SharedDataKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol SharedDataKotlinx_coroutines_coreFlow
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtime_kotlinGraphQLRequest")))
@interface SharedDataApollo_runtime_kotlinGraphQLRequest : SharedDataBase
- (instancetype)initWithOperationName:(NSString *)operationName operationId:(NSString *)operationId document:(NSString *)document variables:(NSString *)variables extensions:(NSString *)extensions __attribute__((swift_name("init(operationName:operationId:document:variables:extensions:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *document __attribute__((swift_name("document")));
@property (readonly) NSString *extensions __attribute__((swift_name("extensions")));
@property (readonly) NSString *operationId __attribute__((swift_name("operationId")));
@property (readonly) NSString *operationName __attribute__((swift_name("operationName")));
@property (readonly) NSString *variables __attribute__((swift_name("variables")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtime_kotlinApolloRequest")))
@interface SharedDataApollo_runtime_kotlinApolloRequest<T> : SharedDataBase
- (instancetype)initWithOperation:(id<SharedDataApollo_apiOperation>)operation scalarTypeAdapters:(SharedDataApollo_apiScalarTypeAdapters *)scalarTypeAdapters executionContext:(id<SharedDataApollo_apiExecutionContext>)executionContext __attribute__((swift_name("init(operation:scalarTypeAdapters:executionContext:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<SharedDataApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<SharedDataApollo_apiOperation> operation __attribute__((swift_name("operation")));
@property (readonly) SharedDataApollo_apiScalarTypeAdapters *scalarTypeAdapters __attribute__((swift_name("scalarTypeAdapters")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloInterceptorChain")))
@protocol SharedDataApollo_runtime_kotlinApolloInterceptorChain
@required
- (BOOL)canProceed __attribute__((swift_name("canProceed()")));
- (id<SharedDataKotlinx_coroutines_coreFlow>)proceedRequest:(SharedDataApollo_runtime_kotlinApolloRequest<id> *)request __attribute__((swift_name("proceed(request:)")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeCompositeEncoder")))
@protocol SharedDataKotlinx_serialization_runtimeCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (void)encodeIntElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));
- (void)encodeNonSerializableElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(id)value __attribute__((swift_name("encodeNonSerializableElement(descriptor:index:value:)"))) __attribute__((unavailable("This method is deprecated for removal. Please remove it from your implementation and delegate to default method instead")));
- (void)encodeNullableSerializableElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<SharedDataKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<SharedDataKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)encodeUnitElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeUnitElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) id<SharedDataKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialModule")))
@protocol SharedDataKotlinx_serialization_runtimeSerialModule
@required
- (void)dumpToCollector:(id<SharedDataKotlinx_serialization_runtimeSerialModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));
- (id<SharedDataKotlinx_serialization_runtimeKSerializer> _Nullable)getContextualKclass:(id<SharedDataKotlinKClass>)kclass __attribute__((swift_name("getContextual(kclass:)")));
- (id<SharedDataKotlinx_serialization_runtimeKSerializer> _Nullable)getPolymorphicBaseClass:(id<SharedDataKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));
- (id<SharedDataKotlinx_serialization_runtimeKSerializer> _Nullable)getPolymorphicBaseClass:(id<SharedDataKotlinKClass>)baseClass serializedClassName:(NSString *)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end;

__attribute__((swift_name("KotlinAnnotation")))
@protocol SharedDataKotlinAnnotation
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialKind")))
@interface SharedDataKotlinx_serialization_runtimeSerialKind : SharedDataBase
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeCompositeDecoder")))
@protocol SharedDataKotlinx_serialization_runtimeCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<SharedDataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:)")));
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<SharedDataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:)")));
- (int16_t)decodeShortElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)decodeUnitElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeUnitElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
- (id _Nullable)updateNullableSerializableElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<SharedDataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateNullableSerializableElement(descriptor:index:deserializer:old:)")));
- (id _Nullable)updateSerializableElementDescriptor:(id<SharedDataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<SharedDataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateSerializableElement(descriptor:index:deserializer:old:)")));
@property (readonly) id<SharedDataKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@property (readonly) SharedDataKotlinx_serialization_runtimeUpdateMode *updateMode __attribute__((swift_name("updateMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_runtimeUpdateMode")))
@interface SharedDataKotlinx_serialization_runtimeUpdateMode : SharedDataKotlinEnum<SharedDataKotlinx_serialization_runtimeUpdateMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedDataKotlinx_serialization_runtimeUpdateMode *banned __attribute__((swift_name("banned")));
@property (class, readonly) SharedDataKotlinx_serialization_runtimeUpdateMode *overwrite __attribute__((swift_name("overwrite")));
@property (class, readonly) SharedDataKotlinx_serialization_runtimeUpdateMode *update __attribute__((swift_name("update")));
- (int32_t)compareToOther:(SharedDataKotlinx_serialization_runtimeUpdateMode *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("Apollo_apiInputFieldWriterListItemWriter")))
@protocol SharedDataApollo_apiInputFieldWriterListItemWriter
@required
- (void)writeBooleanValue:(SharedDataBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(value:)")));
- (void)writeCustomScalarType:(id<SharedDataApollo_apiScalarType>)scalarType value:(id _Nullable)value __attribute__((swift_name("writeCustom(scalarType:value:)")));
- (void)writeDoubleValue:(SharedDataDouble * _Nullable)value __attribute__((swift_name("writeDouble(value:)")));
- (void)writeIntValue:(SharedDataInt * _Nullable)value __attribute__((swift_name("writeInt(value:)")));
- (void)writeListBlock:(void (^)(id<SharedDataApollo_apiInputFieldWriterListItemWriter>))block __attribute__((swift_name("writeList(block:)")));
- (void)writeListListWriter:(id<SharedDataApollo_apiInputFieldWriterListWriter> _Nullable)listWriter __attribute__((swift_name("writeList(listWriter:)")));
- (void)writeLongValue:(SharedDataLong * _Nullable)value __attribute__((swift_name("writeLong(value:)")));
- (void)writeMapValue:(NSDictionary<NSString *, id> * _Nullable)value __attribute__((swift_name("writeMap(value:)")));
- (void)writeNumberValue:(id _Nullable)value __attribute__((swift_name("writeNumber(value:)")));
- (void)writeObjectMarshaller_:(id<SharedDataApollo_apiInputFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(marshaller_:)")));
- (void)writeStringValue:(NSString * _Nullable)value __attribute__((swift_name("writeString(value:)")));
@end;

__attribute__((swift_name("Apollo_apiInputFieldWriterListWriter")))
@protocol SharedDataApollo_apiInputFieldWriterListWriter
@required
- (void)writeListItemWriter:(id<SharedDataApollo_apiInputFieldWriterListItemWriter>)listItemWriter __attribute__((swift_name("write(listItemWriter:)")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientFeature")))
@protocol SharedDataKtor_client_coreHttpClientFeature
@required
- (void)installFeature:(id)feature scope:(SharedDataKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(feature:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) SharedDataKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface SharedDataKtor_utilsAttributeKey<T> : SharedDataBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface SharedDataKtor_utilsPipelinePhase : SharedDataBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol SharedDataKotlinSuspendFunction2 <SharedDataKotlinFunction>
@required
@end;

__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol SharedDataKtor_httpHttpMessage
@required
@property (readonly) id<SharedDataKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface SharedDataKtor_client_coreHttpResponse : SharedDataBase <SharedDataKtor_httpHttpMessage, SharedDataKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedDataKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) id<SharedDataKtor_ioByteReadChannel> content __attribute__((swift_name("content")));
@property (readonly) SharedDataKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) SharedDataKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) SharedDataKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));
@property (readonly) SharedDataKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface SharedDataKtor_client_coreHttpClientCall : SharedDataBase <SharedDataKotlinx_coroutines_coreCoroutineScope>
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<SharedDataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) SharedDataKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<SharedDataKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<SharedDataKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));
@property (readonly) SharedDataKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end;

__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol SharedDataKtor_httpHttpMessageBuilder
@required
@property (readonly) SharedDataKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface SharedDataKtor_client_coreHttpRequestBuilder : SharedDataBase <SharedDataKtor_httpHttpMessageBuilder>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedDataKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));
- (id _Nullable)getCapabilityOrNullKey:(id<SharedDataKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (void)setAttributesBlock:(void (^)(id<SharedDataKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));
- (void)setCapabilityKey:(id<SharedDataKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));
- (SharedDataKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(SharedDataKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));
- (SharedDataKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(SharedDataKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));
- (void)urlBlock:(void (^)(SharedDataKtor_httpURLBuilder *, SharedDataKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));
@property (readonly) id<SharedDataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property id body __attribute__((swift_name("body")));
@property (readonly) id<SharedDataKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) SharedDataKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@property SharedDataKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) SharedDataKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface SharedDataKtor_client_coreHttpResponseContainer : SharedDataBase
- (instancetype)initWithExpectedType:(SharedDataKtor_client_coreTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (SharedDataKtor_client_coreTypeInfo *)component1 __attribute__((swift_name("component1()")));
- (id)component2 __attribute__((swift_name("component2()")));
- (SharedDataKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(SharedDataKtor_client_coreTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedDataKtor_client_coreTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface SharedDataKtor_httpUrl : SharedDataBase
- (instancetype)initWithProtocol:(SharedDataKtor_httpURLProtocol *)protocol host:(NSString *)host specifiedPort:(int32_t)specifiedPort encodedPath:(NSString *)encodedPath parameters:(id<SharedDataKtor_httpParameters>)parameters fragment:(NSString *)fragment user:(NSString * _Nullable)user password:(NSString * _Nullable)password trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:specifiedPort:encodedPath:parameters:fragment:user:password:trailingQuery:)"))) __attribute__((objc_designated_initializer));
- (SharedDataKtor_httpURLProtocol *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (id<SharedDataKtor_httpParameters>)component5 __attribute__((swift_name("component5()")));
- (NSString *)component6 __attribute__((swift_name("component6()")));
- (NSString * _Nullable)component7 __attribute__((swift_name("component7()")));
- (NSString * _Nullable)component8 __attribute__((swift_name("component8()")));
- (BOOL)component9 __attribute__((swift_name("component9()")));
- (SharedDataKtor_httpUrl *)doCopyProtocol:(SharedDataKtor_httpURLProtocol *)protocol host:(NSString *)host specifiedPort:(int32_t)specifiedPort encodedPath:(NSString *)encodedPath parameters:(id<SharedDataKtor_httpParameters>)parameters fragment:(NSString *)fragment user:(NSString * _Nullable)user password:(NSString * _Nullable)password trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("doCopy(protocol:host:specifiedPort:encodedPath:parameters:fragment:user:password:trailingQuery:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<SharedDataKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) SharedDataKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialModuleCollector")))
@protocol SharedDataKotlinx_serialization_runtimeSerialModuleCollector
@required
- (void)contextualKClass:(id<SharedDataKotlinKClass>)kClass serializer:(id<SharedDataKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<SharedDataKotlinKClass>)baseClass actualClass:(id<SharedDataKotlinKClass>)actualClass actualSerializer:(id<SharedDataKotlinx_serialization_runtimeKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
@end;

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol SharedDataKotlinKDeclarationContainer
@required
@end;

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol SharedDataKotlinKAnnotatedElement
@required
@end;

__attribute__((swift_name("KotlinKClassifier")))
@protocol SharedDataKotlinKClassifier
@required
@end;

__attribute__((swift_name("KotlinKClass")))
@protocol SharedDataKotlinKClass <SharedDataKotlinKDeclarationContainer, SharedDataKotlinKAnnotatedElement, SharedDataKotlinKClassifier>
@required
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end;

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol SharedDataKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<SharedDataKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end;

__attribute__((swift_name("Ktor_httpHeaders")))
@protocol SharedDataKtor_httpHeaders <SharedDataKtor_utilsStringValues>
@required
@end;

__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol SharedDataKtor_ioByteReadChannel
@required
- (BOOL)cancelCause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));
- (void)readSessionConsumer:(void (^)(id<SharedDataKtor_ioReadSession>))consumer __attribute__((swift_name("readSession(consumer:)"))) __attribute__((deprecated("Use read { } instead.")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) BOOL isClosedForWrite __attribute__((swift_name("isClosedForWrite")));
@property SharedDataKtor_ioByteOrder *readByteOrder __attribute__((swift_name("readByteOrder"))) __attribute__((unavailable("Setting byte order is no longer supported. Read/write in big endian and use reverseByteOrder() extensions.")));
@property (readonly) int64_t totalBytesRead __attribute__((swift_name("totalBytesRead"))) __attribute__((deprecated("Don't use byte count")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface SharedDataKtor_utilsGMTDate : SharedDataBase <SharedDataKotlinComparable>
- (int32_t)compareToOther:(SharedDataKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (SharedDataKtor_utilsWeekDay *)component4 __attribute__((swift_name("component4()")));
- (int32_t)component5 __attribute__((swift_name("component5()")));
- (int32_t)component6 __attribute__((swift_name("component6()")));
- (SharedDataKtor_utilsMonth *)component7 __attribute__((swift_name("component7()")));
- (int32_t)component8 __attribute__((swift_name("component8()")));
- (int64_t)component9 __attribute__((swift_name("component9()")));
- (SharedDataKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(SharedDataKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(SharedDataKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) SharedDataKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) SharedDataKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface SharedDataKtor_httpHttpStatusCode : SharedDataBase
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (SharedDataKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));
- (SharedDataKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=description_) NSString *description __attribute__((swift_name("description")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface SharedDataKtor_httpHttpProtocolVersion : SharedDataBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (SharedDataKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol SharedDataKtor_client_coreHttpRequest <SharedDataKtor_httpHttpMessage, SharedDataKotlinx_coroutines_coreCoroutineScope>
@required
@property (readonly) id<SharedDataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) SharedDataKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) SharedDataKtor_httpOutgoingContent *content __attribute__((swift_name("content")));
@property (readonly) SharedDataKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) SharedDataKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@interface SharedDataKtor_utilsStringValuesBuilder : SharedDataBase
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<SharedDataKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<SharedDataKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<SharedDataKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<SharedDataKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property BOOL built __attribute__((swift_name("built")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@property (readonly) SharedDataMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface SharedDataKtor_httpHeadersBuilder : SharedDataKtor_utilsStringValuesBuilder
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<SharedDataKtor_httpHeaders>)build __attribute__((swift_name("build()")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface SharedDataKtor_client_coreHttpRequestData : SharedDataBase
- (instancetype)initWithUrl:(SharedDataKtor_httpUrl *)url method:(SharedDataKtor_httpHttpMethod *)method headers:(id<SharedDataKtor_httpHeaders>)headers body:(SharedDataKtor_httpOutgoingContent *)body executionContext:(id<SharedDataKotlinx_coroutines_coreJob>)executionContext attributes:(id<SharedDataKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCapabilityOrNullKey:(id<SharedDataKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<SharedDataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) SharedDataKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<SharedDataKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<SharedDataKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) SharedDataKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) SharedDataKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface SharedDataKtor_httpURLBuilder : SharedDataBase
- (instancetype)initWithProtocol:(SharedDataKtor_httpURLProtocol *)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password encodedPath:(NSString *)encodedPath parameters:(SharedDataKtor_httpParametersBuilder *)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:encodedPath:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
- (SharedDataKtor_httpUrl *)build __attribute__((swift_name("build()")));
- (NSString *)buildString __attribute__((swift_name("buildString()")));
- (SharedDataKtor_httpURLBuilder *)pathComponents:(SharedDataKotlinArray<NSString *> *)components __attribute__((swift_name("path(components:)")));
- (SharedDataKtor_httpURLBuilder *)pathComponents_:(NSArray<NSString *> *)components __attribute__((swift_name("path(components_:)")));
@property NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) SharedDataKtor_httpParametersBuilder *parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property int32_t port __attribute__((swift_name("port")));
@property SharedDataKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol SharedDataKotlinx_coroutines_coreJob <SharedDataKotlinCoroutineContextElement>
@required
- (id<SharedDataKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<SharedDataKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause_:(SharedDataKotlinx_coroutines_coreCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));
- (SharedDataKotlinx_coroutines_coreCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<SharedDataKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(SharedDataKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));
- (id<SharedDataKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(SharedDataKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));
- (id<SharedDataKotlinx_coroutines_coreJob>)plusOther_:(id<SharedDataKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<SharedDataKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<SharedDataKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface SharedDataKtor_httpHttpMethod : SharedDataBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (SharedDataKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreTypeInfo")))
@interface SharedDataKtor_client_coreTypeInfo : SharedDataBase
- (instancetype)initWithType:(id<SharedDataKotlinKClass>)type reifiedType:(id<SharedDataKtor_client_coreType>)reifiedType kotlinType:(id<SharedDataKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (id<SharedDataKotlinKClass>)component1 __attribute__((swift_name("component1()")));
- (id<SharedDataKtor_client_coreType>)component2 __attribute__((swift_name("component2()")));
- (id<SharedDataKotlinKType> _Nullable)component3 __attribute__((swift_name("component3()")));
- (SharedDataKtor_client_coreTypeInfo *)doCopyType:(id<SharedDataKotlinKClass>)type reifiedType:(id<SharedDataKtor_client_coreType>)reifiedType kotlinType:(id<SharedDataKotlinKType> _Nullable)kotlinType __attribute__((swift_name("doCopy(type:reifiedType:kotlinType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<SharedDataKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<SharedDataKtor_client_coreType> reifiedType __attribute__((swift_name("reifiedType")));
@property (readonly) id<SharedDataKotlinKClass> type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface SharedDataKtor_httpURLProtocol : SharedDataBase
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (SharedDataKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("Ktor_httpParameters")))
@protocol SharedDataKtor_httpParameters <SharedDataKtor_utilsStringValues>
@required
@end;

__attribute__((swift_name("KotlinMapEntry")))
@protocol SharedDataKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly, getter=value_) id _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Ktor_ioReadSession")))
@protocol SharedDataKtor_ioReadSession
@required
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (SharedDataKtor_ioIoBuffer * _Nullable)requestAtLeast:(int32_t)atLeast __attribute__((swift_name("request(atLeast:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteOrder")))
@interface SharedDataKtor_ioByteOrder : SharedDataKotlinEnum<SharedDataKtor_ioByteOrder *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedDataKtor_ioByteOrder *bigEndian __attribute__((swift_name("bigEndian")));
@property (class, readonly) SharedDataKtor_ioByteOrder *littleEndian __attribute__((swift_name("littleEndian")));
- (int32_t)compareToOther:(SharedDataKtor_ioByteOrder *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface SharedDataKtor_utilsWeekDay : SharedDataKotlinEnum<SharedDataKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedDataKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) SharedDataKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) SharedDataKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) SharedDataKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) SharedDataKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) SharedDataKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) SharedDataKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
- (int32_t)compareToOther:(SharedDataKtor_utilsWeekDay *)other __attribute__((swift_name("compareTo(other:)")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface SharedDataKtor_utilsMonth : SharedDataKotlinEnum<SharedDataKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedDataKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) SharedDataKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) SharedDataKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) SharedDataKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) SharedDataKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) SharedDataKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) SharedDataKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) SharedDataKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) SharedDataKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) SharedDataKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) SharedDataKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) SharedDataKtor_utilsMonth *december __attribute__((swift_name("december")));
- (int32_t)compareToOther:(SharedDataKtor_utilsMonth *)other __attribute__((swift_name("compareTo(other:)")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface SharedDataKtor_httpOutgoingContent : SharedDataBase
- (id _Nullable)getPropertyKey:(SharedDataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));
- (void)setPropertyKey:(SharedDataKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));
@property (readonly) SharedDataLong * _Nullable contentLength __attribute__((swift_name("contentLength")));
@property (readonly) SharedDataKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) id<SharedDataKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) SharedDataKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpParametersBuilder")))
@interface SharedDataKtor_httpParametersBuilder : SharedDataKtor_utilsStringValuesBuilder
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<SharedDataKtor_httpParameters>)build __attribute__((swift_name("build()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol SharedDataKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol SharedDataKotlinx_coroutines_coreChildHandle <SharedDataKotlinx_coroutines_coreDisposableHandle>
@required
- (BOOL)childCancelledCause:(SharedDataKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol SharedDataKotlinx_coroutines_coreChildJob <SharedDataKotlinx_coroutines_coreJob>
@required
- (void)parentCancelledParentJob:(id<SharedDataKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end;

__attribute__((swift_name("KotlinRuntimeException")))
@interface SharedDataKotlinRuntimeException : SharedDataKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinIllegalStateException")))
@interface SharedDataKotlinIllegalStateException : SharedDataKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCancellationException")))
@interface SharedDataKotlinx_coroutines_coreCancellationException : SharedDataKotlinIllegalStateException
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithCause:(SharedDataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end;

__attribute__((swift_name("KotlinSequence")))
@protocol SharedDataKotlinSequence
@required
- (id<SharedDataKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol SharedDataKotlinx_coroutines_coreSelectClause0
@required
- (void)registerSelectClause0Select:(id<SharedDataKotlinx_coroutines_coreSelectInstance>)select block:(id<SharedDataKotlinSuspendFunction0>)block __attribute__((swift_name("registerSelectClause0(select:block:)")));
@end;

__attribute__((swift_name("Ktor_client_coreType")))
@protocol SharedDataKtor_client_coreType
@required
@end;

__attribute__((swift_name("KotlinKType")))
@protocol SharedDataKotlinKType
@required
@property (readonly, getter=arguments_) NSArray<SharedDataKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));
@property (readonly) id<SharedDataKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end;

__attribute__((swift_name("Ktor_ioBuffer")))
@interface SharedDataKtor_ioBuffer : SharedDataBase
- (instancetype)initWithMemory:(SharedDataKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer));
- (void)commitWrittenCount:(int32_t)count __attribute__((swift_name("commitWritten(count:)")));
- (int32_t)discardCount:(int32_t)count __attribute__((swift_name("discard(count:)"))) __attribute__((unavailable("Use discardExact instead.")));
- (int64_t)discardCount_:(int64_t)count __attribute__((swift_name("discard(count_:)"))) __attribute__((unavailable("Use discardExact instead.")));
- (void)discardExactCount:(int32_t)count __attribute__((swift_name("discardExact(count:)")));
- (SharedDataKtor_ioBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)duplicateToCopy:(SharedDataKtor_ioBuffer *)copy __attribute__((swift_name("duplicateTo(copy:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (void)reserveEndGapEndGap:(int32_t)endGap __attribute__((swift_name("reserveEndGap(endGap:)")));
- (void)reserveStartGapStartGap:(int32_t)startGap __attribute__((swift_name("reserveStartGap(startGap:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)resetForRead __attribute__((swift_name("resetForRead()")));
- (void)resetForWrite __attribute__((swift_name("resetForWrite()")));
- (void)resetForWriteLimit:(int32_t)limit __attribute__((swift_name("resetForWrite(limit:)")));
- (void)rewindCount:(int32_t)count __attribute__((swift_name("rewind(count:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeekByte __attribute__((swift_name("tryPeekByte()")));
- (int32_t)tryReadByte __attribute__((swift_name("tryReadByte()")));
- (void)writeByteValue:(int8_t)value __attribute__((swift_name("writeByte(value:)")));
@property id _Nullable attachment __attribute__((swift_name("attachment"))) __attribute__((deprecated("Will be removed. Inherit Buffer and add required fields instead.")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@property (readonly) int32_t endGap __attribute__((swift_name("endGap")));
@property (readonly) int32_t limit __attribute__((swift_name("limit")));
@property (readonly) SharedDataKtor_ioMemory *memory __attribute__((swift_name("memory")));
@property (readonly) int32_t readPosition __attribute__((swift_name("readPosition")));
@property (readonly) int32_t readRemaining __attribute__((swift_name("readRemaining")));
@property (readonly) int32_t startGap __attribute__((swift_name("startGap")));
@property (readonly) int32_t writePosition __attribute__((swift_name("writePosition")));
@property (readonly) int32_t writeRemaining __attribute__((swift_name("writeRemaining")));
@end;

__attribute__((swift_name("Ktor_ioChunkBuffer")))
@interface SharedDataKtor_ioChunkBuffer : SharedDataKtor_ioBuffer
- (instancetype)initWithMemory:(SharedDataKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (SharedDataKtor_ioChunkBuffer * _Nullable)cleanNext __attribute__((swift_name("cleanNext()")));
- (SharedDataKtor_ioChunkBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)releasePool:(id<SharedDataKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool:)")));
- (void)reset __attribute__((swift_name("reset()")));
@property (getter=next_) SharedDataKtor_ioChunkBuffer * _Nullable next __attribute__((swift_name("next")));
@property (readonly) SharedDataKtor_ioChunkBuffer * _Nullable origin __attribute__((swift_name("origin")));
@property (readonly) int32_t referenceCount __attribute__((swift_name("referenceCount")));
@end;

__attribute__((swift_name("Ktor_ioInput")))
@protocol SharedDataKtor_ioInput <SharedDataKtor_ioCloseable>
@required
- (int64_t)discardN_:(int64_t)n __attribute__((swift_name("discard(n_:)")));
- (int64_t)peekToDestination:(SharedDataKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
@property SharedDataKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((unavailable("Not supported anymore. All operations are big endian by default. Use readXXXLittleEndian or readXXX then X.reverseByteOrder() instead.")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@end;

__attribute__((swift_name("KotlinAppendable")))
@protocol SharedDataKotlinAppendable
@required
- (id<SharedDataKotlinAppendable>)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));
- (id<SharedDataKotlinAppendable>)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));
- (id<SharedDataKotlinAppendable>)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
@end;

__attribute__((swift_name("Ktor_ioOutput")))
@protocol SharedDataKtor_ioOutput <SharedDataKotlinAppendable, SharedDataKtor_ioCloseable>
@required
- (id<SharedDataKotlinAppendable>)appendCsq:(SharedDataKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("append(csq:start:end:)")));
- (void)flush __attribute__((swift_name("flush()")));
- (void)writeByteV:(int8_t)v __attribute__((swift_name("writeByte(v:)")));
@property SharedDataKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((deprecated("Write with writeXXXLittleEndian or do X.reverseByteOrder() and then writeXXX instead.")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioIoBuffer")))
@interface SharedDataKtor_ioIoBuffer : SharedDataKtor_ioChunkBuffer <SharedDataKtor_ioInput, SharedDataKtor_ioOutput>
- (instancetype)initWithContent:(void *)content contentCapacity:(int32_t)contentCapacity __attribute__((swift_name("init(content:contentCapacity:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use Buffer instead.")));
- (instancetype)initWithMemory:(SharedDataKtor_ioMemory *)memory origin:(SharedDataKtor_ioChunkBuffer * _Nullable)origin __attribute__((swift_name("init(memory:origin:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use Buffer instead.")));
- (id<SharedDataKotlinAppendable>)appendValue:(unichar)c __attribute__((swift_name("append(value:)")));
- (id<SharedDataKotlinAppendable>)appendCsq:(SharedDataKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("append(csq:start:end:)")));
- (id<SharedDataKotlinAppendable>)appendValue_:(id _Nullable)csq __attribute__((swift_name("append(value_:)")));
- (id<SharedDataKotlinAppendable>)appendValue:(id _Nullable)csq startIndex:(int32_t)start endIndex:(int32_t)end __attribute__((swift_name("append(value:startIndex:endIndex:)")));
- (int32_t)appendCharsCsq:(SharedDataKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("appendChars(csq:start:end:)")));
- (int32_t)appendCharsCsq:(id)csq start:(int32_t)start end_:(int32_t)end __attribute__((swift_name("appendChars(csq:start:end_:)")));
- (void)close __attribute__((swift_name("close()")));
- (int64_t)discardCount_:(int64_t)n __attribute__((swift_name("discard(count_:)")));
- (SharedDataKtor_ioIoBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)flush __attribute__((swift_name("flush()")));
- (SharedDataKtor_ioIoBuffer *)makeView __attribute__((swift_name("makeView()")));
- (int64_t)peekToDestination:(SharedDataKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int32_t)readDirectBlock:(SharedDataInt *(^)(id))block __attribute__((swift_name("readDirect(block:)")));
- (void)releasePool_:(id<SharedDataKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool_:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
- (void)writeByteValue:(int8_t)v __attribute__((swift_name("writeByte(value:)")));
- (int32_t)writeDirectBlock:(SharedDataInt *(^)(id))block __attribute__((swift_name("writeDirect(block:)")));
@property SharedDataKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((unavailable("Not supported anymore. All operations are big endian by default.")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@end;

__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface SharedDataKtor_httpHeaderValueWithParameters : SharedDataBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<SharedDataKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<SharedDataKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface SharedDataKtor_httpContentType : SharedDataKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<SharedDataKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<SharedDataKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)matchPattern:(SharedDataKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));
- (SharedDataKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));
- (SharedDataKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol SharedDataKotlinx_coroutines_coreParentJob <SharedDataKotlinx_coroutines_coreJob>
@required
- (SharedDataKotlinx_coroutines_coreCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol SharedDataKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnSelectHandle:(id<SharedDataKotlinx_coroutines_coreDisposableHandle>)handle __attribute__((swift_name("disposeOnSelect(handle:)")));
- (id _Nullable)performAtomicTrySelectDesc:(SharedDataKotlinx_coroutines_coreAtomicDesc *)desc __attribute__((swift_name("performAtomicTrySelect(desc:)")));
- (void)resumeSelectWithExceptionException:(SharedDataKotlinThrowable *)exception __attribute__((swift_name("resumeSelectWithException(exception:)")));
- (BOOL)trySelect __attribute__((swift_name("trySelect()")));
- (id _Nullable)trySelectOtherOtherOp:(SharedDataKotlinx_coroutines_corePrepareOp * _Nullable)otherOp __attribute__((swift_name("trySelectOther(otherOp:)")));
@property (readonly) id<SharedDataKotlinContinuation> completion __attribute__((swift_name("completion")));
@property (readonly) BOOL isSelected __attribute__((swift_name("isSelected")));
@end;

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol SharedDataKotlinSuspendFunction0 <SharedDataKotlinFunction>
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface SharedDataKotlinKTypeProjection : SharedDataBase
- (instancetype)initWithVariance:(SharedDataKotlinKVariance * _Nullable)variance type:(id<SharedDataKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
- (SharedDataKotlinKVariance * _Nullable)component1 __attribute__((swift_name("component1()")));
- (id<SharedDataKotlinKType> _Nullable)component2 __attribute__((swift_name("component2()")));
- (SharedDataKotlinKTypeProjection *)doCopyVariance:(SharedDataKotlinKVariance * _Nullable)variance type:(id<SharedDataKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<SharedDataKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) SharedDataKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory")))
@interface SharedDataKtor_ioMemory : SharedDataBase
- (instancetype)initWithPointer:(void *)pointer size:(int64_t)size __attribute__((swift_name("init(pointer:size:)"))) __attribute__((objc_designated_initializer));
- (void)doCopyToDestination:(SharedDataKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length destinationOffset:(int32_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset:)")));
- (void)doCopyToDestination:(SharedDataKtor_ioMemory *)destination offset:(int64_t)offset length:(int64_t)length destinationOffset_:(int64_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset_:)")));
- (int8_t)loadAtIndex:(int32_t)index __attribute__((swift_name("loadAt(index:)")));
- (int8_t)loadAtIndex_:(int64_t)index __attribute__((swift_name("loadAt(index_:)")));
- (SharedDataKtor_ioMemory *)sliceOffset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("slice(offset:length:)")));
- (SharedDataKtor_ioMemory *)sliceOffset:(int64_t)offset length_:(int64_t)length __attribute__((swift_name("slice(offset:length_:)")));
- (void)storeAtIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("storeAt(index:value:)")));
- (void)storeAtIndex:(int64_t)index value_:(int8_t)value __attribute__((swift_name("storeAt(index:value_:)")));
@property (readonly) void *pointer __attribute__((swift_name("pointer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@property (readonly) int32_t size32 __attribute__((swift_name("size32")));
@end;

__attribute__((swift_name("Ktor_ioObjectPool")))
@protocol SharedDataKtor_ioObjectPool <SharedDataKtor_ioCloseable>
@required
- (id)borrow __attribute__((swift_name("borrow()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)recycleInstance:(id)instance __attribute__((swift_name("recycle(instance:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinCharArray")))
@interface SharedDataKotlinCharArray : SharedDataBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(id (^)(SharedDataInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (unichar)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (SharedDataKotlinCharIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(unichar)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface SharedDataKtor_httpHeaderValueParam : SharedDataBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (SharedDataKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value __attribute__((swift_name("doCopy(name:value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicDesc")))
@interface SharedDataKotlinx_coroutines_coreAtomicDesc : SharedDataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(SharedDataKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)prepareOp:(SharedDataKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
@property SharedDataKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreOpDescriptor")))
@interface SharedDataKotlinx_coroutines_coreOpDescriptor : SharedDataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (BOOL)isEarlierThanThat:(SharedDataKotlinx_coroutines_coreOpDescriptor *)that __attribute__((swift_name("isEarlierThan(that:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedDataKotlinx_coroutines_coreAtomicOp<id> * _Nullable atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_corePrepareOp")))
@interface SharedDataKotlinx_coroutines_corePrepareOp : SharedDataKotlinx_coroutines_coreOpDescriptor
- (instancetype)initWithAffected:(SharedDataKotlinx_coroutines_coreLinkedListNode *)affected desc:(SharedDataKotlinx_coroutines_coreAbstractAtomicDesc *)desc atomicOp:(SharedDataKotlinx_coroutines_coreAtomicOp<id> *)atomicOp __attribute__((swift_name("init(affected:desc:atomicOp:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)finishPrepare __attribute__((swift_name("finishPrepare()")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
@property (readonly) SharedDataKotlinx_coroutines_coreLinkedListNode *affected __attribute__((swift_name("affected")));
@property (readonly) SharedDataKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) SharedDataKotlinx_coroutines_coreAbstractAtomicDesc *desc __attribute__((swift_name("desc")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface SharedDataKotlinKVariance : SharedDataKotlinEnum<SharedDataKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedDataKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) SharedDataKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) SharedDataKotlinKVariance *out __attribute__((swift_name("out")));
- (int32_t)compareToOther:(SharedDataKotlinKVariance *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("KotlinCharIterator")))
@interface SharedDataKotlinCharIterator : SharedDataBase <SharedDataKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id)next __attribute__((swift_name("next()")));
- (unichar)nextChar __attribute__((swift_name("nextChar()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicOp")))
@interface SharedDataKotlinx_coroutines_coreAtomicOp<__contravariant T> : SharedDataKotlinx_coroutines_coreOpDescriptor
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeAffected:(T _Nullable)affected failure:(id _Nullable)failure __attribute__((swift_name("complete(affected:failure:)")));
- (id _Nullable)decideDecision:(id _Nullable)decision __attribute__((swift_name("decide(decision:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (id _Nullable)prepareAffected:(T _Nullable)affected __attribute__((swift_name("prepare(affected:)")));
@property (readonly) SharedDataKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) BOOL isDecided __attribute__((swift_name("isDecided")));
@property (readonly) int64_t opSequence __attribute__((swift_name("opSequence")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLinkedListNode")))
@interface SharedDataKotlinx_coroutines_coreLinkedListNode : SharedDataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)addLastNode:(SharedDataKotlinx_coroutines_coreLinkedListNode *)node __attribute__((swift_name("addLast(node:)")));
- (BOOL)addLastIfNode:(SharedDataKotlinx_coroutines_coreLinkedListNode *)node condition:(SharedDataBoolean *(^)(void))condition __attribute__((swift_name("addLastIf(node:condition:)")));
- (BOOL)addLastIfPrevNode:(SharedDataKotlinx_coroutines_coreLinkedListNode *)node predicate:(SharedDataBoolean *(^)(SharedDataKotlinx_coroutines_coreLinkedListNode *))predicate __attribute__((swift_name("addLastIfPrev(node:predicate:)")));
- (BOOL)addLastIfPrevAndIfNode:(SharedDataKotlinx_coroutines_coreLinkedListNode *)node predicate:(SharedDataBoolean *(^)(SharedDataKotlinx_coroutines_coreLinkedListNode *))predicate condition:(SharedDataBoolean *(^)(void))condition __attribute__((swift_name("addLastIfPrevAndIf(node:predicate:condition:)")));
- (BOOL)addOneIfEmptyNode:(SharedDataKotlinx_coroutines_coreLinkedListNode *)node __attribute__((swift_name("addOneIfEmpty(node:)")));
- (void)helpRemove __attribute__((swift_name("helpRemove()")));
- (BOOL)remove __attribute__((swift_name("remove()")));
- (id _Nullable)removeFirstIfIsInstanceOfOrPeekIfPredicate:(SharedDataBoolean *(^)(id _Nullable))predicate __attribute__((swift_name("removeFirstIfIsInstanceOfOrPeekIf(predicate:)")));
- (SharedDataKotlinx_coroutines_coreLinkedListNode * _Nullable)removeFirstOrNull __attribute__((swift_name("removeFirstOrNull()")));
@property (readonly) BOOL isRemoved __attribute__((swift_name("isRemoved")));
@property (readonly) SharedDataKotlinx_coroutines_coreLinkedListNode *nextNode __attribute__((swift_name("nextNode")));
@property (readonly) SharedDataKotlinx_coroutines_coreLinkedListNode *prevNode __attribute__((swift_name("prevNode")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAbstractAtomicDesc")))
@interface SharedDataKotlinx_coroutines_coreAbstractAtomicDesc : SharedDataKotlinx_coroutines_coreAtomicDesc
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(SharedDataKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)failureAffected:(SharedDataKotlinx_coroutines_coreLinkedListNode *)affected __attribute__((swift_name("failure(affected:)")));
- (void)finishOnSuccessAffected:(SharedDataKotlinx_coroutines_coreLinkedListNode *)affected next:(SharedDataKotlinx_coroutines_coreLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(SharedDataKotlinx_coroutines_corePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (void)onComplete __attribute__((swift_name("onComplete()")));
- (id _Nullable)onPreparePrepareOp:(SharedDataKotlinx_coroutines_corePrepareOp *)prepareOp __attribute__((swift_name("onPrepare(prepareOp:)")));
- (id _Nullable)prepareOp:(SharedDataKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
- (BOOL)retryAffected:(SharedDataKotlinx_coroutines_coreLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
@property (readonly) SharedDataKotlinx_coroutines_coreLinkedListNode *affectedNode __attribute__((swift_name("affectedNode")));
@end;

#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
