#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class KmpdataEval<__covariant A>, KmpdataEvalAlways<__covariant A>, KmpdataEvalLater<__covariant A>, KmpdataEvalNow<__covariant A>, KmpdataKotlinUnit, KmpdataMpTry<__covariant A>, KmpdataKotlinThrowable, KmpdataMpTryFailure, KmpdataKotlinNothing, KmpdataMpTrySuccess<__covariant A>, KmpdataKotlinArray<T>, KmpdataKotlinException, KmpdataTryException, KmpdataTryExceptionPredicateException, KmpdataTryExceptionUnsupportedOperationException, KmpdataUserQueryData, KmpdataPrice, KmpdataDestination, KmpdataOkioByteString, KmpdataApollo_apiScalarTypeAdapters, KmpdataApollo_apiResponse<T>, KmpdataApollo_apiOperationVariables, KmpdataApollo_apiInput<V>, KmpdataUserQuery, KmpdataUserQueryUser, KmpdataUserQueryHobby, KmpdataKotlinEnum<E>, KmpdataCustomType, KmpdataRemoteDataSourceCompanion, KmpdataApollo_runtime_kotlinApolloClient, KmpdataKotlinByteArray, KmpdataApollo_apiResponseBuilder<T>, KmpdataApollo_apiError, KmpdataOkioBuffer, KmpdataOkioTimeout, KmpdataApollo_apiResponseField, KmpdataApollo_apiResponseFieldCustomTypeField, KmpdataKtor_client_coreHttpClient, KmpdataKtor_client_coreHttpClientEngineConfig, KmpdataKotlinx_coroutines_coreCoroutineDispatcher, KmpdataKotlinByteIterator, KmpdataApollo_apiCustomTypeValue<T>, KmpdataApollo_apiErrorLocation, KmpdataApollo_apiResponseFieldCondition, KmpdataApollo_apiResponseFieldType, KmpdataKtor_client_coreHttpClientConfig<T>, KmpdataKtor_client_coreHttpReceivePipeline, KmpdataKtor_client_coreHttpRequestPipeline, KmpdataKtor_client_coreHttpResponsePipeline, KmpdataKtor_client_coreHttpSendPipeline, KmpdataKtor_client_coreProxyConfig, KmpdataKotlinAbstractCoroutineContextElement, KmpdataApollo_runtime_kotlinGraphQLRequest, KmpdataApollo_runtime_kotlinApolloRequest<T>, KmpdataKotlinx_serialization_runtimeSerialKind, KmpdataKotlinx_serialization_runtimeUpdateMode, KmpdataKtor_utilsAttributeKey<T>, KmpdataKtor_utilsPipelinePhase, KmpdataKtor_utilsPipeline<TSubject, TContext>, KmpdataKtor_client_coreHttpResponse, KmpdataKtor_client_coreHttpClientCall, KmpdataKtor_client_coreHttpRequestBuilder, KmpdataKtor_client_coreHttpResponseContainer, KmpdataKtor_httpUrl, KmpdataKtor_utilsGMTDate, KmpdataKtor_httpHttpStatusCode, KmpdataKtor_httpHttpProtocolVersion, KmpdataKtor_httpHeadersBuilder, KmpdataKtor_client_coreHttpRequestData, KmpdataKtor_httpURLBuilder, KmpdataKtor_httpHttpMethod, KmpdataKtor_client_coreTypeInfo, KmpdataKtor_httpURLProtocol, KmpdataKtor_ioByteOrder, KmpdataKtor_utilsWeekDay, KmpdataKtor_utilsMonth, KmpdataKtor_httpOutgoingContent, KmpdataKtor_utilsStringValuesBuilder, KmpdataKtor_httpParametersBuilder, KmpdataKotlinx_coroutines_coreCancellationException, KmpdataKtor_ioIoBuffer, KmpdataKtor_httpContentType, KmpdataKotlinRuntimeException, KmpdataKotlinIllegalStateException, KmpdataKotlinKTypeProjection, KmpdataKtor_ioMemory, KmpdataKtor_ioBuffer, KmpdataKtor_ioChunkBuffer, KmpdataKotlinCharArray, KmpdataKtor_httpHeaderValueParam, KmpdataKtor_httpHeaderValueWithParameters, KmpdataKotlinx_coroutines_coreAtomicDesc, KmpdataKotlinx_coroutines_corePrepareOp, KmpdataKotlinKVariance, KmpdataKotlinCharIterator, KmpdataKotlinx_coroutines_coreAtomicOp<__contravariant T>, KmpdataKotlinx_coroutines_coreOpDescriptor, KmpdataKotlinx_coroutines_coreLinkedListNode, KmpdataKotlinx_coroutines_coreAbstractAtomicDesc;

@protocol KmpdataKind, KmpdataNetConfig, KmpdataRemoteRepoGraphQl, KmpdataDealsUseCase, KmpdataApollo_apiOperationName, KmpdataOkioBufferedSource, KmpdataApollo_apiResponseFieldMapper, KmpdataApollo_apiOperationData, KmpdataApollo_apiOperation, KmpdataApollo_apiQuery, KmpdataApollo_apiResponseFieldMarshaller, KmpdataApollo_apiResponseReader, KmpdataKotlinComparable, KmpdataApollo_apiScalarType, KmpdataRemoteDataSource, KmpdataKtor_client_coreHttpClientEngine, KmpdataKotlinx_coroutines_coreCoroutineScope, KmpdataLocalDataSource, KmpdataKotlinSuspendFunction1, KmpdataKotlinx_serialization_runtimeKSerializer, KmpdataDealsService, KmpdataKotlinIterator, KmpdataApollo_apiCustomTypeAdapter, KmpdataApollo_apiExecutionContext, KmpdataOkioSink, KmpdataOkioSource, KmpdataApollo_apiInputFieldMarshaller, KmpdataApollo_apiResponseWriter, KmpdataApollo_apiResponseReaderObjectReader, KmpdataApollo_apiResponseReaderListItemReader, KmpdataApollo_apiResponseReaderListReader, KmpdataKtor_client_coreHttpClientEngineCapability, KmpdataKotlinCoroutineContext, KmpdataKtor_ioCloseable, KmpdataApollo_runtime_kotlinNetworkTransport, KmpdataApollo_runtime_kotlinApolloRequestInterceptor, KmpdataApollo_runtime_kotlinApolloMutationCall, KmpdataApollo_apiMutation, KmpdataApollo_runtime_kotlinApolloQueryCall, KmpdataKotlinFunction, KmpdataKotlinx_serialization_runtimeEncoder, KmpdataKotlinx_serialization_runtimeSerialDescriptor, KmpdataKotlinx_serialization_runtimeSerializationStrategy, KmpdataKotlinx_serialization_runtimeDecoder, KmpdataKotlinx_serialization_runtimeDeserializationStrategy, KmpdataApollo_apiExecutionContextElement, KmpdataApollo_apiExecutionContextKey, KmpdataOkioBufferedSink, KmpdataApollo_apiInputFieldWriter, KmpdataApollo_apiResponseWriterListItemWriter, KmpdataApollo_apiResponseWriterListWriter, KmpdataKtor_utilsAttributes, KmpdataKotlinCoroutineContextKey, KmpdataKotlinCoroutineContextElement, KmpdataKotlinContinuation, KmpdataKotlinContinuationInterceptor, KmpdataKotlinx_coroutines_coreRunnable, KmpdataKotlinx_coroutines_coreFlow, KmpdataApollo_runtime_kotlinApolloInterceptorChain, KmpdataApollo_runtime_kotlinApolloCall, KmpdataKotlinx_serialization_runtimeCompositeEncoder, KmpdataKotlinx_serialization_runtimeSerialModule, KmpdataKotlinAnnotation, KmpdataKotlinx_serialization_runtimeCompositeDecoder, KmpdataApollo_apiInputFieldWriterListItemWriter, KmpdataApollo_apiInputFieldWriterListWriter, KmpdataKtor_client_coreHttpClientFeature, KmpdataKotlinSuspendFunction2, KmpdataKotlinx_serialization_runtimeSerialModuleCollector, KmpdataKotlinKClass, KmpdataKtor_httpHeaders, KmpdataKtor_httpHttpMessage, KmpdataKtor_ioByteReadChannel, KmpdataKtor_client_coreHttpRequest, KmpdataKtor_httpHttpMessageBuilder, KmpdataKotlinx_coroutines_coreJob, KmpdataKtor_httpParameters, KmpdataKotlinKDeclarationContainer, KmpdataKotlinKAnnotatedElement, KmpdataKotlinKClassifier, KmpdataKotlinMapEntry, KmpdataKtor_utilsStringValues, KmpdataKtor_ioReadSession, KmpdataKotlinx_coroutines_coreChildHandle, KmpdataKotlinx_coroutines_coreChildJob, KmpdataKotlinx_coroutines_coreDisposableHandle, KmpdataKotlinSequence, KmpdataKotlinx_coroutines_coreSelectClause0, KmpdataKtor_client_coreType, KmpdataKotlinKType, KmpdataKotlinx_coroutines_coreParentJob, KmpdataKotlinx_coroutines_coreSelectInstance, KmpdataKotlinSuspendFunction0, KmpdataKtor_ioObjectPool, KmpdataKtor_ioInput, KmpdataKotlinAppendable, KmpdataKtor_ioOutput;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wnullability"

__attribute__((swift_name("KotlinBase")))
@interface KmpdataBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end;

@interface KmpdataBase (KmpdataBaseCopying) <NSCopying>
@end;

__attribute__((swift_name("KotlinMutableSet")))
@interface KmpdataMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end;

__attribute__((swift_name("KotlinMutableDictionary")))
@interface KmpdataMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end;

@interface NSError (NSErrorKmpdataKotlinException)
@property (readonly) id _Nullable kotlinException;
@end;

__attribute__((swift_name("KotlinNumber")))
@interface KmpdataNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end;

__attribute__((swift_name("KotlinByte")))
@interface KmpdataByte : KmpdataNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end;

__attribute__((swift_name("KotlinUByte")))
@interface KmpdataUByte : KmpdataNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end;

__attribute__((swift_name("KotlinShort")))
@interface KmpdataShort : KmpdataNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end;

__attribute__((swift_name("KotlinUShort")))
@interface KmpdataUShort : KmpdataNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end;

__attribute__((swift_name("KotlinInt")))
@interface KmpdataInt : KmpdataNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end;

__attribute__((swift_name("KotlinUInt")))
@interface KmpdataUInt : KmpdataNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end;

__attribute__((swift_name("KotlinLong")))
@interface KmpdataLong : KmpdataNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end;

__attribute__((swift_name("KotlinULong")))
@interface KmpdataULong : KmpdataNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end;

__attribute__((swift_name("KotlinFloat")))
@interface KmpdataFloat : KmpdataNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end;

__attribute__((swift_name("KotlinDouble")))
@interface KmpdataDouble : KmpdataNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end;

__attribute__((swift_name("KotlinBoolean")))
@interface KmpdataBoolean : KmpdataNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end;

__attribute__((swift_name("Kind")))
@protocol KmpdataKind
@required
@end;

__attribute__((swift_name("Eval")))
@interface KmpdataEval<__covariant A> : KmpdataBase <KmpdataKind>
- (A _Nullable)extract __attribute__((swift_name("extract()")));
- (KmpdataEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalAlways")))
@interface KmpdataEvalAlways<__covariant A> : KmpdataEval<A>
- (instancetype)initWithF:(A _Nullable (^)(void))f __attribute__((swift_name("init(f:)"))) __attribute__((objc_designated_initializer));
- (KmpdataEvalAlways<A> *)doCopyF:(A _Nullable (^)(void))f __attribute__((swift_name("doCopy(f:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (KmpdataEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalCompanion")))
@interface KmpdataEvalCompanion : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (KmpdataEvalAlways<id> *)alwaysF:(id _Nullable (^)(void))f __attribute__((swift_name("always(f:)")));
- (KmpdataEval<id> *)justA:(id _Nullable)a __attribute__((swift_name("just(a:)")));
- (KmpdataEvalLater<id> *)laterF:(id _Nullable (^)(void))f __attribute__((swift_name("later(f:)")));
- (KmpdataEvalNow<id> *)nowA:(id _Nullable)a __attribute__((swift_name("now(a:)")));
@property (readonly) KmpdataEval<KmpdataBoolean *> *False __attribute__((swift_name("False")));
@property (readonly) KmpdataEval<KmpdataInt *> *One __attribute__((swift_name("One")));
@property (readonly) KmpdataEval<KmpdataBoolean *> *True __attribute__((swift_name("True")));
@property (readonly) KmpdataEval<KmpdataKotlinUnit *> *Unit __attribute__((swift_name("Unit")));
@property (readonly) KmpdataEval<KmpdataInt *> *Zero __attribute__((swift_name("Zero")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalLater")))
@interface KmpdataEvalLater<__covariant A> : KmpdataEval<A>
- (instancetype)initWithF:(A _Nullable (^)(void))f __attribute__((swift_name("init(f:)"))) __attribute__((objc_designated_initializer));
- (KmpdataEvalLater<A> *)doCopyF:(A _Nullable (^)(void))f __attribute__((swift_name("doCopy(f:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (KmpdataEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@property (readonly, getter=value_) A _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EvalNow")))
@interface KmpdataEvalNow<__covariant A> : KmpdataEval<A>
- (instancetype)initWithValue:(A _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (A _Nullable)component1 __attribute__((swift_name("component1()")));
- (KmpdataEvalNow<A> *)doCopyValue:(A _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (KmpdataEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value __attribute__((swift_name("value()")));
@property (readonly, getter=value_) A _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForTry")))
@interface KmpdataForTry : KmpdataBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForTry.Companion")))
@interface KmpdataForTryCompanion : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("MpTry")))
@interface KmpdataMpTry<__covariant A> : KmpdataBase <KmpdataKind>
- (KmpdataMpTry<id> *)apFf:(id<KmpdataKind>)ff __attribute__((swift_name("ap(ff:)")));
- (BOOL)existsPredicate:(KmpdataBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("exists(predicate:)")));
- (KmpdataMpTry<KmpdataKotlinThrowable *> *)failed __attribute__((swift_name("failed()")));
- (KmpdataMpTry<A> *)filterP:(KmpdataBoolean *(^)(A _Nullable))p __attribute__((swift_name("filter(p:)")));
- (KmpdataMpTry<id> *)flatMapF:(id<KmpdataKind> (^)(A _Nullable))f __attribute__((swift_name("flatMap(f:)")));
- (id _Nullable)foldIfFailure:(id _Nullable (^)(KmpdataKotlinThrowable *))ifFailure ifSuccess:(id _Nullable (^)(A _Nullable))ifSuccess __attribute__((swift_name("fold(ifFailure:ifSuccess:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, A _Nullable))operation __attribute__((swift_name("foldLeft(initial:operation:)")));
- (KmpdataEval<id> *)foldRightInitial:(KmpdataEval<id> *)initial operation:(KmpdataEval<id> *(^)(A _Nullable, KmpdataEval<id> *))operation __attribute__((swift_name("foldRight(initial:operation:)")));
- (BOOL)isFailure __attribute__((swift_name("isFailure()")));
- (BOOL)isSuccess __attribute__((swift_name("isSuccess()")));
- (KmpdataMpTry<id> *)mapF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("map(f:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTryCompanion")))
@interface KmpdataMpTryCompanion : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (KmpdataMpTry<id> *)invokeF:(id _Nullable (^)(void))f __attribute__((swift_name("invoke(f:)")));
- (KmpdataMpTry<id> *)justA:(id _Nullable)a __attribute__((swift_name("just(a:)")));
- (KmpdataMpTry<id> *)raiseE:(KmpdataKotlinThrowable *)e __attribute__((swift_name("raise(e:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTryFailure")))
@interface KmpdataMpTryFailure : KmpdataMpTry<KmpdataKotlinNothing *>
- (instancetype)initWithException:(KmpdataKotlinThrowable *)exception __attribute__((swift_name("init(exception:)"))) __attribute__((objc_designated_initializer));
- (KmpdataKotlinThrowable *)component1 __attribute__((swift_name("component1()")));
- (KmpdataMpTryFailure *)doCopyException:(KmpdataKotlinThrowable *)exception __attribute__((swift_name("doCopy(exception:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)existsPredicate:(KmpdataBoolean *(^)(KmpdataKotlinNothing *))predicate __attribute__((swift_name("exists(predicate:)")));
- (KmpdataMpTry<KmpdataKotlinNothing *> *)filterP:(KmpdataBoolean *(^)(KmpdataKotlinNothing *))p __attribute__((swift_name("filter(p:)")));
- (KmpdataMpTry<id> *)flatMapF:(id<KmpdataKind> (^)(KmpdataKotlinNothing *))f __attribute__((swift_name("flatMap(f:)")));
- (id _Nullable)foldIfFailure:(id _Nullable (^)(KmpdataKotlinThrowable *))ifFailure ifSuccess:(id _Nullable (^)(KmpdataKotlinNothing *))ifSuccess __attribute__((swift_name("fold(ifFailure:ifSuccess:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, KmpdataKotlinNothing *))operation __attribute__((swift_name("foldLeft(initial:operation:)")));
- (KmpdataEval<id> *)foldRightInitial:(KmpdataEval<id> *)initial operation:(KmpdataEval<id> *(^)(KmpdataKotlinNothing *, KmpdataEval<id> *))operation __attribute__((swift_name("foldRight(initial:operation:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isFailure __attribute__((swift_name("isFailure()")));
- (BOOL)isSuccess __attribute__((swift_name("isSuccess()")));
- (KmpdataMpTry<id> *)mapF:(id _Nullable (^)(KmpdataKotlinNothing *))f __attribute__((swift_name("map(f:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) KmpdataKotlinThrowable *exception __attribute__((swift_name("exception")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTrySuccess")))
@interface KmpdataMpTrySuccess<__covariant A> : KmpdataMpTry<A>
- (instancetype)initWithValue:(A _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (A _Nullable)component1 __attribute__((swift_name("component1()")));
- (KmpdataMpTrySuccess<A> *)doCopyValue:(A _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isFailure __attribute__((swift_name("isFailure()")));
- (BOOL)isSuccess __attribute__((swift_name("isSuccess()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) A _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("KotlinThrowable")))
@interface KmpdataKotlinThrowable : KmpdataBase
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (KmpdataKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) KmpdataKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
@end;

__attribute__((swift_name("KotlinException")))
@interface KmpdataKotlinException : KmpdataKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("TryException")))
@interface KmpdataTryException : KmpdataKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TryException.PredicateException")))
@interface KmpdataTryExceptionPredicateException : KmpdataTryException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (KmpdataTryExceptionPredicateException *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TryException.UnsupportedOperationException")))
@interface KmpdataTryExceptionUnsupportedOperationException : KmpdataTryException
- (instancetype)initWithMessage:(NSString *)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (KmpdataTryExceptionUnsupportedOperationException *)doCopyMessage:(NSString *)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((swift_name("Logger")))
@protocol KmpdataLogger
@required
- (void)logTag:(NSString *)tag message:(NSString *)message __attribute__((swift_name("log(tag:message:)")));
@end;

__attribute__((swift_name("ModuleConfig")))
@protocol KmpdataModuleConfig
@required
@property id<KmpdataNetConfig> netConfig __attribute__((swift_name("netConfig")));
@end;

__attribute__((swift_name("NetConfig")))
@protocol KmpdataNetConfig
@required
@property NSString *pathDeals __attribute__((swift_name("pathDeals")));
@property NSString *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetConfigImpl")))
@interface KmpdataNetConfigImpl : KmpdataBase <KmpdataNetConfig>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)netConfigImpl __attribute__((swift_name("init()")));
@property NSString *pathDeals __attribute__((swift_name("pathDeals")));
@property NSString *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("RemoteRepoGraphQl")))
@protocol KmpdataRemoteRepoGraphQl
@required
- (void)fetchUserCBId:(NSString *)id success:(void (^)(KmpdataUserQueryData *))success error:(void (^)(KmpdataKotlinThrowable *))error __attribute__((swift_name("fetchUserCB(id:success:error:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServiceLocatorShared")))
@interface KmpdataServiceLocatorShared : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serviceLocatorShared __attribute__((swift_name("init()")));
@property (readonly) id<KmpdataRemoteRepoGraphQl> graph __attribute__((swift_name("graph")));
@property (readonly) id<KmpdataDealsUseCase> uc __attribute__((swift_name("uc")));
@end;

__attribute__((swift_name("LocalDataSource")))
@protocol KmpdataLocalDataSource
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocalDataSourceCompanion")))
@interface KmpdataLocalDataSourceCompanion : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Destination")))
@interface KmpdataDestination : KmpdataBase
- (instancetype)initWithDestinationId:(int32_t)destinationId destinationName:(NSString *)destinationName image:(NSString *)image price:(KmpdataPrice *)price searchUrl:(NSString *)searchUrl startDate:(NSString *)startDate timePeriod:(NSString *)timePeriod __attribute__((swift_name("init(destinationId:destinationName:image:price:searchUrl:startDate:timePeriod:)"))) __attribute__((objc_designated_initializer));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (KmpdataPrice *)component4 __attribute__((swift_name("component4()")));
- (NSString *)component5 __attribute__((swift_name("component5()")));
- (NSString *)component6 __attribute__((swift_name("component6()")));
- (NSString *)component7 __attribute__((swift_name("component7()")));
- (KmpdataDestination *)doCopyDestinationId:(int32_t)destinationId destinationName:(NSString *)destinationName image:(NSString *)image price:(KmpdataPrice *)price searchUrl:(NSString *)searchUrl startDate:(NSString *)startDate timePeriod:(NSString *)timePeriod __attribute__((swift_name("doCopy(destinationId:destinationName:image:price:searchUrl:startDate:timePeriod:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t destinationId __attribute__((swift_name("destinationId")));
@property (readonly) NSString *destinationName __attribute__((swift_name("destinationName")));
@property (readonly) NSString *image __attribute__((swift_name("image")));
@property (readonly) KmpdataPrice *price __attribute__((swift_name("price")));
@property (readonly) NSString *searchUrl __attribute__((swift_name("searchUrl")));
@property (readonly) NSString *startDate __attribute__((swift_name("startDate")));
@property (readonly) NSString *timePeriod __attribute__((swift_name("timePeriod")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Price")))
@interface KmpdataPrice : KmpdataBase
- (instancetype)initWithAmount:(double)amount currency:(NSString *)currency __attribute__((swift_name("init(amount:currency:)"))) __attribute__((objc_designated_initializer));
- (double)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (KmpdataPrice *)doCopyAmount:(double)amount currency:(NSString *)currency __attribute__((swift_name("doCopy(amount:currency:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) double amount __attribute__((swift_name("amount")));
@property (readonly) NSString *currency __attribute__((swift_name("currency")));
@end;

__attribute__((swift_name("RemoteDataSource")))
@protocol KmpdataRemoteDataSource
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemoteDataSourceCompanion")))
@interface KmpdataRemoteDataSourceCompanion : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("DealsService")))
@protocol KmpdataDealsService
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DealsServiceCompanion")))
@interface KmpdataDealsServiceCompanion : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("DealsUseCase")))
@protocol KmpdataDealsUseCase
@required
- (void)getDestinationsCbSuccess:(void (^)(NSArray<id> *))success error:(void (^)(KmpdataKotlinThrowable *))error __attribute__((swift_name("getDestinationsCb(success:error:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DealsUseCaseCompanion")))
@interface KmpdataDealsUseCaseCompanion : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((swift_name("Apollo_apiOperation")))
@protocol KmpdataApollo_apiOperation
@required
- (KmpdataOkioByteString *)composeRequestBody __attribute__((swift_name("composeRequestBody()")));
- (KmpdataOkioByteString *)composeRequestBodyScalarTypeAdapters:(KmpdataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(scalarTypeAdapters:)")));
- (id<KmpdataApollo_apiOperationName>)name __attribute__((swift_name("name()")));
- (NSString *)operationId __attribute__((swift_name("operationId()")));
- (KmpdataApollo_apiResponse<id> *)parseSource:(id<KmpdataOkioBufferedSource>)source __attribute__((swift_name("parse(source:)")));
- (KmpdataApollo_apiResponse<id> *)parseSource:(id<KmpdataOkioBufferedSource>)source scalarTypeAdapters:(KmpdataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(source:scalarTypeAdapters:)")));
- (KmpdataApollo_apiResponse<id> *)parseByteString:(KmpdataOkioByteString *)byteString __attribute__((swift_name("parse(byteString:)")));
- (KmpdataApollo_apiResponse<id> *)parseByteString:(KmpdataOkioByteString *)byteString scalarTypeAdapters:(KmpdataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(byteString:scalarTypeAdapters:)")));
- (NSString *)queryDocument __attribute__((swift_name("queryDocument()")));
- (id<KmpdataApollo_apiResponseFieldMapper>)responseFieldMapper __attribute__((swift_name("responseFieldMapper()")));
- (KmpdataApollo_apiOperationVariables *)variables __attribute__((swift_name("variables()")));
- (id _Nullable)wrapDataData:(id<KmpdataApollo_apiOperationData> _Nullable)data __attribute__((swift_name("wrapData(data:)")));
@end;

__attribute__((swift_name("Apollo_apiQuery")))
@protocol KmpdataApollo_apiQuery <KmpdataApollo_apiOperation>
@required
- (KmpdataOkioByteString *)composeRequestBodyAutoPersistQueries:(BOOL)autoPersistQueries withQueryDocument:(BOOL)withQueryDocument scalarTypeAdapters:(KmpdataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(autoPersistQueries:withQueryDocument:scalarTypeAdapters:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery")))
@interface KmpdataUserQuery : KmpdataBase <KmpdataApollo_apiQuery>
- (instancetype)initWithId:(KmpdataApollo_apiInput<NSString *> *)id __attribute__((swift_name("init(id:)"))) __attribute__((objc_designated_initializer));
- (KmpdataApollo_apiInput<NSString *> *)component1 __attribute__((swift_name("component1()")));
- (KmpdataOkioByteString *)composeRequestBody __attribute__((swift_name("composeRequestBody()")));
- (KmpdataOkioByteString *)composeRequestBodyScalarTypeAdapters:(KmpdataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(scalarTypeAdapters:)")));
- (KmpdataOkioByteString *)composeRequestBodyAutoPersistQueries:(BOOL)autoPersistQueries withQueryDocument:(BOOL)withQueryDocument scalarTypeAdapters:(KmpdataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("composeRequestBody(autoPersistQueries:withQueryDocument:scalarTypeAdapters:)")));
- (KmpdataUserQuery *)doCopyId:(KmpdataApollo_apiInput<NSString *> *)id __attribute__((swift_name("doCopy(id:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<KmpdataApollo_apiOperationName>)name __attribute__((swift_name("name()")));
- (NSString *)operationId __attribute__((swift_name("operationId()")));
- (KmpdataApollo_apiResponse<KmpdataUserQueryData *> *)parseSource:(id<KmpdataOkioBufferedSource>)source __attribute__((swift_name("parse(source:)")));
- (KmpdataApollo_apiResponse<KmpdataUserQueryData *> *)parseSource:(id<KmpdataOkioBufferedSource>)source scalarTypeAdapters:(KmpdataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(source:scalarTypeAdapters:)")));
- (KmpdataApollo_apiResponse<KmpdataUserQueryData *> *)parseByteString:(KmpdataOkioByteString *)byteString __attribute__((swift_name("parse(byteString:)")));
- (KmpdataApollo_apiResponse<KmpdataUserQueryData *> *)parseByteString:(KmpdataOkioByteString *)byteString scalarTypeAdapters:(KmpdataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("parse(byteString:scalarTypeAdapters:)")));
- (NSString *)queryDocument __attribute__((swift_name("queryDocument()")));
- (id<KmpdataApollo_apiResponseFieldMapper>)responseFieldMapper __attribute__((swift_name("responseFieldMapper()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (KmpdataApollo_apiOperationVariables *)variables __attribute__((swift_name("variables()")));
- (KmpdataUserQueryData * _Nullable)wrapDataData:(KmpdataUserQueryData * _Nullable)data __attribute__((swift_name("wrapData(data:)")));
@property (readonly) KmpdataApollo_apiInput<NSString *> *id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.Companion")))
@interface KmpdataUserQueryCompanion : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (readonly) NSString *OPERATION_ID __attribute__((swift_name("OPERATION_ID")));
@property (readonly) id<KmpdataApollo_apiOperationName> OPERATION_NAME __attribute__((swift_name("OPERATION_NAME")));
@property (readonly) NSString *QUERY_DOCUMENT __attribute__((swift_name("QUERY_DOCUMENT")));
@end;

__attribute__((swift_name("Apollo_apiOperationData")))
@protocol KmpdataApollo_apiOperationData
@required
- (id<KmpdataApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.Data")))
@interface KmpdataUserQueryData : KmpdataBase <KmpdataApollo_apiOperationData>
- (instancetype)initWithUser:(KmpdataUserQueryUser * _Nullable)user __attribute__((swift_name("init(user:)"))) __attribute__((objc_designated_initializer));
- (KmpdataUserQueryUser * _Nullable)component1 __attribute__((swift_name("component1()")));
- (KmpdataUserQueryData *)doCopyUser:(KmpdataUserQueryUser * _Nullable)user __attribute__((swift_name("doCopy(user:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<KmpdataApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) KmpdataUserQueryUser * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.DataCompanion")))
@interface KmpdataUserQueryDataCompanion : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KmpdataApollo_apiResponseFieldMapper>)Mapper __attribute__((swift_name("Mapper()")));
- (KmpdataUserQueryData *)invokeReader:(id<KmpdataApollo_apiResponseReader>)reader __attribute__((swift_name("invoke(reader:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.Hobby")))
@interface KmpdataUserQueryHobby : KmpdataBase
- (instancetype)initWith__typename:(NSString *)__typename description:(NSString * _Nullable)description title:(NSString * _Nullable)title __attribute__((swift_name("init(__typename:description:title:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (KmpdataUserQueryHobby *)doCopy__typename:(NSString *)__typename description:(NSString * _Nullable)description title:(NSString * _Nullable)title __attribute__((swift_name("doCopy(__typename:description:title:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<KmpdataApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *__typename __attribute__((swift_name("__typename")));
@property (readonly, getter=description_) NSString * _Nullable description __attribute__((swift_name("description")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.HobbyCompanion")))
@interface KmpdataUserQueryHobbyCompanion : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KmpdataApollo_apiResponseFieldMapper>)Mapper __attribute__((swift_name("Mapper()")));
- (KmpdataUserQueryHobby *)invokeReader:(id<KmpdataApollo_apiResponseReader>)reader __attribute__((swift_name("invoke(reader:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.User")))
@interface KmpdataUserQueryUser : KmpdataBase
- (instancetype)initWith__typename:(NSString *)__typename id:(NSString * _Nullable)id name:(NSString * _Nullable)name age:(KmpdataInt * _Nullable)age hobbies:(NSArray<id> * _Nullable)hobbies __attribute__((swift_name("init(__typename:id:name:age:hobbies:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (KmpdataInt * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSArray<id> * _Nullable)component5 __attribute__((swift_name("component5()")));
- (KmpdataUserQueryUser *)doCopy__typename:(NSString *)__typename id:(NSString * _Nullable)id name:(NSString * _Nullable)name age:(KmpdataInt * _Nullable)age hobbies:(NSArray<id> * _Nullable)hobbies __attribute__((swift_name("doCopy(__typename:id:name:age:hobbies:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<KmpdataApollo_apiResponseFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *__typename __attribute__((swift_name("__typename")));
@property (readonly) KmpdataInt * _Nullable age __attribute__((swift_name("age")));
@property (readonly) NSArray<id> * _Nullable hobbies __attribute__((swift_name("hobbies")));
@property (readonly) NSString * _Nullable id __attribute__((swift_name("id")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserQuery.UserCompanion")))
@interface KmpdataUserQueryUserCompanion : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<KmpdataApollo_apiResponseFieldMapper>)Mapper __attribute__((swift_name("Mapper()")));
- (KmpdataUserQueryUser *)invokeReader:(id<KmpdataApollo_apiResponseReader>)reader __attribute__((swift_name("invoke(reader:)")));
@end;

__attribute__((swift_name("KotlinComparable")))
@protocol KmpdataKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("KotlinEnum")))
@interface KmpdataKotlinEnum<E> : KmpdataBase <KmpdataKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=name_) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end;

__attribute__((swift_name("Apollo_apiScalarType")))
@protocol KmpdataApollo_apiScalarType
@required
- (NSString *)className __attribute__((swift_name("className()")));
- (NSString *)typeName __attribute__((swift_name("typeName()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CustomType")))
@interface KmpdataCustomType : KmpdataKotlinEnum<KmpdataCustomType *> <KmpdataApollo_apiScalarType>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) KmpdataCustomType *id __attribute__((swift_name("id")));
- (int32_t)compareToOther:(KmpdataCustomType *)other __attribute__((swift_name("compareTo(other:)")));
@end;

@interface KmpdataKotlinThrowable (Extensions)
- (KmpdataMpTry<id> *)failure __attribute__((swift_name("failure()")));
@end;

@interface KmpdataRemoteDataSourceCompanion (Extensions)
- (id<KmpdataRemoteDataSource>)createClientHttpEngine:(id<KmpdataKtor_client_coreHttpClientEngine>)clientHttpEngine netConfig:(id<KmpdataNetConfig>)netConfig __attribute__((swift_name("create(clientHttpEngine:netConfig:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MpTryKt")))
@interface KmpdataMpTryKt : KmpdataBase
+ (id _Nullable)identityA:(id _Nullable)a __attribute__((swift_name("identity(a:)")));
+ (KmpdataMpTry<id> *)fix:(id<KmpdataKind>)receiver __attribute__((swift_name("fix(_:)")));
+ (KmpdataMpTry<id> *)flatten:(id<KmpdataKind>)receiver __attribute__((swift_name("flatten(_:)")));
+ (id _Nullable)getOrDefault:(id<KmpdataKind>)receiver default:(id _Nullable (^)(void))default_ __attribute__((swift_name("getOrDefault(_:default:)")));
+ (id _Nullable)getOrElse:(id<KmpdataKind>)receiver default:(id _Nullable (^)(KmpdataKotlinThrowable *))default_ __attribute__((swift_name("getOrElse(_:default:)")));
+ (KmpdataMpTry<id> *)orElse:(id<KmpdataKind>)receiver f:(id<KmpdataKind> (^)(void))f __attribute__((swift_name("orElse(_:f:)")));
+ (id _Nullable)orNull:(id<KmpdataKind>)receiver __attribute__((swift_name("orNull(_:)")));
+ (KmpdataMpTry<id> *)recover:(id<KmpdataKind>)receiver f:(id _Nullable (^)(KmpdataKotlinThrowable *))f __attribute__((swift_name("recover(_:f:)")));
+ (KmpdataMpTry<id> *)recoverWith:(id<KmpdataKind>)receiver f:(id<KmpdataKind> (^)(KmpdataKotlinThrowable *))f __attribute__((swift_name("recoverWith(_:f:)")));
+ (KmpdataMpTry<id> *)rescue:(id<KmpdataKind>)receiver f:(id<KmpdataKind> (^)(KmpdataKotlinThrowable *))f __attribute__((swift_name("rescue(_:f:)")));
+ (KmpdataMpTry<id> *)success:(id _Nullable)receiver __attribute__((swift_name("success(_:)")));
+ (KmpdataMpTry<id> *)try_:(id _Nullable (^)(void))receiver __attribute__((swift_name("try_(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ActualObjKt")))
@interface KmpdataActualObjKt : KmpdataBase
+ (int64_t)expectedTimestamp __attribute__((swift_name("expectedTimestamp()")));
@property (class, readonly) id<KmpdataKtor_client_coreHttpClientEngine> clientEngine __attribute__((swift_name("clientEngine")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApolloRemoteRepositoryKt")))
@interface KmpdataApolloRemoteRepositoryKt : KmpdataBase
+ (KmpdataApollo_runtime_kotlinApolloClient *)createApolloClient __attribute__((swift_name("createApolloClient()")));
+ (id<KmpdataRemoteRepoGraphQl>)createRemoteRepoGraphQl __attribute__((swift_name("createRemoteRepoGraphQl()")));
+ (id<KmpdataRemoteRepoGraphQl>)createRemoteRepoGraphQlClient:(KmpdataApollo_runtime_kotlinApolloClient *)client __attribute__((swift_name("createRemoteRepoGraphQl(client:)")));
+ (id<KmpdataRemoteRepoGraphQl>)createRemoteRepoGraphQlClient:(KmpdataApollo_runtime_kotlinApolloClient *)client scope:(id<KmpdataKotlinx_coroutines_coreCoroutineScope>)scope __attribute__((swift_name("createRemoteRepoGraphQl(client:scope:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocalDataSourceKt")))
@interface KmpdataLocalDataSourceKt : KmpdataBase
+ (id<KmpdataLocalDataSource>)createLocalDataSource __attribute__((swift_name("createLocalDataSource()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemoteDataSourceKt")))
@interface KmpdataRemoteDataSourceKt : KmpdataBase
+ (id<KmpdataRemoteDataSource>)createRemoteDataSource __attribute__((swift_name("createRemoteDataSource()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetDataModelKt")))
@interface KmpdataNetDataModelKt : KmpdataBase
+ (id<KmpdataKotlinSuspendFunction1>)mapperListT:(id<KmpdataKotlinx_serialization_runtimeKSerializer>)t __attribute__((swift_name("mapperList(t:)")));
+ (NSMutableArray<id> *)filterResponseValues:(NSArray<id> *)receiver dtoMapper:(id _Nullable (^)(id _Nullable))dtoMapper __attribute__((swift_name("filterResponseValues(_:dtoMapper:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DealsServiceKt")))
@interface KmpdataDealsServiceKt : KmpdataBase
+ (id<KmpdataDealsService>)createDealsServiceLocalDataSource:(id<KmpdataLocalDataSource>)localDataSource remoteDataSource:(id<KmpdataRemoteDataSource>)remoteDataSource __attribute__((swift_name("createDealsService(localDataSource:remoteDataSource:)")));
+ (id<KmpdataDealsService>)createDealsServiceLocalDataSource:(id<KmpdataLocalDataSource>)localDataSource remoteDataSource:(id<KmpdataRemoteDataSource>)remoteDataSource scope:(id<KmpdataKotlinx_coroutines_coreCoroutineScope>)scope __attribute__((swift_name("createDealsService(localDataSource:remoteDataSource:scope:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DealsUseCaseKt")))
@interface KmpdataDealsUseCaseKt : KmpdataBase
+ (id<KmpdataDealsUseCase>)createDealsUseCaseDealsService:(id<KmpdataDealsService>)dealsService dealsMapper:(id _Nullable (^)(KmpdataDestination *))dealsMapper __attribute__((swift_name("createDealsUseCase(dealsService:dealsMapper:)")));
+ (id<KmpdataDealsUseCase>)createDealsUseCaseWithScopeDealsService:(id<KmpdataDealsService>)dealsService dealsMapper:(id _Nullable (^)(KmpdataDestination *))dealsMapper scope:(id<KmpdataKotlinx_coroutines_coreCoroutineScope>)scope __attribute__((swift_name("createDealsUseCaseWithScope(dealsService:dealsMapper:scope:)")));
+ (id<KmpdataDealsUseCase>)createDealsUseCase:(id<KmpdataDealsUseCase>)receiver dealsService:(id<KmpdataDealsService>)dealsService dealsMapper:(id _Nullable (^)(KmpdataDestination *))dealsMapper __attribute__((swift_name("createDealsUseCase(_:dealsService:dealsMapper:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface KmpdataKotlinUnit : KmpdataBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface KmpdataKotlinNothing : KmpdataBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface KmpdataKotlinArray<T> : KmpdataBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(KmpdataInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<KmpdataKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("OkioByteString")))
@interface KmpdataOkioByteString : KmpdataBase <KmpdataKotlinComparable>
- (NSString *)base64 __attribute__((swift_name("base64()")));
- (NSString *)base64Url __attribute__((swift_name("base64Url()")));
- (int32_t)compareToOther:(KmpdataOkioByteString *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)endsWithSuffix:(KmpdataKotlinByteArray *)suffix __attribute__((swift_name("endsWith(suffix:)")));
- (BOOL)endsWithSuffix_:(KmpdataOkioByteString *)suffix __attribute__((swift_name("endsWith(suffix_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)hex __attribute__((swift_name("hex()")));
- (int32_t)indexOfOther:(KmpdataKotlinByteArray *)other fromIndex:(int32_t)fromIndex __attribute__((swift_name("indexOf(other:fromIndex:)")));
- (int32_t)indexOfOther:(KmpdataOkioByteString *)other fromIndex_:(int32_t)fromIndex __attribute__((swift_name("indexOf(other:fromIndex_:)")));
- (int32_t)lastIndexOfOther:(KmpdataKotlinByteArray *)other fromIndex:(int32_t)fromIndex __attribute__((swift_name("lastIndexOf(other:fromIndex:)")));
- (int32_t)lastIndexOfOther:(KmpdataOkioByteString *)other fromIndex_:(int32_t)fromIndex __attribute__((swift_name("lastIndexOf(other:fromIndex_:)")));
- (BOOL)rangeEqualsOffset:(int32_t)offset other:(KmpdataKotlinByteArray *)other otherOffset:(int32_t)otherOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:other:otherOffset:byteCount:)")));
- (BOOL)rangeEqualsOffset:(int32_t)offset other:(KmpdataOkioByteString *)other otherOffset:(int32_t)otherOffset byteCount_:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:other:otherOffset:byteCount_:)")));
- (BOOL)startsWithPrefix:(KmpdataKotlinByteArray *)prefix __attribute__((swift_name("startsWith(prefix:)")));
- (BOOL)startsWithPrefix_:(KmpdataOkioByteString *)prefix __attribute__((swift_name("startsWith(prefix_:)")));
- (KmpdataOkioByteString *)substringBeginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("substring(beginIndex:endIndex:)")));
- (KmpdataOkioByteString *)toAsciiLowercase __attribute__((swift_name("toAsciiLowercase()")));
- (KmpdataOkioByteString *)toAsciiUppercase __attribute__((swift_name("toAsciiUppercase()")));
- (KmpdataKotlinByteArray *)toByteArray __attribute__((swift_name("toByteArray()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (NSString *)utf8 __attribute__((swift_name("utf8()")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiScalarTypeAdapters")))
@interface KmpdataApollo_apiScalarTypeAdapters : KmpdataBase
- (instancetype)initWithCustomAdapters:(NSDictionary<id<KmpdataApollo_apiScalarType>, id<KmpdataApollo_apiCustomTypeAdapter>> *)customAdapters __attribute__((swift_name("init(customAdapters:)"))) __attribute__((objc_designated_initializer));
- (id<KmpdataApollo_apiCustomTypeAdapter>)adapterForScalarType:(id<KmpdataApollo_apiScalarType>)scalarType __attribute__((swift_name("adapterFor(scalarType:)")));
@property (readonly) NSDictionary<id<KmpdataApollo_apiScalarType>, id<KmpdataApollo_apiCustomTypeAdapter>> *customAdapters __attribute__((swift_name("customAdapters")));
@end;

__attribute__((swift_name("Apollo_apiOperationName")))
@protocol KmpdataApollo_apiOperationName
@required
- (NSString *)name __attribute__((swift_name("name()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponse")))
@interface KmpdataApollo_apiResponse<T> : KmpdataBase
- (instancetype)initWithBuilder:(KmpdataApollo_apiResponseBuilder<T> *)builder __attribute__((swift_name("init(builder:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithOperation:(id<KmpdataApollo_apiOperation>)operation data:(T _Nullable)data errors:(NSArray<KmpdataApollo_apiError *> * _Nullable)errors dependentKeys:(NSSet<NSString *> *)dependentKeys fromCache:(BOOL)fromCache extensions:(NSDictionary<NSString *, id> *)extensions executionContext:(id<KmpdataApollo_apiExecutionContext>)executionContext __attribute__((swift_name("init(operation:data:errors:dependentKeys:fromCache:extensions:executionContext:)"))) __attribute__((objc_designated_initializer));
- (id<KmpdataApollo_apiOperation>)component1 __attribute__((swift_name("component1()")));
- (T _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSArray<KmpdataApollo_apiError *> * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSSet<NSString *> *)component4 __attribute__((swift_name("component4()")));
- (BOOL)component5 __attribute__((swift_name("component5()")));
- (NSDictionary<NSString *, id> *)component6 __attribute__((swift_name("component6()")));
- (id<KmpdataApollo_apiExecutionContext>)component7 __attribute__((swift_name("component7()")));
- (KmpdataApollo_apiResponse<T> *)doCopyOperation:(id<KmpdataApollo_apiOperation>)operation data:(T _Nullable)data errors:(NSArray<KmpdataApollo_apiError *> * _Nullable)errors dependentKeys:(NSSet<NSString *> *)dependentKeys fromCache:(BOOL)fromCache extensions:(NSDictionary<NSString *, id> *)extensions executionContext:(id<KmpdataApollo_apiExecutionContext>)executionContext __attribute__((swift_name("doCopy(operation:data:errors:dependentKeys:fromCache:extensions:executionContext:)")));
- (T _Nullable)data __attribute__((swift_name("data()"))) __attribute__((deprecated("Use property instead")));
- (NSSet<NSString *> *)dependentKeys __attribute__((swift_name("dependentKeys()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSArray<KmpdataApollo_apiError *> * _Nullable)errors __attribute__((swift_name("errors()"))) __attribute__((deprecated("Use property instead")));
- (NSDictionary<NSString *, id> *)extensions __attribute__((swift_name("extensions()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)fromCache __attribute__((swift_name("fromCache()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)hasErrors __attribute__((swift_name("hasErrors()")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<KmpdataApollo_apiOperation>)operation __attribute__((swift_name("operation()"))) __attribute__((deprecated("Use property instead")));
- (KmpdataApollo_apiResponseBuilder<T> *)toBuilder __attribute__((swift_name("toBuilder()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=data_) T _Nullable data __attribute__((swift_name("data")));
@property (readonly, getter=dependentKeys_) NSSet<NSString *> *dependentKeys __attribute__((swift_name("dependentKeys")));
@property (readonly, getter=errors_) NSArray<KmpdataApollo_apiError *> * _Nullable errors __attribute__((swift_name("errors")));
@property (readonly) id<KmpdataApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly, getter=extensions_) NSDictionary<NSString *, id> *extensions __attribute__((swift_name("extensions")));
@property (readonly, getter=fromCache_) BOOL fromCache __attribute__((swift_name("fromCache")));
@property (readonly, getter=operation_) id<KmpdataApollo_apiOperation> operation __attribute__((swift_name("operation")));
@end;

__attribute__((swift_name("OkioSource")))
@protocol KmpdataOkioSource
@required
- (void)close __attribute__((swift_name("close()")));
- (int64_t)readSink:(KmpdataOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("read(sink:byteCount:)")));
- (KmpdataOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
@end;

__attribute__((swift_name("OkioBufferedSource")))
@protocol KmpdataOkioBufferedSource <KmpdataOkioSource>
@required
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (int64_t)indexOfB:(int8_t)b __attribute__((swift_name("indexOf(b:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(b:fromIndex:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex toIndex:(int64_t)toIndex __attribute__((swift_name("indexOf(b:fromIndex:toIndex:)")));
- (int64_t)indexOfBytes:(KmpdataOkioByteString *)bytes __attribute__((swift_name("indexOf(bytes:)")));
- (int64_t)indexOfBytes:(KmpdataOkioByteString *)bytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(bytes:fromIndex:)")));
- (int64_t)indexOfElementTargetBytes:(KmpdataOkioByteString *)targetBytes __attribute__((swift_name("indexOfElement(targetBytes:)")));
- (int64_t)indexOfElementTargetBytes:(KmpdataOkioByteString *)targetBytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOfElement(targetBytes:fromIndex:)")));
- (id<KmpdataOkioBufferedSource>)peek __attribute__((swift_name("peek()")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(KmpdataOkioByteString *)bytes __attribute__((swift_name("rangeEquals(offset:bytes:)")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(KmpdataOkioByteString *)bytes bytesOffset:(int32_t)bytesOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:bytes:bytesOffset:byteCount:)")));
- (int32_t)readSink:(KmpdataKotlinByteArray *)sink __attribute__((swift_name("read(sink:)")));
- (int32_t)readSink:(KmpdataKotlinByteArray *)sink offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("read(sink:offset:byteCount:)")));
- (int64_t)readAllSink:(id<KmpdataOkioSink>)sink __attribute__((swift_name("readAll(sink:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (KmpdataKotlinByteArray *)readByteArray __attribute__((swift_name("readByteArray()")));
- (KmpdataKotlinByteArray *)readByteArrayByteCount:(int64_t)byteCount __attribute__((swift_name("readByteArray(byteCount:)")));
- (KmpdataOkioByteString *)readByteString __attribute__((swift_name("readByteString()")));
- (KmpdataOkioByteString *)readByteStringByteCount:(int64_t)byteCount __attribute__((swift_name("readByteString(byteCount:)")));
- (int64_t)readDecimalLong __attribute__((swift_name("readDecimalLong()")));
- (void)readFullySink:(KmpdataKotlinByteArray *)sink __attribute__((swift_name("readFully(sink:)")));
- (void)readFullySink:(KmpdataOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readFully(sink:byteCount:)")));
- (int64_t)readHexadecimalUnsignedLong __attribute__((swift_name("readHexadecimalUnsignedLong()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int32_t)readIntLe __attribute__((swift_name("readIntLe()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int64_t)readLongLe __attribute__((swift_name("readLongLe()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (int16_t)readShortLe __attribute__((swift_name("readShortLe()")));
- (NSString *)readUtf8 __attribute__((swift_name("readUtf8()")));
- (NSString *)readUtf8ByteCount:(int64_t)byteCount __attribute__((swift_name("readUtf8(byteCount:)")));
- (int32_t)readUtf8CodePoint __attribute__((swift_name("readUtf8CodePoint()")));
- (NSString * _Nullable)readUtf8Line __attribute__((swift_name("readUtf8Line()")));
- (NSString *)readUtf8LineStrict __attribute__((swift_name("readUtf8LineStrict()")));
- (NSString *)readUtf8LineStrictLimit:(int64_t)limit __attribute__((swift_name("readUtf8LineStrict(limit:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (int32_t)selectOptions:(NSArray<KmpdataOkioByteString *> *)options __attribute__((swift_name("select(options:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
@property (readonly) KmpdataOkioBuffer *buffer __attribute__((swift_name("buffer")));
@end;

__attribute__((swift_name("Apollo_apiResponseFieldMapper")))
@protocol KmpdataApollo_apiResponseFieldMapper
@required
- (id _Nullable)mapResponseReader:(id<KmpdataApollo_apiResponseReader>)responseReader __attribute__((swift_name("map(responseReader:)")));
@end;

__attribute__((swift_name("Apollo_apiOperationVariables")))
@interface KmpdataApollo_apiOperationVariables : KmpdataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)marshal __attribute__((swift_name("marshal()")));
- (NSString *)marshalScalarTypeAdapters:(KmpdataApollo_apiScalarTypeAdapters *)scalarTypeAdapters __attribute__((swift_name("marshal(scalarTypeAdapters:)")));
- (id<KmpdataApollo_apiInputFieldMarshaller>)marshaller __attribute__((swift_name("marshaller()")));
- (NSDictionary<NSString *, id> *)valueMap __attribute__((swift_name("valueMap()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiInput")))
@interface KmpdataApollo_apiInput<V> : KmpdataBase
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
@property (readonly) BOOL defined __attribute__((swift_name("defined")));
@property (readonly) V _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Apollo_apiResponseFieldMarshaller")))
@protocol KmpdataApollo_apiResponseFieldMarshaller
@required
- (void)marshalWriter:(id<KmpdataApollo_apiResponseWriter>)writer __attribute__((swift_name("marshal(writer:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseReader")))
@protocol KmpdataApollo_apiResponseReader
@required
- (KmpdataBoolean * _Nullable)readBooleanField:(KmpdataApollo_apiResponseField *)field __attribute__((swift_name("readBoolean(field:)")));
- (id _Nullable)readCustomTypeField:(KmpdataApollo_apiResponseFieldCustomTypeField *)field __attribute__((swift_name("readCustomType(field:)")));
- (KmpdataDouble * _Nullable)readDoubleField:(KmpdataApollo_apiResponseField *)field __attribute__((swift_name("readDouble(field:)")));
- (id _Nullable)readFragmentField:(KmpdataApollo_apiResponseField *)field block:(id (^)(id<KmpdataApollo_apiResponseReader>))block __attribute__((swift_name("readFragment(field:block:)")));
- (id _Nullable)readFragmentField:(KmpdataApollo_apiResponseField *)field objectReader:(id<KmpdataApollo_apiResponseReaderObjectReader>)objectReader __attribute__((swift_name("readFragment(field:objectReader:)")));
- (KmpdataInt * _Nullable)readIntField:(KmpdataApollo_apiResponseField *)field __attribute__((swift_name("readInt(field:)")));
- (NSArray<id> * _Nullable)readListField:(KmpdataApollo_apiResponseField *)field block:(id (^)(id<KmpdataApollo_apiResponseReaderListItemReader>))block __attribute__((swift_name("readList(field:block:)")));
- (NSArray<id> * _Nullable)readListField:(KmpdataApollo_apiResponseField *)field listReader:(id<KmpdataApollo_apiResponseReaderListReader>)listReader __attribute__((swift_name("readList(field:listReader:)")));
- (KmpdataLong * _Nullable)readLongField:(KmpdataApollo_apiResponseField *)field __attribute__((swift_name("readLong(field:)")));
- (id _Nullable)readObjectField:(KmpdataApollo_apiResponseField *)field block:(id (^)(id<KmpdataApollo_apiResponseReader>))block __attribute__((swift_name("readObject(field:block:)")));
- (id _Nullable)readObjectField:(KmpdataApollo_apiResponseField *)field objectReader:(id<KmpdataApollo_apiResponseReaderObjectReader>)objectReader __attribute__((swift_name("readObject(field:objectReader:)")));
- (NSString * _Nullable)readStringField:(KmpdataApollo_apiResponseField *)field __attribute__((swift_name("readString(field:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol KmpdataKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<KmpdataKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end;

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol KmpdataKtor_ioCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol KmpdataKtor_client_coreHttpClientEngine <KmpdataKotlinx_coroutines_coreCoroutineScope, KmpdataKtor_ioCloseable>
@required
- (void)installClient:(KmpdataKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) KmpdataKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) KmpdataKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<KmpdataKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtime_kotlinApolloClient")))
@interface KmpdataApollo_runtime_kotlinApolloClient : KmpdataBase
- (instancetype)initWithNetworkTransport:(id<KmpdataApollo_runtime_kotlinNetworkTransport>)networkTransport scalarTypeAdapters:(KmpdataApollo_apiScalarTypeAdapters *)scalarTypeAdapters interceptors:(NSArray<id<KmpdataApollo_runtime_kotlinApolloRequestInterceptor>> *)interceptors executionContext:(id<KmpdataApollo_apiExecutionContext>)executionContext __attribute__((swift_name("init(networkTransport:scalarTypeAdapters:interceptors:executionContext:)"))) __attribute__((objc_designated_initializer));
- (id<KmpdataApollo_runtime_kotlinApolloMutationCall>)mutateMutation:(id<KmpdataApollo_apiMutation>)mutation __attribute__((swift_name("mutate(mutation:)")));
- (id<KmpdataApollo_runtime_kotlinApolloQueryCall>)queryQuery:(id<KmpdataApollo_apiQuery>)query __attribute__((swift_name("query(query:)")));
@end;

__attribute__((swift_name("KotlinFunction")))
@protocol KmpdataKotlinFunction
@required
@end;

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol KmpdataKotlinSuspendFunction1 <KmpdataKotlinFunction>
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerializationStrategy")))
@protocol KmpdataKotlinx_serialization_runtimeSerializationStrategy
@required
- (void)serializeEncoder:(id<KmpdataKotlinx_serialization_runtimeEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<KmpdataKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeDeserializationStrategy")))
@protocol KmpdataKotlinx_serialization_runtimeDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<KmpdataKotlinx_serialization_runtimeDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (id _Nullable)patchDecoder:(id<KmpdataKotlinx_serialization_runtimeDecoder>)decoder old:(id _Nullable)old __attribute__((swift_name("patch(decoder:old:)")));
@property (readonly) id<KmpdataKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeKSerializer")))
@protocol KmpdataKotlinx_serialization_runtimeKSerializer <KmpdataKotlinx_serialization_runtimeSerializationStrategy, KmpdataKotlinx_serialization_runtimeDeserializationStrategy>
@required
@end;

__attribute__((swift_name("KotlinIterator")))
@protocol KmpdataKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface KmpdataKotlinByteArray : KmpdataBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(KmpdataByte *(^)(KmpdataInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (KmpdataKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("Apollo_apiCustomTypeAdapter")))
@protocol KmpdataApollo_apiCustomTypeAdapter
@required
- (id _Nullable)decodeValue:(KmpdataApollo_apiCustomTypeValue<id> *)value __attribute__((swift_name("decode(value:)")));
- (KmpdataApollo_apiCustomTypeValue<id> *)encodeValue:(id _Nullable)value __attribute__((swift_name("encode(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponseBuilder")))
@interface KmpdataApollo_apiResponseBuilder<T> : KmpdataBase
- (KmpdataApollo_apiResponse<T> *)build __attribute__((swift_name("build()")));
- (KmpdataApollo_apiResponseBuilder<T> *)dataData:(T _Nullable)data __attribute__((swift_name("data(data:)")));
- (KmpdataApollo_apiResponseBuilder<T> *)dependentKeysDependentKeys:(NSSet<NSString *> * _Nullable)dependentKeys __attribute__((swift_name("dependentKeys(dependentKeys:)")));
- (KmpdataApollo_apiResponseBuilder<T> *)errorsErrors:(NSArray<KmpdataApollo_apiError *> * _Nullable)errors __attribute__((swift_name("errors(errors:)")));
- (KmpdataApollo_apiResponseBuilder<T> *)executionContextExecutionContext:(id<KmpdataApollo_apiExecutionContext>)executionContext __attribute__((swift_name("executionContext(executionContext:)")));
- (KmpdataApollo_apiResponseBuilder<T> *)extensionsExtensions:(NSDictionary<NSString *, id> * _Nullable)extensions __attribute__((swift_name("extensions(extensions:)")));
- (KmpdataApollo_apiResponseBuilder<T> *)fromCacheFromCache:(BOOL)fromCache __attribute__((swift_name("fromCache(fromCache:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiError")))
@interface KmpdataApollo_apiError : KmpdataBase
- (instancetype)initWithMessage:(NSString *)message locations:(NSArray<KmpdataApollo_apiErrorLocation *> *)locations customAttributes:(NSDictionary<NSString *, id> *)customAttributes __attribute__((swift_name("init(message:locations:customAttributes:)"))) __attribute__((objc_designated_initializer));
- (NSDictionary<NSString *, id> *)customAttributes __attribute__((swift_name("customAttributes()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSArray<KmpdataApollo_apiErrorLocation *> *)locations __attribute__((swift_name("locations()"))) __attribute__((deprecated("Use property instead")));
- (NSString * _Nullable)message __attribute__((swift_name("message()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=customAttributes_) NSDictionary<NSString *, id> *customAttributes __attribute__((swift_name("customAttributes")));
@property (readonly, getter=locations_) NSArray<KmpdataApollo_apiErrorLocation *> *locations __attribute__((swift_name("locations")));
@property (readonly, getter=message_) NSString *message __attribute__((swift_name("message")));
@end;

__attribute__((swift_name("Apollo_apiExecutionContext")))
@protocol KmpdataApollo_apiExecutionContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<KmpdataApollo_apiExecutionContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<KmpdataApollo_apiExecutionContextElement> _Nullable)getKey:(id<KmpdataApollo_apiExecutionContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<KmpdataApollo_apiExecutionContext>)minusKeyKey:(id<KmpdataApollo_apiExecutionContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<KmpdataApollo_apiExecutionContext>)plusContext:(id<KmpdataApollo_apiExecutionContext>)context __attribute__((swift_name("plus(context:)")));
@end;

__attribute__((swift_name("OkioSink")))
@protocol KmpdataOkioSink
@required
- (void)close __attribute__((swift_name("close()")));
- (void)flush __attribute__((swift_name("flush()")));
- (KmpdataOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
- (void)writeSource:(KmpdataOkioBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
@end;

__attribute__((swift_name("OkioBufferedSink")))
@protocol KmpdataOkioBufferedSink <KmpdataOkioSink>
@required
- (id<KmpdataOkioBufferedSink>)emit __attribute__((swift_name("emit()")));
- (id<KmpdataOkioBufferedSink>)emitCompleteSegments __attribute__((swift_name("emitCompleteSegments()")));
- (id<KmpdataOkioBufferedSink>)writeSource:(KmpdataKotlinByteArray *)source __attribute__((swift_name("write(source:)")));
- (id<KmpdataOkioBufferedSink>)writeSource:(KmpdataKotlinByteArray *)source offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(source:offset:byteCount:)")));
- (id<KmpdataOkioBufferedSink>)writeByteString:(KmpdataOkioByteString *)byteString __attribute__((swift_name("write(byteString:)")));
- (id<KmpdataOkioBufferedSink>)writeByteString:(KmpdataOkioByteString *)byteString offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(byteString:offset:byteCount:)")));
- (id<KmpdataOkioBufferedSink>)writeSource:(id<KmpdataOkioSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (int64_t)writeAllSource:(id<KmpdataOkioSource>)source __attribute__((swift_name("writeAll(source:)")));
- (id<KmpdataOkioBufferedSink>)writeByteB:(int32_t)b __attribute__((swift_name("writeByte(b:)")));
- (id<KmpdataOkioBufferedSink>)writeDecimalLongV:(int64_t)v __attribute__((swift_name("writeDecimalLong(v:)")));
- (id<KmpdataOkioBufferedSink>)writeHexadecimalUnsignedLongV:(int64_t)v __attribute__((swift_name("writeHexadecimalUnsignedLong(v:)")));
- (id<KmpdataOkioBufferedSink>)writeIntI:(int32_t)i __attribute__((swift_name("writeInt(i:)")));
- (id<KmpdataOkioBufferedSink>)writeIntLeI:(int32_t)i __attribute__((swift_name("writeIntLe(i:)")));
- (id<KmpdataOkioBufferedSink>)writeLongV:(int64_t)v __attribute__((swift_name("writeLong(v:)")));
- (id<KmpdataOkioBufferedSink>)writeLongLeV:(int64_t)v __attribute__((swift_name("writeLongLe(v:)")));
- (id<KmpdataOkioBufferedSink>)writeShortS:(int32_t)s __attribute__((swift_name("writeShort(s:)")));
- (id<KmpdataOkioBufferedSink>)writeShortLeS:(int32_t)s __attribute__((swift_name("writeShortLe(s:)")));
- (id<KmpdataOkioBufferedSink>)writeUtf8String:(NSString *)string __attribute__((swift_name("writeUtf8(string:)")));
- (id<KmpdataOkioBufferedSink>)writeUtf8String:(NSString *)string beginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("writeUtf8(string:beginIndex:endIndex:)")));
- (id<KmpdataOkioBufferedSink>)writeUtf8CodePointCodePoint:(int32_t)codePoint __attribute__((swift_name("writeUtf8CodePoint(codePoint:)")));
@property (readonly) KmpdataOkioBuffer *buffer __attribute__((swift_name("buffer")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OkioBuffer")))
@interface KmpdataOkioBuffer : KmpdataBase <KmpdataOkioBufferedSource, KmpdataOkioBufferedSink>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));
- (void)close __attribute__((swift_name("close()")));
- (int64_t)completeSegmentByteCount __attribute__((swift_name("completeSegmentByteCount()")));
- (KmpdataOkioBuffer *)doCopy __attribute__((swift_name("doCopy()")));
- (KmpdataOkioBuffer *)doCopyToOut:(KmpdataOkioBuffer *)out offset:(int64_t)offset __attribute__((swift_name("doCopyTo(out:offset:)")));
- (KmpdataOkioBuffer *)doCopyToOut:(KmpdataOkioBuffer *)out offset:(int64_t)offset byteCount:(int64_t)byteCount __attribute__((swift_name("doCopyTo(out:offset:byteCount:)")));
- (KmpdataOkioBuffer *)emit __attribute__((swift_name("emit()")));
- (KmpdataOkioBuffer *)emitCompleteSegments __attribute__((swift_name("emitCompleteSegments()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (void)flush __attribute__((swift_name("flush()")));
- (int8_t)getPos:(int64_t)pos __attribute__((swift_name("get(pos:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (int64_t)indexOfB:(int8_t)b __attribute__((swift_name("indexOf(b:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(b:fromIndex:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex toIndex:(int64_t)toIndex __attribute__((swift_name("indexOf(b:fromIndex:toIndex:)")));
- (int64_t)indexOfBytes:(KmpdataOkioByteString *)bytes __attribute__((swift_name("indexOf(bytes:)")));
- (int64_t)indexOfBytes:(KmpdataOkioByteString *)bytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(bytes:fromIndex:)")));
- (int64_t)indexOfElementTargetBytes:(KmpdataOkioByteString *)targetBytes __attribute__((swift_name("indexOfElement(targetBytes:)")));
- (int64_t)indexOfElementTargetBytes:(KmpdataOkioByteString *)targetBytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOfElement(targetBytes:fromIndex:)")));
- (id<KmpdataOkioBufferedSource>)peek __attribute__((swift_name("peek()")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(KmpdataOkioByteString *)bytes __attribute__((swift_name("rangeEquals(offset:bytes:)")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(KmpdataOkioByteString *)bytes bytesOffset:(int32_t)bytesOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:bytes:bytesOffset:byteCount:)")));
- (int32_t)readSink:(KmpdataKotlinByteArray *)sink __attribute__((swift_name("read(sink:)")));
- (int32_t)readSink:(KmpdataKotlinByteArray *)sink offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("read(sink:offset:byteCount:)")));
- (int64_t)readSink:(KmpdataOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("read(sink:byteCount:)")));
- (int64_t)readAllSink:(id<KmpdataOkioSink>)sink __attribute__((swift_name("readAll(sink:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (KmpdataKotlinByteArray *)readByteArray __attribute__((swift_name("readByteArray()")));
- (KmpdataKotlinByteArray *)readByteArrayByteCount:(int64_t)byteCount __attribute__((swift_name("readByteArray(byteCount:)")));
- (KmpdataOkioByteString *)readByteString __attribute__((swift_name("readByteString()")));
- (KmpdataOkioByteString *)readByteStringByteCount:(int64_t)byteCount __attribute__((swift_name("readByteString(byteCount:)")));
- (int64_t)readDecimalLong __attribute__((swift_name("readDecimalLong()")));
- (void)readFullySink:(KmpdataKotlinByteArray *)sink __attribute__((swift_name("readFully(sink:)")));
- (void)readFullySink:(KmpdataOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readFully(sink:byteCount:)")));
- (int64_t)readHexadecimalUnsignedLong __attribute__((swift_name("readHexadecimalUnsignedLong()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int32_t)readIntLe __attribute__((swift_name("readIntLe()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int64_t)readLongLe __attribute__((swift_name("readLongLe()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (int16_t)readShortLe __attribute__((swift_name("readShortLe()")));
- (NSString *)readUtf8 __attribute__((swift_name("readUtf8()")));
- (NSString *)readUtf8ByteCount:(int64_t)byteCount __attribute__((swift_name("readUtf8(byteCount:)")));
- (int32_t)readUtf8CodePoint __attribute__((swift_name("readUtf8CodePoint()")));
- (NSString * _Nullable)readUtf8Line __attribute__((swift_name("readUtf8Line()")));
- (NSString *)readUtf8LineStrict __attribute__((swift_name("readUtf8LineStrict()")));
- (NSString *)readUtf8LineStrictLimit:(int64_t)limit __attribute__((swift_name("readUtf8LineStrict(limit:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (int32_t)selectOptions:(NSArray<KmpdataOkioByteString *> *)options __attribute__((swift_name("select(options:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (KmpdataOkioByteString *)snapshot __attribute__((swift_name("snapshot()")));
- (KmpdataOkioByteString *)snapshotByteCount:(int32_t)byteCount __attribute__((swift_name("snapshot(byteCount:)")));
- (KmpdataOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (KmpdataOkioBuffer *)writeSource:(KmpdataKotlinByteArray *)source __attribute__((swift_name("write(source:)")));
- (KmpdataOkioBuffer *)writeSource:(KmpdataKotlinByteArray *)source offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(source:offset:byteCount:)")));
- (void)writeSource:(KmpdataOkioBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
- (KmpdataOkioBuffer *)writeByteString:(KmpdataOkioByteString *)byteString __attribute__((swift_name("write(byteString:)")));
- (KmpdataOkioBuffer *)writeByteString:(KmpdataOkioByteString *)byteString offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(byteString:offset:byteCount:)")));
- (KmpdataOkioBuffer *)writeSource:(id<KmpdataOkioSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (int64_t)writeAllSource:(id<KmpdataOkioSource>)source __attribute__((swift_name("writeAll(source:)")));
- (KmpdataOkioBuffer *)writeByteB:(int32_t)b __attribute__((swift_name("writeByte(b:)")));
- (KmpdataOkioBuffer *)writeDecimalLongV:(int64_t)v __attribute__((swift_name("writeDecimalLong(v:)")));
- (KmpdataOkioBuffer *)writeHexadecimalUnsignedLongV:(int64_t)v __attribute__((swift_name("writeHexadecimalUnsignedLong(v:)")));
- (KmpdataOkioBuffer *)writeIntI:(int32_t)i __attribute__((swift_name("writeInt(i:)")));
- (KmpdataOkioBuffer *)writeIntLeI:(int32_t)i __attribute__((swift_name("writeIntLe(i:)")));
- (KmpdataOkioBuffer *)writeLongV:(int64_t)v __attribute__((swift_name("writeLong(v:)")));
- (KmpdataOkioBuffer *)writeLongLeV:(int64_t)v __attribute__((swift_name("writeLongLe(v:)")));
- (KmpdataOkioBuffer *)writeShortS:(int32_t)s __attribute__((swift_name("writeShort(s:)")));
- (KmpdataOkioBuffer *)writeShortLeS:(int32_t)s __attribute__((swift_name("writeShortLe(s:)")));
- (KmpdataOkioBuffer *)writeUtf8String:(NSString *)string __attribute__((swift_name("writeUtf8(string:)")));
- (KmpdataOkioBuffer *)writeUtf8String:(NSString *)string beginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("writeUtf8(string:beginIndex:endIndex:)")));
- (KmpdataOkioBuffer *)writeUtf8CodePointCodePoint:(int32_t)codePoint __attribute__((swift_name("writeUtf8CodePoint(codePoint:)")));
@property (readonly) KmpdataOkioBuffer *buffer __attribute__((swift_name("buffer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("OkioTimeout")))
@interface KmpdataOkioTimeout : KmpdataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end;

__attribute__((swift_name("Apollo_apiInputFieldMarshaller")))
@protocol KmpdataApollo_apiInputFieldMarshaller
@required
- (void)marshalWriter_:(id<KmpdataApollo_apiInputFieldWriter>)writer __attribute__((swift_name("marshal(writer_:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseWriter")))
@protocol KmpdataApollo_apiResponseWriter
@required
- (void)writeBooleanField:(KmpdataApollo_apiResponseField *)field value:(KmpdataBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(field:value:)")));
- (void)writeCustomField:(KmpdataApollo_apiResponseFieldCustomTypeField *)field value:(id _Nullable)value __attribute__((swift_name("writeCustom(field:value:)")));
- (void)writeDoubleField:(KmpdataApollo_apiResponseField *)field value:(KmpdataDouble * _Nullable)value __attribute__((swift_name("writeDouble(field:value:)")));
- (void)writeFragmentMarshaller:(id<KmpdataApollo_apiResponseFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeFragment(marshaller:)")));
- (void)writeIntField:(KmpdataApollo_apiResponseField *)field value:(KmpdataInt * _Nullable)value __attribute__((swift_name("writeInt(field:value:)")));
- (void)writeListField:(KmpdataApollo_apiResponseField *)field values:(NSArray<id> * _Nullable)values block:(void (^)(NSArray<id> * _Nullable, id<KmpdataApollo_apiResponseWriterListItemWriter>))block __attribute__((swift_name("writeList(field:values:block:)")));
- (void)writeListField:(KmpdataApollo_apiResponseField *)field values:(NSArray<id> * _Nullable)values listWriter:(id<KmpdataApollo_apiResponseWriterListWriter>)listWriter __attribute__((swift_name("writeList(field:values:listWriter:)")));
- (void)writeLongField:(KmpdataApollo_apiResponseField *)field value:(KmpdataLong * _Nullable)value __attribute__((swift_name("writeLong(field:value:)")));
- (void)writeObjectField:(KmpdataApollo_apiResponseField *)field marshaller:(id<KmpdataApollo_apiResponseFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(field:marshaller:)")));
- (void)writeStringField:(KmpdataApollo_apiResponseField *)field value:(NSString * _Nullable)value __attribute__((swift_name("writeString(field:value:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseField")))
@interface KmpdataApollo_apiResponseField : KmpdataBase
- (NSDictionary<NSString *, id> *)arguments __attribute__((swift_name("arguments()"))) __attribute__((deprecated("Use property instead")));
- (NSArray<KmpdataApollo_apiResponseFieldCondition *> *)conditions __attribute__((swift_name("conditions()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSString *)fieldName __attribute__((swift_name("fieldName()"))) __attribute__((deprecated("Use property instead")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)optional __attribute__((swift_name("optional()"))) __attribute__((deprecated("Use property instead")));
- (id _Nullable)resolveArgumentName:(NSString *)name variables:(KmpdataApollo_apiOperationVariables *)variables __attribute__((swift_name("resolveArgument(name:variables:)")));
- (NSString *)responseName __attribute__((swift_name("responseName()"))) __attribute__((deprecated("Use property instead")));
- (KmpdataApollo_apiResponseFieldType *)type __attribute__((swift_name("type()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=arguments_) NSDictionary<NSString *, id> *arguments __attribute__((swift_name("arguments")));
@property (readonly, getter=conditions_) NSArray<KmpdataApollo_apiResponseFieldCondition *> *conditions __attribute__((swift_name("conditions")));
@property (readonly, getter=fieldName_) NSString *fieldName __attribute__((swift_name("fieldName")));
@property (readonly, getter=optional_) BOOL optional __attribute__((swift_name("optional")));
@property (readonly, getter=responseName_) NSString *responseName __attribute__((swift_name("responseName")));
@property (readonly, getter=type_) KmpdataApollo_apiResponseFieldType *type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponseField.CustomTypeField")))
@interface KmpdataApollo_apiResponseFieldCustomTypeField : KmpdataApollo_apiResponseField
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (id<KmpdataApollo_apiScalarType>)scalarType __attribute__((swift_name("scalarType()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=scalarType_) id<KmpdataApollo_apiScalarType> scalarType __attribute__((swift_name("scalarType")));
@end;

__attribute__((swift_name("Apollo_apiResponseReaderObjectReader")))
@protocol KmpdataApollo_apiResponseReaderObjectReader
@required
- (id)readReader:(id<KmpdataApollo_apiResponseReader>)reader __attribute__((swift_name("read(reader:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseReaderListItemReader")))
@protocol KmpdataApollo_apiResponseReaderListItemReader
@required
- (BOOL)readBoolean __attribute__((swift_name("readBoolean()")));
- (id)readCustomTypeScalarType:(id<KmpdataApollo_apiScalarType>)scalarType __attribute__((swift_name("readCustomType(scalarType:)")));
- (double)readDouble __attribute__((swift_name("readDouble()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (NSArray<id> *)readListBlock:(id (^)(id<KmpdataApollo_apiResponseReaderListItemReader>))block __attribute__((swift_name("readList(block:)")));
- (NSArray<id> *)readListListReader:(id<KmpdataApollo_apiResponseReaderListReader>)listReader __attribute__((swift_name("readList(listReader:)")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (id)readObjectBlock:(id (^)(id<KmpdataApollo_apiResponseReader>))block __attribute__((swift_name("readObject(block:)")));
- (id)readObjectObjectReader:(id<KmpdataApollo_apiResponseReaderObjectReader>)objectReader __attribute__((swift_name("readObject(objectReader:)")));
- (NSString *)readString __attribute__((swift_name("readString()")));
@end;

__attribute__((swift_name("Apollo_apiResponseReaderListReader")))
@protocol KmpdataApollo_apiResponseReaderListReader
@required
- (id)readReader_:(id<KmpdataApollo_apiResponseReaderListItemReader>)reader __attribute__((swift_name("read(reader_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface KmpdataKtor_client_coreHttpClient : KmpdataBase <KmpdataKotlinx_coroutines_coreCoroutineScope, KmpdataKtor_ioCloseable>
- (instancetype)initWithEngine:(id<KmpdataKtor_client_coreHttpClientEngine>)engine userConfig:(KmpdataKtor_client_coreHttpClientConfig<KmpdataKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (KmpdataKtor_client_coreHttpClient *)configBlock:(void (^)(KmpdataKtor_client_coreHttpClientConfig<KmpdataKtor_client_coreHttpClientEngineConfig *> *))block __attribute__((swift_name("config(block:)")));
- (BOOL)isSupportedCapability:(id<KmpdataKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<KmpdataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<KmpdataKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) KmpdataKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher"))) __attribute__((unavailable("[dispatcher] is deprecated. Use coroutineContext instead.")));
@property (readonly) id<KmpdataKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) KmpdataKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) KmpdataKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) KmpdataKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) KmpdataKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) KmpdataKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface KmpdataKtor_client_coreHttpClientEngineConfig : KmpdataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property KmpdataKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property (readonly) KmpdataKotlinNothing *response __attribute__((swift_name("response"))) __attribute__((unavailable("Response config is deprecated. See [HttpPlainText] feature for charset configuration")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount")));
@end;

__attribute__((swift_name("KotlinCoroutineContext")))
@protocol KmpdataKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation_:(id _Nullable (^)(id _Nullable, id<KmpdataKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation_:)")));
- (id<KmpdataKotlinCoroutineContextElement> _Nullable)getKey_:(id<KmpdataKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key_:)")));
- (id<KmpdataKotlinCoroutineContext>)minusKeyKey_:(id<KmpdataKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key_:)")));
- (id<KmpdataKotlinCoroutineContext>)plusContext_:(id<KmpdataKotlinCoroutineContext>)context __attribute__((swift_name("plus(context_:)")));
@end;

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol KmpdataKotlinCoroutineContextElement <KmpdataKotlinCoroutineContext>
@required
@property (readonly) id<KmpdataKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface KmpdataKotlinAbstractCoroutineContextElement : KmpdataBase <KmpdataKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<KmpdataKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<KmpdataKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol KmpdataKotlinContinuationInterceptor <KmpdataKotlinCoroutineContextElement>
@required
- (id<KmpdataKotlinContinuation>)interceptContinuationContinuation:(id<KmpdataKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<KmpdataKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface KmpdataKotlinx_coroutines_coreCoroutineDispatcher : KmpdataKotlinAbstractCoroutineContextElement <KmpdataKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<KmpdataKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)dispatchContext:(id<KmpdataKotlinCoroutineContext>)context block:(id<KmpdataKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<KmpdataKotlinCoroutineContext>)context block:(id<KmpdataKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<KmpdataKotlinContinuation>)interceptContinuationContinuation:(id<KmpdataKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<KmpdataKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (KmpdataKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(KmpdataKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<KmpdataKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol KmpdataKtor_client_coreHttpClientEngineCapability
@required
@end;

__attribute__((swift_name("Apollo_runtime_kotlinNetworkTransport")))
@protocol KmpdataApollo_runtime_kotlinNetworkTransport
@required
- (id<KmpdataKotlinx_coroutines_coreFlow>)executeRequest:(KmpdataApollo_runtime_kotlinGraphQLRequest *)request __attribute__((swift_name("execute(request:)")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloRequestInterceptor")))
@protocol KmpdataApollo_runtime_kotlinApolloRequestInterceptor
@required
- (id<KmpdataKotlinx_coroutines_coreFlow>)interceptRequest:(KmpdataApollo_runtime_kotlinApolloRequest<id> *)request interceptorChain:(id<KmpdataApollo_runtime_kotlinApolloInterceptorChain>)interceptorChain __attribute__((swift_name("intercept(request:interceptorChain:)")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloCall")))
@protocol KmpdataApollo_runtime_kotlinApolloCall
@required
- (id<KmpdataKotlinx_coroutines_coreFlow>)execute __attribute__((swift_name("execute()")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloMutationCall")))
@protocol KmpdataApollo_runtime_kotlinApolloMutationCall <KmpdataApollo_runtime_kotlinApolloCall>
@required
@end;

__attribute__((swift_name("Apollo_apiMutation")))
@protocol KmpdataApollo_apiMutation <KmpdataApollo_apiOperation>
@required
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloQueryCall")))
@protocol KmpdataApollo_runtime_kotlinApolloQueryCall <KmpdataApollo_runtime_kotlinApolloCall>
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeEncoder")))
@protocol KmpdataKotlinx_serialization_runtimeEncoder
@required
- (id<KmpdataKotlinx_serialization_runtimeCompositeEncoder>)beginCollectionDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize typeSerializers:(KmpdataKotlinArray<id<KmpdataKotlinx_serialization_runtimeKSerializer>> *)typeSerializers __attribute__((swift_name("beginCollection(descriptor:collectionSize:typeSerializers:)")));
- (id<KmpdataKotlinx_serialization_runtimeCompositeEncoder>)beginStructureDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor typeSerializers:(KmpdataKotlinArray<id<KmpdataKotlinx_serialization_runtimeKSerializer>> *)typeSerializers __attribute__((swift_name("beginStructure(descriptor:typeSerializers:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));
- (void)encodeNull __attribute__((swift_name("encodeNull()")));
- (void)encodeNullableSerializableValueSerializer:(id<KmpdataKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<KmpdataKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
- (void)encodeUnit __attribute__((swift_name("encodeUnit()")));
@property (readonly) id<KmpdataKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialDescriptor")))
@protocol KmpdataKotlinx_serialization_runtimeSerialDescriptor
@required
- (NSArray<id<KmpdataKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (NSArray<id<KmpdataKotlinAnnotation>> *)getEntityAnnotations __attribute__((swift_name("getEntityAnnotations()"))) __attribute__((deprecated("Deprecated in the favour of 'annotations' property")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<KmpdataKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) KmpdataKotlinx_serialization_runtimeSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly, getter=name_) NSString *name __attribute__((swift_name("name"))) __attribute__((unavailable("name property deprecated in the favour of serialName")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeDecoder")))
@protocol KmpdataKotlinx_serialization_runtimeDecoder
@required
- (id<KmpdataKotlinx_serialization_runtimeCompositeDecoder>)beginStructureDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor typeParams:(KmpdataKotlinArray<id<KmpdataKotlinx_serialization_runtimeKSerializer>> *)typeParams __attribute__((swift_name("beginStructure(descriptor:typeParams:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));
- (KmpdataKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<KmpdataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<KmpdataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
- (void)decodeUnit __attribute__((swift_name("decodeUnit()")));
- (id _Nullable)updateNullableSerializableValueDeserializer:(id<KmpdataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateNullableSerializableValue(deserializer:old:)")));
- (id _Nullable)updateSerializableValueDeserializer:(id<KmpdataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateSerializableValue(deserializer:old:)")));
@property (readonly) id<KmpdataKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@property (readonly) KmpdataKotlinx_serialization_runtimeUpdateMode *updateMode __attribute__((swift_name("updateMode")));
@end;

__attribute__((swift_name("KotlinByteIterator")))
@interface KmpdataKotlinByteIterator : KmpdataBase <KmpdataKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (KmpdataByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end;

__attribute__((swift_name("Apollo_apiCustomTypeValue")))
@interface KmpdataApollo_apiCustomTypeValue<T> : KmpdataBase
@property (readonly) T _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiError.Location")))
@interface KmpdataApollo_apiErrorLocation : KmpdataBase
- (instancetype)initWithLine:(int64_t)line column:(int64_t)column __attribute__((swift_name("init(line:column:)"))) __attribute__((objc_designated_initializer));
- (int64_t)column __attribute__((swift_name("column()"))) __attribute__((deprecated("Use property instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (int64_t)line __attribute__((swift_name("line()"))) __attribute__((deprecated("Use property instead")));
@property (readonly, getter=column_) int64_t column __attribute__((swift_name("column")));
@property (readonly, getter=line_) int64_t line __attribute__((swift_name("line")));
@end;

__attribute__((swift_name("Apollo_apiExecutionContextElement")))
@protocol KmpdataApollo_apiExecutionContextElement <KmpdataApollo_apiExecutionContext>
@required
@property (readonly) id<KmpdataApollo_apiExecutionContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("Apollo_apiExecutionContextKey")))
@protocol KmpdataApollo_apiExecutionContextKey
@required
@end;

__attribute__((swift_name("Apollo_apiInputFieldWriter")))
@protocol KmpdataApollo_apiInputFieldWriter
@required
- (void)writeBooleanFieldName:(NSString *)fieldName value:(KmpdataBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(fieldName:value:)")));
- (void)writeCustomFieldName:(NSString *)fieldName scalarType:(id<KmpdataApollo_apiScalarType>)scalarType value:(id _Nullable)value __attribute__((swift_name("writeCustom(fieldName:scalarType:value:)")));
- (void)writeDoubleFieldName:(NSString *)fieldName value:(KmpdataDouble * _Nullable)value __attribute__((swift_name("writeDouble(fieldName:value:)")));
- (void)writeIntFieldName:(NSString *)fieldName value:(KmpdataInt * _Nullable)value __attribute__((swift_name("writeInt(fieldName:value:)")));
- (void)writeListFieldName:(NSString *)fieldName block:(void (^)(id<KmpdataApollo_apiInputFieldWriterListItemWriter>))block __attribute__((swift_name("writeList(fieldName:block:)")));
- (void)writeListFieldName:(NSString *)fieldName listWriter:(id<KmpdataApollo_apiInputFieldWriterListWriter> _Nullable)listWriter __attribute__((swift_name("writeList(fieldName:listWriter:)")));
- (void)writeLongFieldName:(NSString *)fieldName value:(KmpdataLong * _Nullable)value __attribute__((swift_name("writeLong(fieldName:value:)")));
- (void)writeMapFieldName:(NSString *)fieldName value:(NSDictionary<NSString *, id> * _Nullable)value __attribute__((swift_name("writeMap(fieldName:value:)")));
- (void)writeNumberFieldName:(NSString *)fieldName value:(id _Nullable)value __attribute__((swift_name("writeNumber(fieldName:value:)")));
- (void)writeObjectFieldName:(NSString *)fieldName marshaller:(id<KmpdataApollo_apiInputFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(fieldName:marshaller:)")));
- (void)writeStringFieldName:(NSString *)fieldName value:(NSString * _Nullable)value __attribute__((swift_name("writeString(fieldName:value:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseWriterListItemWriter")))
@protocol KmpdataApollo_apiResponseWriterListItemWriter
@required
- (void)writeBooleanValue:(KmpdataBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(value:)")));
- (void)writeCustomScalarType:(id<KmpdataApollo_apiScalarType>)scalarType value:(id _Nullable)value __attribute__((swift_name("writeCustom(scalarType:value:)")));
- (void)writeDoubleValue:(KmpdataDouble * _Nullable)value __attribute__((swift_name("writeDouble(value:)")));
- (void)writeIntValue:(KmpdataInt * _Nullable)value __attribute__((swift_name("writeInt(value:)")));
- (void)writeListItems:(NSArray<id> * _Nullable)items block:(void (^)(NSArray<id> * _Nullable, id<KmpdataApollo_apiResponseWriterListItemWriter>))block __attribute__((swift_name("writeList(items:block:)")));
- (void)writeListItems:(NSArray<id> * _Nullable)items listWriter:(id<KmpdataApollo_apiResponseWriterListWriter>)listWriter __attribute__((swift_name("writeList(items:listWriter:)")));
- (void)writeLongValue:(KmpdataLong * _Nullable)value __attribute__((swift_name("writeLong(value:)")));
- (void)writeObjectMarshaller:(id<KmpdataApollo_apiResponseFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(marshaller:)")));
- (void)writeStringValue:(NSString * _Nullable)value __attribute__((swift_name("writeString(value:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseWriterListWriter")))
@protocol KmpdataApollo_apiResponseWriterListWriter
@required
- (void)writeItems:(NSArray<id> * _Nullable)items listItemWriter:(id<KmpdataApollo_apiResponseWriterListItemWriter>)listItemWriter __attribute__((swift_name("write(items:listItemWriter:)")));
@end;

__attribute__((swift_name("Apollo_apiResponseField.Condition")))
@interface KmpdataApollo_apiResponseFieldCondition : KmpdataBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiResponseField.Type_")))
@interface KmpdataApollo_apiResponseFieldType : KmpdataKotlinEnum<KmpdataApollo_apiResponseFieldType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) KmpdataApollo_apiResponseFieldType *string __attribute__((swift_name("string")));
@property (class, readonly) KmpdataApollo_apiResponseFieldType *int_ __attribute__((swift_name("int_")));
@property (class, readonly) KmpdataApollo_apiResponseFieldType *long_ __attribute__((swift_name("long_")));
@property (class, readonly) KmpdataApollo_apiResponseFieldType *double_ __attribute__((swift_name("double_")));
@property (class, readonly) KmpdataApollo_apiResponseFieldType *boolean __attribute__((swift_name("boolean")));
@property (class, readonly) KmpdataApollo_apiResponseFieldType *enum_ __attribute__((swift_name("enum_")));
@property (class, readonly) KmpdataApollo_apiResponseFieldType *object __attribute__((swift_name("object")));
@property (class, readonly) KmpdataApollo_apiResponseFieldType *list __attribute__((swift_name("list")));
@property (class, readonly) KmpdataApollo_apiResponseFieldType *custom __attribute__((swift_name("custom")));
@property (class, readonly) KmpdataApollo_apiResponseFieldType *fragment __attribute__((swift_name("fragment")));
@property (class, readonly) KmpdataApollo_apiResponseFieldType *fragments __attribute__((swift_name("fragments")));
- (int32_t)compareToOther:(KmpdataApollo_apiResponseFieldType *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface KmpdataKtor_client_coreHttpClientConfig<T> : KmpdataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (KmpdataKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(KmpdataKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installFeature:(id<KmpdataKtor_client_coreHttpClientFeature>)feature configure:(void (^)(id))configure __attribute__((swift_name("install(feature:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(KmpdataKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(KmpdataKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end;

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol KmpdataKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(KmpdataKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(KmpdataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey__:(KmpdataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key__:)")));
- (id _Nullable)getOrNullKey:(KmpdataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(KmpdataKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey:(KmpdataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));
- (id)takeKey:(KmpdataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(KmpdataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<KmpdataKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end;

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface KmpdataKtor_utilsPipeline<TSubject, TContext> : KmpdataBase
- (instancetype)initWithPhase:(KmpdataKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<KmpdataKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(KmpdataKotlinArray<KmpdataKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(KmpdataKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));
- (void)insertPhaseAfterReference:(KmpdataKtor_utilsPipelinePhase *)reference phase:(KmpdataKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(KmpdataKtor_utilsPipelinePhase *)reference phase:(KmpdataKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(KmpdataKtor_utilsPipelinePhase *)phase block:(id<KmpdataKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (void)mergeFrom:(KmpdataKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
@property (readonly) id<KmpdataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<KmpdataKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface KmpdataKtor_client_coreHttpReceivePipeline : KmpdataKtor_utilsPipeline<KmpdataKtor_client_coreHttpResponse *, KmpdataKtor_client_coreHttpClientCall *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(KmpdataKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<KmpdataKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(KmpdataKotlinArray<KmpdataKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(KmpdataKtor_utilsPipeline<KmpdataKtor_client_coreHttpResponse *, KmpdataKtor_client_coreHttpClientCall *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface KmpdataKtor_client_coreHttpRequestPipeline : KmpdataKtor_utilsPipeline<id, KmpdataKtor_client_coreHttpRequestBuilder *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(KmpdataKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<KmpdataKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(KmpdataKotlinArray<KmpdataKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(KmpdataKtor_utilsPipeline<id, KmpdataKtor_client_coreHttpRequestBuilder *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface KmpdataKtor_client_coreHttpResponsePipeline : KmpdataKtor_utilsPipeline<KmpdataKtor_client_coreHttpResponseContainer *, KmpdataKtor_client_coreHttpClientCall *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(KmpdataKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<KmpdataKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(KmpdataKotlinArray<KmpdataKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(KmpdataKtor_utilsPipeline<KmpdataKtor_client_coreHttpResponseContainer *, KmpdataKtor_client_coreHttpClientCall *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface KmpdataKtor_client_coreHttpSendPipeline : KmpdataKtor_utilsPipeline<id, KmpdataKtor_client_coreHttpRequestBuilder *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(KmpdataKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<KmpdataKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(KmpdataKotlinArray<KmpdataKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)mergeFrom:(KmpdataKtor_utilsPipeline<id, KmpdataKtor_client_coreHttpRequestBuilder *> *)from __attribute__((swift_name("merge(from:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface KmpdataKtor_client_coreProxyConfig : KmpdataBase
- (instancetype)initWithUrl:(KmpdataKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) KmpdataKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol KmpdataKotlinCoroutineContextKey
@required
@end;

__attribute__((swift_name("KotlinContinuation")))
@protocol KmpdataKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<KmpdataKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol KmpdataKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol KmpdataKotlinx_coroutines_coreFlow
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtime_kotlinGraphQLRequest")))
@interface KmpdataApollo_runtime_kotlinGraphQLRequest : KmpdataBase
- (instancetype)initWithOperationName:(NSString *)operationName operationId:(NSString *)operationId document:(NSString *)document variables:(NSString *)variables extensions:(NSString *)extensions __attribute__((swift_name("init(operationName:operationId:document:variables:extensions:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *document __attribute__((swift_name("document")));
@property (readonly) NSString *extensions __attribute__((swift_name("extensions")));
@property (readonly) NSString *operationId __attribute__((swift_name("operationId")));
@property (readonly) NSString *operationName __attribute__((swift_name("operationName")));
@property (readonly) NSString *variables __attribute__((swift_name("variables")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtime_kotlinApolloRequest")))
@interface KmpdataApollo_runtime_kotlinApolloRequest<T> : KmpdataBase
- (instancetype)initWithOperation:(id<KmpdataApollo_apiOperation>)operation scalarTypeAdapters:(KmpdataApollo_apiScalarTypeAdapters *)scalarTypeAdapters executionContext:(id<KmpdataApollo_apiExecutionContext>)executionContext __attribute__((swift_name("init(operation:scalarTypeAdapters:executionContext:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<KmpdataApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<KmpdataApollo_apiOperation> operation __attribute__((swift_name("operation")));
@property (readonly) KmpdataApollo_apiScalarTypeAdapters *scalarTypeAdapters __attribute__((swift_name("scalarTypeAdapters")));
@end;

__attribute__((swift_name("Apollo_runtime_kotlinApolloInterceptorChain")))
@protocol KmpdataApollo_runtime_kotlinApolloInterceptorChain
@required
- (BOOL)canProceed __attribute__((swift_name("canProceed()")));
- (id<KmpdataKotlinx_coroutines_coreFlow>)proceedRequest:(KmpdataApollo_runtime_kotlinApolloRequest<id> *)request __attribute__((swift_name("proceed(request:)")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeCompositeEncoder")))
@protocol KmpdataKotlinx_serialization_runtimeCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (void)encodeIntElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));
- (void)encodeNonSerializableElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(id)value __attribute__((swift_name("encodeNonSerializableElement(descriptor:index:value:)"))) __attribute__((unavailable("This method is deprecated for removal. Please remove it from your implementation and delegate to default method instead")));
- (void)encodeNullableSerializableElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<KmpdataKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<KmpdataKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)encodeUnitElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeUnitElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) id<KmpdataKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialModule")))
@protocol KmpdataKotlinx_serialization_runtimeSerialModule
@required
- (void)dumpToCollector:(id<KmpdataKotlinx_serialization_runtimeSerialModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));
- (id<KmpdataKotlinx_serialization_runtimeKSerializer> _Nullable)getContextualKclass:(id<KmpdataKotlinKClass>)kclass __attribute__((swift_name("getContextual(kclass:)")));
- (id<KmpdataKotlinx_serialization_runtimeKSerializer> _Nullable)getPolymorphicBaseClass:(id<KmpdataKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));
- (id<KmpdataKotlinx_serialization_runtimeKSerializer> _Nullable)getPolymorphicBaseClass:(id<KmpdataKotlinKClass>)baseClass serializedClassName:(NSString *)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end;

__attribute__((swift_name("KotlinAnnotation")))
@protocol KmpdataKotlinAnnotation
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialKind")))
@interface KmpdataKotlinx_serialization_runtimeSerialKind : KmpdataBase
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeCompositeDecoder")))
@protocol KmpdataKotlinx_serialization_runtimeCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<KmpdataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:)")));
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<KmpdataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:)")));
- (int16_t)decodeShortElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)decodeUnitElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeUnitElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
- (id _Nullable)updateNullableSerializableElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<KmpdataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateNullableSerializableElement(descriptor:index:deserializer:old:)")));
- (id _Nullable)updateSerializableElementDescriptor:(id<KmpdataKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<KmpdataKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateSerializableElement(descriptor:index:deserializer:old:)")));
@property (readonly) id<KmpdataKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@property (readonly) KmpdataKotlinx_serialization_runtimeUpdateMode *updateMode __attribute__((swift_name("updateMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_runtimeUpdateMode")))
@interface KmpdataKotlinx_serialization_runtimeUpdateMode : KmpdataKotlinEnum<KmpdataKotlinx_serialization_runtimeUpdateMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) KmpdataKotlinx_serialization_runtimeUpdateMode *banned __attribute__((swift_name("banned")));
@property (class, readonly) KmpdataKotlinx_serialization_runtimeUpdateMode *overwrite __attribute__((swift_name("overwrite")));
@property (class, readonly) KmpdataKotlinx_serialization_runtimeUpdateMode *update __attribute__((swift_name("update")));
- (int32_t)compareToOther:(KmpdataKotlinx_serialization_runtimeUpdateMode *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("Apollo_apiInputFieldWriterListItemWriter")))
@protocol KmpdataApollo_apiInputFieldWriterListItemWriter
@required
- (void)writeBooleanValue:(KmpdataBoolean * _Nullable)value __attribute__((swift_name("writeBoolean(value:)")));
- (void)writeCustomScalarType:(id<KmpdataApollo_apiScalarType>)scalarType value:(id _Nullable)value __attribute__((swift_name("writeCustom(scalarType:value:)")));
- (void)writeDoubleValue:(KmpdataDouble * _Nullable)value __attribute__((swift_name("writeDouble(value:)")));
- (void)writeIntValue:(KmpdataInt * _Nullable)value __attribute__((swift_name("writeInt(value:)")));
- (void)writeListBlock:(void (^)(id<KmpdataApollo_apiInputFieldWriterListItemWriter>))block __attribute__((swift_name("writeList(block:)")));
- (void)writeListListWriter:(id<KmpdataApollo_apiInputFieldWriterListWriter> _Nullable)listWriter __attribute__((swift_name("writeList(listWriter:)")));
- (void)writeLongValue:(KmpdataLong * _Nullable)value __attribute__((swift_name("writeLong(value:)")));
- (void)writeMapValue:(NSDictionary<NSString *, id> * _Nullable)value __attribute__((swift_name("writeMap(value:)")));
- (void)writeNumberValue:(id _Nullable)value __attribute__((swift_name("writeNumber(value:)")));
- (void)writeObjectMarshaller_:(id<KmpdataApollo_apiInputFieldMarshaller> _Nullable)marshaller __attribute__((swift_name("writeObject(marshaller_:)")));
- (void)writeStringValue:(NSString * _Nullable)value __attribute__((swift_name("writeString(value:)")));
@end;

__attribute__((swift_name("Apollo_apiInputFieldWriterListWriter")))
@protocol KmpdataApollo_apiInputFieldWriterListWriter
@required
- (void)writeListItemWriter:(id<KmpdataApollo_apiInputFieldWriterListItemWriter>)listItemWriter __attribute__((swift_name("write(listItemWriter:)")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientFeature")))
@protocol KmpdataKtor_client_coreHttpClientFeature
@required
- (void)installFeature:(id)feature scope:(KmpdataKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(feature:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) KmpdataKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface KmpdataKtor_utilsAttributeKey<T> : KmpdataBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface KmpdataKtor_utilsPipelinePhase : KmpdataBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol KmpdataKotlinSuspendFunction2 <KmpdataKotlinFunction>
@required
@end;

__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol KmpdataKtor_httpHttpMessage
@required
@property (readonly) id<KmpdataKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface KmpdataKtor_client_coreHttpResponse : KmpdataBase <KmpdataKtor_httpHttpMessage, KmpdataKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) KmpdataKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) id<KmpdataKtor_ioByteReadChannel> content __attribute__((swift_name("content")));
@property (readonly) KmpdataKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) KmpdataKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) KmpdataKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));
@property (readonly) KmpdataKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface KmpdataKtor_client_coreHttpClientCall : KmpdataBase <KmpdataKotlinx_coroutines_coreCoroutineScope>
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<KmpdataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) KmpdataKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<KmpdataKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<KmpdataKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));
@property (readonly) KmpdataKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end;

__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol KmpdataKtor_httpHttpMessageBuilder
@required
@property (readonly) KmpdataKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface KmpdataKtor_client_coreHttpRequestBuilder : KmpdataBase <KmpdataKtor_httpHttpMessageBuilder>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (KmpdataKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));
- (id _Nullable)getCapabilityOrNullKey:(id<KmpdataKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (void)setAttributesBlock:(void (^)(id<KmpdataKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));
- (void)setCapabilityKey:(id<KmpdataKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));
- (KmpdataKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(KmpdataKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));
- (KmpdataKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(KmpdataKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));
- (void)urlBlock:(void (^)(KmpdataKtor_httpURLBuilder *, KmpdataKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));
@property (readonly) id<KmpdataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property id body __attribute__((swift_name("body")));
@property (readonly) id<KmpdataKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) KmpdataKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@property KmpdataKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) KmpdataKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface KmpdataKtor_client_coreHttpResponseContainer : KmpdataBase
- (instancetype)initWithExpectedType:(KmpdataKtor_client_coreTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (KmpdataKtor_client_coreTypeInfo *)component1 __attribute__((swift_name("component1()")));
- (id)component2 __attribute__((swift_name("component2()")));
- (KmpdataKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(KmpdataKtor_client_coreTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) KmpdataKtor_client_coreTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface KmpdataKtor_httpUrl : KmpdataBase
- (instancetype)initWithProtocol:(KmpdataKtor_httpURLProtocol *)protocol host:(NSString *)host specifiedPort:(int32_t)specifiedPort encodedPath:(NSString *)encodedPath parameters:(id<KmpdataKtor_httpParameters>)parameters fragment:(NSString *)fragment user:(NSString * _Nullable)user password:(NSString * _Nullable)password trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:specifiedPort:encodedPath:parameters:fragment:user:password:trailingQuery:)"))) __attribute__((objc_designated_initializer));
- (KmpdataKtor_httpURLProtocol *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (id<KmpdataKtor_httpParameters>)component5 __attribute__((swift_name("component5()")));
- (NSString *)component6 __attribute__((swift_name("component6()")));
- (NSString * _Nullable)component7 __attribute__((swift_name("component7()")));
- (NSString * _Nullable)component8 __attribute__((swift_name("component8()")));
- (BOOL)component9 __attribute__((swift_name("component9()")));
- (KmpdataKtor_httpUrl *)doCopyProtocol:(KmpdataKtor_httpURLProtocol *)protocol host:(NSString *)host specifiedPort:(int32_t)specifiedPort encodedPath:(NSString *)encodedPath parameters:(id<KmpdataKtor_httpParameters>)parameters fragment:(NSString *)fragment user:(NSString * _Nullable)user password:(NSString * _Nullable)password trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("doCopy(protocol:host:specifiedPort:encodedPath:parameters:fragment:user:password:trailingQuery:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<KmpdataKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) KmpdataKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialModuleCollector")))
@protocol KmpdataKotlinx_serialization_runtimeSerialModuleCollector
@required
- (void)contextualKClass:(id<KmpdataKotlinKClass>)kClass serializer:(id<KmpdataKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<KmpdataKotlinKClass>)baseClass actualClass:(id<KmpdataKotlinKClass>)actualClass actualSerializer:(id<KmpdataKotlinx_serialization_runtimeKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
@end;

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol KmpdataKotlinKDeclarationContainer
@required
@end;

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol KmpdataKotlinKAnnotatedElement
@required
@end;

__attribute__((swift_name("KotlinKClassifier")))
@protocol KmpdataKotlinKClassifier
@required
@end;

__attribute__((swift_name("KotlinKClass")))
@protocol KmpdataKotlinKClass <KmpdataKotlinKDeclarationContainer, KmpdataKotlinKAnnotatedElement, KmpdataKotlinKClassifier>
@required
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end;

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol KmpdataKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<KmpdataKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty_ __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end;

__attribute__((swift_name("Ktor_httpHeaders")))
@protocol KmpdataKtor_httpHeaders <KmpdataKtor_utilsStringValues>
@required
@end;

__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol KmpdataKtor_ioByteReadChannel
@required
- (BOOL)cancelCause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));
- (void)readSessionConsumer:(void (^)(id<KmpdataKtor_ioReadSession>))consumer __attribute__((swift_name("readSession(consumer:)"))) __attribute__((deprecated("Use read { } instead.")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) BOOL isClosedForWrite __attribute__((swift_name("isClosedForWrite")));
@property KmpdataKtor_ioByteOrder *readByteOrder __attribute__((swift_name("readByteOrder"))) __attribute__((unavailable("Setting byte order is no longer supported. Read/write in big endian and use reverseByteOrder() extensions.")));
@property (readonly) int64_t totalBytesRead __attribute__((swift_name("totalBytesRead"))) __attribute__((deprecated("Don't use byte count")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface KmpdataKtor_utilsGMTDate : KmpdataBase <KmpdataKotlinComparable>
- (int32_t)compareToOther:(KmpdataKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (KmpdataKtor_utilsWeekDay *)component4 __attribute__((swift_name("component4()")));
- (int32_t)component5 __attribute__((swift_name("component5()")));
- (int32_t)component6 __attribute__((swift_name("component6()")));
- (KmpdataKtor_utilsMonth *)component7 __attribute__((swift_name("component7()")));
- (int32_t)component8 __attribute__((swift_name("component8()")));
- (int64_t)component9 __attribute__((swift_name("component9()")));
- (KmpdataKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(KmpdataKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(KmpdataKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) KmpdataKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) KmpdataKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface KmpdataKtor_httpHttpStatusCode : KmpdataBase
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (KmpdataKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));
- (KmpdataKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=description_) NSString *description __attribute__((swift_name("description")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface KmpdataKtor_httpHttpProtocolVersion : KmpdataBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (KmpdataKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol KmpdataKtor_client_coreHttpRequest <KmpdataKtor_httpHttpMessage, KmpdataKotlinx_coroutines_coreCoroutineScope>
@required
@property (readonly) id<KmpdataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) KmpdataKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) KmpdataKtor_httpOutgoingContent *content __attribute__((swift_name("content")));
@property (readonly) KmpdataKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) KmpdataKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@interface KmpdataKtor_utilsStringValuesBuilder : KmpdataBase
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<KmpdataKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<KmpdataKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<KmpdataKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<KmpdataKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property BOOL built __attribute__((swift_name("built")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@property (readonly) KmpdataMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface KmpdataKtor_httpHeadersBuilder : KmpdataKtor_utilsStringValuesBuilder
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<KmpdataKtor_httpHeaders>)build __attribute__((swift_name("build()")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface KmpdataKtor_client_coreHttpRequestData : KmpdataBase
- (instancetype)initWithUrl:(KmpdataKtor_httpUrl *)url method:(KmpdataKtor_httpHttpMethod *)method headers:(id<KmpdataKtor_httpHeaders>)headers body:(KmpdataKtor_httpOutgoingContent *)body executionContext:(id<KmpdataKotlinx_coroutines_coreJob>)executionContext attributes:(id<KmpdataKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCapabilityOrNullKey:(id<KmpdataKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<KmpdataKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) KmpdataKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<KmpdataKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<KmpdataKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) KmpdataKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) KmpdataKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface KmpdataKtor_httpURLBuilder : KmpdataBase
- (instancetype)initWithProtocol:(KmpdataKtor_httpURLProtocol *)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password encodedPath:(NSString *)encodedPath parameters:(KmpdataKtor_httpParametersBuilder *)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:encodedPath:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
- (KmpdataKtor_httpUrl *)build __attribute__((swift_name("build()")));
- (NSString *)buildString __attribute__((swift_name("buildString()")));
- (KmpdataKtor_httpURLBuilder *)pathComponents:(KmpdataKotlinArray<NSString *> *)components __attribute__((swift_name("path(components:)")));
- (KmpdataKtor_httpURLBuilder *)pathComponents_:(NSArray<NSString *> *)components __attribute__((swift_name("path(components_:)")));
@property NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) KmpdataKtor_httpParametersBuilder *parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property int32_t port __attribute__((swift_name("port")));
@property KmpdataKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol KmpdataKotlinx_coroutines_coreJob <KmpdataKotlinCoroutineContextElement>
@required
- (id<KmpdataKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<KmpdataKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause_:(KmpdataKotlinx_coroutines_coreCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));
- (KmpdataKotlinx_coroutines_coreCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<KmpdataKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(KmpdataKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));
- (id<KmpdataKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(KmpdataKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));
- (id<KmpdataKotlinx_coroutines_coreJob>)plusOther_:(id<KmpdataKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<KmpdataKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<KmpdataKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface KmpdataKtor_httpHttpMethod : KmpdataBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (KmpdataKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreTypeInfo")))
@interface KmpdataKtor_client_coreTypeInfo : KmpdataBase
- (instancetype)initWithType:(id<KmpdataKotlinKClass>)type reifiedType:(id<KmpdataKtor_client_coreType>)reifiedType kotlinType:(id<KmpdataKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (id<KmpdataKotlinKClass>)component1 __attribute__((swift_name("component1()")));
- (id<KmpdataKtor_client_coreType>)component2 __attribute__((swift_name("component2()")));
- (id<KmpdataKotlinKType> _Nullable)component3 __attribute__((swift_name("component3()")));
- (KmpdataKtor_client_coreTypeInfo *)doCopyType:(id<KmpdataKotlinKClass>)type reifiedType:(id<KmpdataKtor_client_coreType>)reifiedType kotlinType:(id<KmpdataKotlinKType> _Nullable)kotlinType __attribute__((swift_name("doCopy(type:reifiedType:kotlinType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<KmpdataKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<KmpdataKtor_client_coreType> reifiedType __attribute__((swift_name("reifiedType")));
@property (readonly) id<KmpdataKotlinKClass> type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface KmpdataKtor_httpURLProtocol : KmpdataBase
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (KmpdataKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("Ktor_httpParameters")))
@protocol KmpdataKtor_httpParameters <KmpdataKtor_utilsStringValues>
@required
@end;

__attribute__((swift_name("KotlinMapEntry")))
@protocol KmpdataKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly, getter=value_) id _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Ktor_ioReadSession")))
@protocol KmpdataKtor_ioReadSession
@required
- (int32_t)discardN:(int32_t)n __attribute__((swift_name("discard(n:)")));
- (KmpdataKtor_ioIoBuffer * _Nullable)requestAtLeast:(int32_t)atLeast __attribute__((swift_name("request(atLeast:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteOrder")))
@interface KmpdataKtor_ioByteOrder : KmpdataKotlinEnum<KmpdataKtor_ioByteOrder *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) KmpdataKtor_ioByteOrder *bigEndian __attribute__((swift_name("bigEndian")));
@property (class, readonly) KmpdataKtor_ioByteOrder *littleEndian __attribute__((swift_name("littleEndian")));
- (int32_t)compareToOther:(KmpdataKtor_ioByteOrder *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface KmpdataKtor_utilsWeekDay : KmpdataKotlinEnum<KmpdataKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) KmpdataKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) KmpdataKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) KmpdataKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) KmpdataKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) KmpdataKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) KmpdataKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) KmpdataKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
- (int32_t)compareToOther:(KmpdataKtor_utilsWeekDay *)other __attribute__((swift_name("compareTo(other:)")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface KmpdataKtor_utilsMonth : KmpdataKotlinEnum<KmpdataKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) KmpdataKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) KmpdataKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) KmpdataKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) KmpdataKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) KmpdataKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) KmpdataKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) KmpdataKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) KmpdataKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) KmpdataKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) KmpdataKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) KmpdataKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) KmpdataKtor_utilsMonth *december __attribute__((swift_name("december")));
- (int32_t)compareToOther:(KmpdataKtor_utilsMonth *)other __attribute__((swift_name("compareTo(other:)")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface KmpdataKtor_httpOutgoingContent : KmpdataBase
- (id _Nullable)getPropertyKey:(KmpdataKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));
- (void)setPropertyKey:(KmpdataKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));
@property (readonly) KmpdataLong * _Nullable contentLength __attribute__((swift_name("contentLength")));
@property (readonly) KmpdataKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) id<KmpdataKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) KmpdataKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpParametersBuilder")))
@interface KmpdataKtor_httpParametersBuilder : KmpdataKtor_utilsStringValuesBuilder
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<KmpdataKtor_httpParameters>)build __attribute__((swift_name("build()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol KmpdataKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol KmpdataKotlinx_coroutines_coreChildHandle <KmpdataKotlinx_coroutines_coreDisposableHandle>
@required
- (BOOL)childCancelledCause:(KmpdataKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol KmpdataKotlinx_coroutines_coreChildJob <KmpdataKotlinx_coroutines_coreJob>
@required
- (void)parentCancelledParentJob:(id<KmpdataKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end;

__attribute__((swift_name("KotlinRuntimeException")))
@interface KmpdataKotlinRuntimeException : KmpdataKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinIllegalStateException")))
@interface KmpdataKotlinIllegalStateException : KmpdataKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCancellationException")))
@interface KmpdataKotlinx_coroutines_coreCancellationException : KmpdataKotlinIllegalStateException
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithCause:(KmpdataKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end;

__attribute__((swift_name("KotlinSequence")))
@protocol KmpdataKotlinSequence
@required
- (id<KmpdataKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol KmpdataKotlinx_coroutines_coreSelectClause0
@required
- (void)registerSelectClause0Select:(id<KmpdataKotlinx_coroutines_coreSelectInstance>)select block:(id<KmpdataKotlinSuspendFunction0>)block __attribute__((swift_name("registerSelectClause0(select:block:)")));
@end;

__attribute__((swift_name("Ktor_client_coreType")))
@protocol KmpdataKtor_client_coreType
@required
@end;

__attribute__((swift_name("KotlinKType")))
@protocol KmpdataKotlinKType
@required
@property (readonly, getter=arguments_) NSArray<KmpdataKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));
@property (readonly) id<KmpdataKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end;

__attribute__((swift_name("Ktor_ioBuffer")))
@interface KmpdataKtor_ioBuffer : KmpdataBase
- (instancetype)initWithMemory:(KmpdataKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer));
- (void)commitWrittenCount:(int32_t)count __attribute__((swift_name("commitWritten(count:)")));
- (int32_t)discardCount:(int32_t)count __attribute__((swift_name("discard(count:)"))) __attribute__((unavailable("Use discardExact instead.")));
- (int64_t)discardCount_:(int64_t)count __attribute__((swift_name("discard(count_:)"))) __attribute__((unavailable("Use discardExact instead.")));
- (void)discardExactCount:(int32_t)count __attribute__((swift_name("discardExact(count:)")));
- (KmpdataKtor_ioBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)duplicateToCopy:(KmpdataKtor_ioBuffer *)copy __attribute__((swift_name("duplicateTo(copy:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (void)reserveEndGapEndGap:(int32_t)endGap __attribute__((swift_name("reserveEndGap(endGap:)")));
- (void)reserveStartGapStartGap:(int32_t)startGap __attribute__((swift_name("reserveStartGap(startGap:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)resetForRead __attribute__((swift_name("resetForRead()")));
- (void)resetForWrite __attribute__((swift_name("resetForWrite()")));
- (void)resetForWriteLimit:(int32_t)limit __attribute__((swift_name("resetForWrite(limit:)")));
- (void)rewindCount:(int32_t)count __attribute__((swift_name("rewind(count:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeekByte __attribute__((swift_name("tryPeekByte()")));
- (int32_t)tryReadByte __attribute__((swift_name("tryReadByte()")));
- (void)writeByteValue:(int8_t)value __attribute__((swift_name("writeByte(value:)")));
@property id _Nullable attachment __attribute__((swift_name("attachment"))) __attribute__((deprecated("Will be removed. Inherit Buffer and add required fields instead.")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@property (readonly) int32_t endGap __attribute__((swift_name("endGap")));
@property (readonly) int32_t limit __attribute__((swift_name("limit")));
@property (readonly) KmpdataKtor_ioMemory *memory __attribute__((swift_name("memory")));
@property (readonly) int32_t readPosition __attribute__((swift_name("readPosition")));
@property (readonly) int32_t readRemaining __attribute__((swift_name("readRemaining")));
@property (readonly) int32_t startGap __attribute__((swift_name("startGap")));
@property (readonly) int32_t writePosition __attribute__((swift_name("writePosition")));
@property (readonly) int32_t writeRemaining __attribute__((swift_name("writeRemaining")));
@end;

__attribute__((swift_name("Ktor_ioChunkBuffer")))
@interface KmpdataKtor_ioChunkBuffer : KmpdataKtor_ioBuffer
- (instancetype)initWithMemory:(KmpdataKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (KmpdataKtor_ioChunkBuffer * _Nullable)cleanNext __attribute__((swift_name("cleanNext()")));
- (KmpdataKtor_ioChunkBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)releasePool:(id<KmpdataKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool:)")));
- (void)reset __attribute__((swift_name("reset()")));
@property (getter=next_) KmpdataKtor_ioChunkBuffer * _Nullable next __attribute__((swift_name("next")));
@property (readonly) KmpdataKtor_ioChunkBuffer * _Nullable origin __attribute__((swift_name("origin")));
@property (readonly) int32_t referenceCount __attribute__((swift_name("referenceCount")));
@end;

__attribute__((swift_name("Ktor_ioInput")))
@protocol KmpdataKtor_ioInput <KmpdataKtor_ioCloseable>
@required
- (int64_t)discardN_:(int64_t)n __attribute__((swift_name("discard(n_:)")));
- (int64_t)peekToDestination:(KmpdataKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
@property KmpdataKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((unavailable("Not supported anymore. All operations are big endian by default. Use readXXXLittleEndian or readXXX then X.reverseByteOrder() instead.")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@end;

__attribute__((swift_name("KotlinAppendable")))
@protocol KmpdataKotlinAppendable
@required
- (id<KmpdataKotlinAppendable>)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));
- (id<KmpdataKotlinAppendable>)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));
- (id<KmpdataKotlinAppendable>)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
@end;

__attribute__((swift_name("Ktor_ioOutput")))
@protocol KmpdataKtor_ioOutput <KmpdataKotlinAppendable, KmpdataKtor_ioCloseable>
@required
- (id<KmpdataKotlinAppendable>)appendCsq:(KmpdataKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("append(csq:start:end:)")));
- (void)flush __attribute__((swift_name("flush()")));
- (void)writeByteV:(int8_t)v __attribute__((swift_name("writeByte(v:)")));
@property KmpdataKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((deprecated("Write with writeXXXLittleEndian or do X.reverseByteOrder() and then writeXXX instead.")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioIoBuffer")))
@interface KmpdataKtor_ioIoBuffer : KmpdataKtor_ioChunkBuffer <KmpdataKtor_ioInput, KmpdataKtor_ioOutput>
- (instancetype)initWithContent:(void *)content contentCapacity:(int32_t)contentCapacity __attribute__((swift_name("init(content:contentCapacity:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use Buffer instead.")));
- (instancetype)initWithMemory:(KmpdataKtor_ioMemory *)memory origin:(KmpdataKtor_ioChunkBuffer * _Nullable)origin __attribute__((swift_name("init(memory:origin:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use Buffer instead.")));
- (id<KmpdataKotlinAppendable>)appendValue:(unichar)c __attribute__((swift_name("append(value:)")));
- (id<KmpdataKotlinAppendable>)appendCsq:(KmpdataKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("append(csq:start:end:)")));
- (id<KmpdataKotlinAppendable>)appendValue_:(id _Nullable)csq __attribute__((swift_name("append(value_:)")));
- (id<KmpdataKotlinAppendable>)appendValue:(id _Nullable)csq startIndex:(int32_t)start endIndex:(int32_t)end __attribute__((swift_name("append(value:startIndex:endIndex:)")));
- (int32_t)appendCharsCsq:(KmpdataKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("appendChars(csq:start:end:)")));
- (int32_t)appendCharsCsq:(id)csq start:(int32_t)start end_:(int32_t)end __attribute__((swift_name("appendChars(csq:start:end_:)")));
- (void)close __attribute__((swift_name("close()")));
- (int64_t)discardCount_:(int64_t)n __attribute__((swift_name("discard(count_:)")));
- (KmpdataKtor_ioIoBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)flush __attribute__((swift_name("flush()")));
- (KmpdataKtor_ioIoBuffer *)makeView __attribute__((swift_name("makeView()")));
- (int64_t)peekToDestination:(KmpdataKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int32_t)readDirectBlock:(KmpdataInt *(^)(id))block __attribute__((swift_name("readDirect(block:)")));
- (void)releasePool_:(id<KmpdataKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool_:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
- (void)writeByteValue:(int8_t)v __attribute__((swift_name("writeByte(value:)")));
- (int32_t)writeDirectBlock:(KmpdataInt *(^)(id))block __attribute__((swift_name("writeDirect(block:)")));
@property KmpdataKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((unavailable("Not supported anymore. All operations are big endian by default.")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@end;

__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface KmpdataKtor_httpHeaderValueWithParameters : KmpdataBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<KmpdataKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<KmpdataKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface KmpdataKtor_httpContentType : KmpdataKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<KmpdataKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<KmpdataKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)matchPattern:(KmpdataKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));
- (KmpdataKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));
- (KmpdataKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol KmpdataKotlinx_coroutines_coreParentJob <KmpdataKotlinx_coroutines_coreJob>
@required
- (KmpdataKotlinx_coroutines_coreCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol KmpdataKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnSelectHandle:(id<KmpdataKotlinx_coroutines_coreDisposableHandle>)handle __attribute__((swift_name("disposeOnSelect(handle:)")));
- (id _Nullable)performAtomicTrySelectDesc:(KmpdataKotlinx_coroutines_coreAtomicDesc *)desc __attribute__((swift_name("performAtomicTrySelect(desc:)")));
- (void)resumeSelectWithExceptionException:(KmpdataKotlinThrowable *)exception __attribute__((swift_name("resumeSelectWithException(exception:)")));
- (BOOL)trySelect __attribute__((swift_name("trySelect()")));
- (id _Nullable)trySelectOtherOtherOp:(KmpdataKotlinx_coroutines_corePrepareOp * _Nullable)otherOp __attribute__((swift_name("trySelectOther(otherOp:)")));
@property (readonly) id<KmpdataKotlinContinuation> completion __attribute__((swift_name("completion")));
@property (readonly) BOOL isSelected __attribute__((swift_name("isSelected")));
@end;

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol KmpdataKotlinSuspendFunction0 <KmpdataKotlinFunction>
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface KmpdataKotlinKTypeProjection : KmpdataBase
- (instancetype)initWithVariance:(KmpdataKotlinKVariance * _Nullable)variance type:(id<KmpdataKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
- (KmpdataKotlinKVariance * _Nullable)component1 __attribute__((swift_name("component1()")));
- (id<KmpdataKotlinKType> _Nullable)component2 __attribute__((swift_name("component2()")));
- (KmpdataKotlinKTypeProjection *)doCopyVariance:(KmpdataKotlinKVariance * _Nullable)variance type:(id<KmpdataKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<KmpdataKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) KmpdataKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory")))
@interface KmpdataKtor_ioMemory : KmpdataBase
- (instancetype)initWithPointer:(void *)pointer size:(int64_t)size __attribute__((swift_name("init(pointer:size:)"))) __attribute__((objc_designated_initializer));
- (void)doCopyToDestination:(KmpdataKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length destinationOffset:(int32_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset:)")));
- (void)doCopyToDestination:(KmpdataKtor_ioMemory *)destination offset:(int64_t)offset length:(int64_t)length destinationOffset_:(int64_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset_:)")));
- (int8_t)loadAtIndex:(int32_t)index __attribute__((swift_name("loadAt(index:)")));
- (int8_t)loadAtIndex_:(int64_t)index __attribute__((swift_name("loadAt(index_:)")));
- (KmpdataKtor_ioMemory *)sliceOffset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("slice(offset:length:)")));
- (KmpdataKtor_ioMemory *)sliceOffset:(int64_t)offset length_:(int64_t)length __attribute__((swift_name("slice(offset:length_:)")));
- (void)storeAtIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("storeAt(index:value:)")));
- (void)storeAtIndex:(int64_t)index value_:(int8_t)value __attribute__((swift_name("storeAt(index:value_:)")));
@property (readonly) void *pointer __attribute__((swift_name("pointer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@property (readonly) int32_t size32 __attribute__((swift_name("size32")));
@end;

__attribute__((swift_name("Ktor_ioObjectPool")))
@protocol KmpdataKtor_ioObjectPool <KmpdataKtor_ioCloseable>
@required
- (id)borrow __attribute__((swift_name("borrow()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)recycleInstance:(id)instance __attribute__((swift_name("recycle(instance:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinCharArray")))
@interface KmpdataKotlinCharArray : KmpdataBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(id (^)(KmpdataInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (unichar)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (KmpdataKotlinCharIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(unichar)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface KmpdataKtor_httpHeaderValueParam : KmpdataBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (KmpdataKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value __attribute__((swift_name("doCopy(name:value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicDesc")))
@interface KmpdataKotlinx_coroutines_coreAtomicDesc : KmpdataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(KmpdataKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)prepareOp:(KmpdataKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
@property KmpdataKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreOpDescriptor")))
@interface KmpdataKotlinx_coroutines_coreOpDescriptor : KmpdataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (BOOL)isEarlierThanThat:(KmpdataKotlinx_coroutines_coreOpDescriptor *)that __attribute__((swift_name("isEarlierThan(that:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) KmpdataKotlinx_coroutines_coreAtomicOp<id> * _Nullable atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_corePrepareOp")))
@interface KmpdataKotlinx_coroutines_corePrepareOp : KmpdataKotlinx_coroutines_coreOpDescriptor
- (instancetype)initWithAffected:(KmpdataKotlinx_coroutines_coreLinkedListNode *)affected desc:(KmpdataKotlinx_coroutines_coreAbstractAtomicDesc *)desc atomicOp:(KmpdataKotlinx_coroutines_coreAtomicOp<id> *)atomicOp __attribute__((swift_name("init(affected:desc:atomicOp:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)finishPrepare __attribute__((swift_name("finishPrepare()")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
@property (readonly) KmpdataKotlinx_coroutines_coreLinkedListNode *affected __attribute__((swift_name("affected")));
@property (readonly) KmpdataKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) KmpdataKotlinx_coroutines_coreAbstractAtomicDesc *desc __attribute__((swift_name("desc")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface KmpdataKotlinKVariance : KmpdataKotlinEnum<KmpdataKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) KmpdataKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) KmpdataKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) KmpdataKotlinKVariance *out __attribute__((swift_name("out")));
- (int32_t)compareToOther:(KmpdataKotlinKVariance *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("KotlinCharIterator")))
@interface KmpdataKotlinCharIterator : KmpdataBase <KmpdataKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id)next __attribute__((swift_name("next()")));
- (unichar)nextChar __attribute__((swift_name("nextChar()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicOp")))
@interface KmpdataKotlinx_coroutines_coreAtomicOp<__contravariant T> : KmpdataKotlinx_coroutines_coreOpDescriptor
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeAffected:(T _Nullable)affected failure:(id _Nullable)failure __attribute__((swift_name("complete(affected:failure:)")));
- (id _Nullable)decideDecision:(id _Nullable)decision __attribute__((swift_name("decide(decision:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (id _Nullable)prepareAffected:(T _Nullable)affected __attribute__((swift_name("prepare(affected:)")));
@property (readonly) KmpdataKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) BOOL isDecided __attribute__((swift_name("isDecided")));
@property (readonly) int64_t opSequence __attribute__((swift_name("opSequence")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLinkedListNode")))
@interface KmpdataKotlinx_coroutines_coreLinkedListNode : KmpdataBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)addLastNode:(KmpdataKotlinx_coroutines_coreLinkedListNode *)node __attribute__((swift_name("addLast(node:)")));
- (BOOL)addLastIfNode:(KmpdataKotlinx_coroutines_coreLinkedListNode *)node condition:(KmpdataBoolean *(^)(void))condition __attribute__((swift_name("addLastIf(node:condition:)")));
- (BOOL)addLastIfPrevNode:(KmpdataKotlinx_coroutines_coreLinkedListNode *)node predicate:(KmpdataBoolean *(^)(KmpdataKotlinx_coroutines_coreLinkedListNode *))predicate __attribute__((swift_name("addLastIfPrev(node:predicate:)")));
- (BOOL)addLastIfPrevAndIfNode:(KmpdataKotlinx_coroutines_coreLinkedListNode *)node predicate:(KmpdataBoolean *(^)(KmpdataKotlinx_coroutines_coreLinkedListNode *))predicate condition:(KmpdataBoolean *(^)(void))condition __attribute__((swift_name("addLastIfPrevAndIf(node:predicate:condition:)")));
- (BOOL)addOneIfEmptyNode:(KmpdataKotlinx_coroutines_coreLinkedListNode *)node __attribute__((swift_name("addOneIfEmpty(node:)")));
- (void)helpRemove __attribute__((swift_name("helpRemove()")));
- (BOOL)remove __attribute__((swift_name("remove()")));
- (id _Nullable)removeFirstIfIsInstanceOfOrPeekIfPredicate:(KmpdataBoolean *(^)(id _Nullable))predicate __attribute__((swift_name("removeFirstIfIsInstanceOfOrPeekIf(predicate:)")));
- (KmpdataKotlinx_coroutines_coreLinkedListNode * _Nullable)removeFirstOrNull __attribute__((swift_name("removeFirstOrNull()")));
@property (readonly) BOOL isRemoved __attribute__((swift_name("isRemoved")));
@property (readonly) KmpdataKotlinx_coroutines_coreLinkedListNode *nextNode __attribute__((swift_name("nextNode")));
@property (readonly) KmpdataKotlinx_coroutines_coreLinkedListNode *prevNode __attribute__((swift_name("prevNode")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAbstractAtomicDesc")))
@interface KmpdataKotlinx_coroutines_coreAbstractAtomicDesc : KmpdataKotlinx_coroutines_coreAtomicDesc
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(KmpdataKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)failureAffected:(KmpdataKotlinx_coroutines_coreLinkedListNode *)affected __attribute__((swift_name("failure(affected:)")));
- (void)finishOnSuccessAffected:(KmpdataKotlinx_coroutines_coreLinkedListNode *)affected next:(KmpdataKotlinx_coroutines_coreLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(KmpdataKotlinx_coroutines_corePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (void)onComplete __attribute__((swift_name("onComplete()")));
- (id _Nullable)onPreparePrepareOp:(KmpdataKotlinx_coroutines_corePrepareOp *)prepareOp __attribute__((swift_name("onPrepare(prepareOp:)")));
- (id _Nullable)prepareOp:(KmpdataKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
- (BOOL)retryAffected:(KmpdataKotlinx_coroutines_coreLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
@property (readonly) KmpdataKotlinx_coroutines_coreLinkedListNode *affectedNode __attribute__((swift_name("affectedNode")));
@end;

#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
