//
//  MySDK.h
//  MySDK
//
//  Created by Carmelo Iriti on 25.05.20.
//  Copyright © 2020 Carmelo Iriti. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MySDK.
FOUNDATION_EXPORT double MySDKVersionNumber;

//! Project version string for MySDK.
FOUNDATION_EXPORT const unsigned char MySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MySDK/PublicHeader.h>


